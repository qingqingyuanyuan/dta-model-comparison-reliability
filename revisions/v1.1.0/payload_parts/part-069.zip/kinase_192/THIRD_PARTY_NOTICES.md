# Third-party notices and unresolved attribution

BatchDTA official source/project and DOI10.1093/bib/bbac260 are given in README_DATA_PROVENANCE. Cite the original KIBA/Davis sources listed in the manuscript. Exact source dataset licensing has not been independently established by this packaging run; full inputs are not included.

PaddleHelix root LICENSE was viewed at https://github.com/PaddlePaddle/PaddleHelix/blob/dev/LICENSE on2026-11-10 and states Attribution-NonCommercial-ShareAlike4.0 International. This notice is not assumed to cover every external dataset.

Received source imports NumPy, pandas, SciPy, scikit-learn, PyTorch, PyTorch Geometric, RDKit, matplotlib and python-docx. Those package distributions are not vendored. Install through official sources and retain their own notices. A pip-freeze is a version record, not a complete transitive license audit; package-version-specific licenses and any adapted source require confirmation before assigning project-wide terms.

Original126 source/evaluation metadata here comes from the explicitly identified local archived v1.0.0 repository snapshot. Existing source/author headers are retained. The matched baselines preserve the supplied style-reimplementation description and are not claimed exact reproductions of upstream DeepDTA/GraphDTA repositories.

---

# 发布前补充核查（2026-11-10，追加）

以下为许可落定前对所有代码文件做的独立核查结果，追加说明，不替换上文。

## 1. 包内未发现第三方版权声明（原创结论另由逐行比对支撑）

> 说明：`Copyright`/`SPDX` 命中为 0 只能说明**未发现**第三方声明，不能单独证明代码原创；
> 因此本节仅陈述扫描事实，原创结论由第 2 节的逐行比对给出。

`CODE_AND_ENVIRONMENT/` 下 128 个代码与文本文件全部扫描（`.py/.sh/.md/.txt/.yml/.yaml/.cfg/.toml`），
检索 `copyright`、`spdx`、`paddlehelix`、`deepdta`、`graphdta`、`hkmztrk`、`thinng`、`apache licen`、
`mit licen`、`gnu`、`bsd`：`Copyright` 与 `SPDX` 命中数均为 0，无任何第三方版权头或 `LICENSE`/`NOTICE`/`COPYING` 文件。

## 2. 逐行比对：上游仓库与本包不存在可复制的对应文件

- DeepDTA (`hkmztrk/DeepDTA`) 仓库目录树已核对：**没有 `models/` 目录**，模型代码写在单文件
  `source/run_experiments.py` 中，框架为 Keras/TensorFlow，函数名为 `build_combined_onehot`、
  `build_combined_categorical`。本包 `training/baselines/deepdta.py` 为 PyTorch `nn.Module`
  （类 `DeepDTAStyle`，71 行），文件结构、框架、接口均不同。
- GraphDTA 上游（`thinng/GraphDTA`，`models/gcn.py`，72 行）**同样使用 PyTorch Geometric**（`from torch_geometric.nn import GCNConv, global_max_pool`），故「框架不同」不能作为区分依据，改为逐行比对：
  上游为固定维度 `GCNNet`（78 维节点特征、3 层 `GCNConv`、`nn.Conv1d(1000, …)`、固定 `32*121` 展平）；
  本包 `training/baselines/graphdta.py`（94 行）为配置驱动的 `GraphDTAStyleGCN`（节点线性投影 + `nn.ModuleList`
  动态层数、蛋白分支复用项目自有 `CharacterCNNEncoder`、回归头复用 `RegressionHead`、含 `parameter_summary()`）。
  两文件非空行相似度 **0.057**，无逐行可对应代码；共享的仅是已发表的架构思想（GCN 编码器 + 蛋白 CNN + 拼接 + MLP）。
- 两者均在文件头自述为 style-level controlled reimplementation，非上游仓库的精确复现。

## 3. DeepDTA / GraphDTA 上游无 LICENSE 文件

两仓库的 `LICENSE` 路径均取回 404，即上游未授予任何开源许可（默认保留所有权利）。
本包不包含、也不再分发其代码，因此无需继承其许可；如需复用本包，请引用其原始论文。

## 4. 唯一「下载」的是数据，不是代码

`original126_snapshot/.../scripts/download_data.py` 从 `hkmztrk/DeepDTA/master/data/` 获取
`drugs.txt`、`targets.txt`、`Y.txt`，属 KIBA/Davis 原始数据文件，**不随本包分发**。

## 5. 比对方法、版本锚点与实测结果（2026-11-11 复核）

- **方法**：两文件均去空行、去行首尾空白后按行序比对；相似度 = `difflib.SequenceMatcher.ratio()`
  （2×匹配行数 / 两文件行数和）；另统计最长连续匹配块，用于判断是否存在较长的连续逐行复制。
- **版本锚点**：经 jsdelivr 取回并按 SHA-256 固定（该镜像接口只返回分支名、不返回 commit，
  故以「文件哈希 + 取回日期」为准，取到同哈希即同一版本）。
  GraphDTA `models/gcn.py` 2,299 字节 / 72 行 / `552a25d6…75cd`；
  DeepDTA `source/run_experiments.py` 21,520 字节 / 546 行 / `6582831a…b697`。
- **实测**：

| 基线 | 上游非空行 | 本包非空行 | 相似度 | 最长连续匹配块 | ≥3 行匹配块数 |
|---|---|---|---|---|---|
| GraphDTA | 59 | 82 | 0.0567 | 3 行（`import torch` / `import torch.nn as nn` / `import torch.nn.functional as F`） | 1 |
| DeepDTA | 371 | 61 | 0.0000 | 0 行 | 0 |

即 GraphDTA 的 5.67% 全部来自标准框架 import 与一处单行 `return out`，不存在实质代码段落重叠；
DeepDTA 无任何逐行匹配。二者均非对上游文件的裁切或改名复制。
- **方法局限**：行级比对可证明「无连续对应代码」，不能排除「改写 / 改变量名 / 重排」，
  此类情形需人工语义比对。故原创结论由「逐行比对 + 作者声明」两项并列支撑，不单靠扫描命中数。
- **开发记录能证明什么**：包内 `execution_records/`（`revision_runtime`、`worker_A`、`worker_B`）
  记录运行调度与日志，可证明这些脚本由本项目实际运行并产出了随包结果；
  包内不含版本库历史，**不能**据此证明逐次提交的作者归属，作者归属以 `CITATION.cff` 与作者声明为准。
