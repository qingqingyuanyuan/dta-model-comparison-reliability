# BatchDTA 四个输入 CSV：哈希、来源版本与哈希来源证明

回答队友的三个问题：① 四个文件的完整 SHA-256；② 实际使用的 BatchDTA 数据包下载地址与版本；③ 这些哈希是否算在当初正式实验所用文件上，而非事后重新下载的文件。

---

## 一、四个文件的完整 SHA-256

前缀均为 `data/colab/BatchDTA_processed_data/`。

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| `KIBA/train_KIBA_unseenP_seenD.csv` | 81,472,017 | `8a91a9a5e2457d9f482d61b7ecf3e9748dfc4168a6afcc4b78c7a056a1ffcb28` |
| `KIBA/test_KIBA_unseenP_seenD.csv` | 13,885,642 | `258b843129167bf55afe265b913a53b523f7ab0b9b73069526863aeda03b3d6e` |
| `DAVIS/train_DAVIS_unseenP_seenD.csv` | 22,108,353 | `9df2254fabda4702e9410c6bbe85a9cecd2491472ce331ce7d7c7c7e8a71b74d` |
| `DAVIS/test_DAVIS_unseenP_seenD.csv` | 3,973,893 | `f9d6df455daeef702d858cb6667b162759f8000e2a89bf6813d00f3caed0946e` |

合计 121,439,905 字节。

## 二、数据包来源与版本

| 项目 | 值 |
|---|---|
| 数据包名称 | `BatchDTA_processed_data` |
| 官方下载地址 | `https://baidu-nlp.bj.bcebos.com/PaddleHelix/datasets/dti_datasets/BatchDTA_processed_data.zip` |
| 出处说明 | PaddleHelix 仓库 `apps/drug_target_interaction/batchdta/README.md`（dev 分支）："The processed datasets can be downloaded from here… uncompress and put the downloaded directory under `/apps/drug_target_interaction/batchdta/`" |
| 代码仓库 | `https://github.com/PaddlePaddle/PaddleHelix/tree/dev/apps/drug_target_interaction/batchdta` |
| 对应论文 | BatchDTA, *Briefings in Bioinformatics* 2022, doi:10.1093/bib/bbac260 |
| zip 字节数 | 45,081,433 |
| **zip SHA-256** | `b10231276d9ab7135c1243f94bba95f096d43e6c13f7872986dd80bbf76d689d` |
| 服务器 Last-Modified | 2022-04-13 06:12:45 GMT |
| ETag | `2a80d2dc60b49e8b58c68e5b6b557f6f` |
| 包内四个文件时间戳 | 2022-01-09（KIBA/DAVIS 主文件）、2022-01-12（mixed 系列） |

**关键比对**：2026-11-09 重新从上述官方地址下载该 zip，直接对包内四个文件流式计算 SHA-256，结果与第一节四个值逐字相同。因此这四份 CSV 是官方发布包的原样文件，未经过滤、重采样、重编码或格式转换。

## 三、这些哈希是否算在当初正式实验所用文件上

是。证据分四层，且能闭合。

1. **哈希由生成流程当场计算，不是外部补录。**
   `scripts/prepare_final_datasets.py` 内置 `file_sha256()`（第 172 行），在生成 `data_final` 切分时读取源 CSV 并计算哈希，写入 manifest 的 `source_files` 段（第 951 行）与 `files` 段（第 978 行）。也就是说，记录值就是该脚本读盘那一刻的字节。

2. **时间顺序排除“事后重算”。**
   `data_final/manifest.json` 的 mtime 为 2026-09-06 03:33:58（UTC），`FINAL_RUNTIME_MANIFEST.json` 为 2026-09-06 03:33:52；而正式训练与评估发生在 2026-11-07 至 11-08（`train_cm.log`、`eval_all.log` 等时间戳）。manifest 早于训练两个月，不可能由训练之后的重算产生。

3. **正式实验实际读取的派生文件，全量复核通过。**
   正式 126 runs 训练读取的是 `data_final` 下的派生切分，不是源 CSV 本身。在运行这批实验的同一台实例上，对 manifest 登记的 41 个派生文件逐个重算 SHA-256：**41/41 全部一致（0 缺失、0 不符）**。说明训练时喂给模型的那套文件，正是 manifest 所描述的那一套，未被替换或改动。

4. **源文件字节三方一致。**
   生成时记录值 = 本机 `05-模型输入数据\BatchDTA-processed` 四文件实测值 = 官方 zip 内四文件实测值。本机这四份解包于 2026-07-25 19:27，早于 9 月 6 日生成 `data_final`，也早于 11 月正式训练。

**边界说明（不夸大）**：这批源 CSV 在生成 `data_final` 之后已从云实例清理，因此 2026-11-09 无法在实例上对源 CSV 现场重算。上面第 1–3 条构成“生成时记录 + 派生全量复核”的证据链，第 4 条以官方发布包做字节级对照。三者合起来足以确认哈希对应的是当初正式实验所依赖的文件，不是后来另行下载的另一份。

## 四、时间线

| 时间 | 事件 |
|---|---|
| 2022-01-09 / 01-12 | 官方包内四个 CSV 的最后修改时间 |
| 2022-04-13 | 官方 zip 服务器最后更新 |
| 2026-07-25 19:27 | 本机解包得到四份 CSV（字节与官方包一致） |
| 2026-09-06 03:33 | `prepare_final_datasets.py` 生成 `data_final`，同时记录源文件 bytes/sha256 |
| 2026-11-07 ~ 11-08 | 正式 126 runs 训练与评估（读取 `data_final` 派生切分） |
| 2026-11-09 | 三重复核：manifest 41/41、本机实测、官方 zip 实测 |

## 五、复核命令

```bash
# 官方包内四文件的哈希（Linux/macOS）
curl -sL -o /tmp/BatchDTA_processed_data.zip https://baidu-nlp.bj.bcebos.com/PaddleHelix/datasets/dti_datasets/BatchDTA_processed_data.zip
sha256sum /tmp/BatchDTA_processed_data.zip          # 应为 b10231276d9ab7135c1243f94bba95f096d43e6c13f7872986dd80bbf76d689d
unzip -p /tmp/BatchDTA_processed_data.zip '*KIBA/train_KIBA_unseenP_seenD.csv' | sha256sum
```

```powershell
# 本地四文件
Get-ChildItem -Recurse -Filter "*_unseenP_seenD.csv" |
  Where-Object { $_.FullName -notmatch "__MACOSX|_mixed_" } |
  Get-FileHash -Algorithm SHA256
```

```bash
# 派生切分全量复核（在运行过正式实验的实例上）
cd /root/rivermind-data/dta_cm && python3 - <<'PY'
import json, hashlib, pathlib
m = json.load(open('data_final/manifest.json'))
ok = bad = 0
for rel, meta in m['files'].items():
    p = pathlib.Path('data_final') / rel
    h = hashlib.sha256(p.read_bytes()).hexdigest()
    ok += h == meta['sha256']; bad += h != meta['sha256']
print('ok=%d mismatch=%d' % (ok, bad))
PY
```

## 六、可直接转给队友的答复

> 四个 BatchDTA 输入 CSV 的版本与校验值已核实。
>
> 数据来源是 BatchDTA（PaddleHelix）官方发布的 `BatchDTA_processed_data.zip`，地址 `https://baidu-nlp.bj.bcebos.com/PaddleHelix/datasets/dti_datasets/BatchDTA_processed_data.zip`，压缩包 45,081,433 字节、SHA-256 `b10231276d9ab7135c1243f94bba95f096d43e6c13f7872986dd80bbf76d689d`、服务器最后更新 2022-04-13。
>
> 四个文件（KIBA/DAVIS × train/test）的字节数与 SHA-256 见上表，合计 121,439,905 字节。
>
> 关于“是否算在当初实验用的文件上”：是。哈希由 `scripts/prepare_final_datasets.py` 在生成正式切分时（2026-09-06 03:33 UTC）对源文件实时计算并写入 `data_final/manifest.json`；该 manifest 早于正式训练（2026-11-07）两个月，不存在事后重算。正式实验读取的 41 个派生切分文件已逐份重算，41/41 与 manifest 一致。这四个源文件再与今日从官方地址重新下载的 zip 内同名文件逐字节比对，SHA-256 完全相同。
>
> 说明：源 CSV 在生成 `data_final` 后已从训练实例清理，故无法在实例上对源文件现场重算；上述证据来自生成时记录、派生文件全量复核与官方包字节比对三方面。

---

整理时间：2026-11-09
