import pathlib,pandas as pd,numpy as np,json,sys,hashlib
from itertools import permutations
from types import SimpleNamespace
def kendalltau(a,b,method='exact'):
 a=np.asarray(a);b=np.asarray(b)
 def stat(x):
  return sum(np.sign(a[i]-a[j])*np.sign(x[i]-x[j]) for i in range(len(a)) for j in range(i))/ (len(a)*(len(a)-1)/2)
 t=stat(b);v=[stat(np.array(x)) for x in permutations(b)]
 return SimpleNamespace(statistic=t,pvalue=sum(abs(x)>=abs(t)-1e-12 for x in v)/len(v))
sys.stdout.reconfigure(encoding='utf-8')
O=pathlib.Path('work/analysis');O.mkdir(exist_ok=True)
def ci(y,p):
 # Fenwick scan by label, never count pairs sharing a label
 y=np.asarray(y);p=np.asarray(p);r=np.searchsorted(np.unique(p),p)+1;tree=np.zeros(r.max()+2,dtype=np.int64);order=np.argsort(y,kind='stable');score=0.;den=0;seen=0
 def query(k):
  s=0
  while k:s+=tree[k];k-=k&-k
  return s
 j=0
 while j<len(y):
  k=j+1
  while k<len(y) and y[order[k]]==y[order[j]]:k+=1
  for v in order[j:k]:score+=query(r[v]-1)+.5*(query(r[v])-query(r[v]-1));den+=seen
  for v in order[j:k]:
   x=r[v]
   while x<len(tree):tree[x]+=1;x+=x&-x
  seen+=k-j;j=k
 return score/den if den else np.nan
# independent small tie check
assert ci([1,1,2],[1,2,2])==.75
roots={'GPCR_split42':pathlib.Path('work/nonkin/DTA_NonKinase_30'),'Protease_split42':pathlib.Path('work/protease/DTA_Protease_60/batches/protease_split42'),'Protease_split2026':pathlib.Path('work/protease/DTA_Protease_60/batches/protease_split2026')}
rows=[];counts=[];checks=[];rankrows=[];errors=[]
for batch,root in roots.items():
 orig=pd.read_csv(root/'results/ALL_30_METRICS.csv')
 for run in sorted((root/'results/runs').iterdir()):
  cfg=json.loads((run/'run_config.json').read_text());summary=json.loads((run/'EVALUATION_DONE.json').read_text())['summary'];setting,model,seed=run.name.split('__');seed=int(seed[4:]);d=pd.read_csv(run/'test_predictions.csv',float_precision='round_trip');u=pd.read_csv(run/'test_unique_input_predictions.csv',float_precision='round_trip')
  yp='Prediction_pKi'; label='Label' if 'Label' in u else 'Label_pKi'
  metrics={'C_index':ci(d.Label,d[yp]),'RMSE_pKi':np.sqrt(np.mean((d.Label-d[yp])**2)),'MAE_pKi':np.mean(abs(d.Label-d[yp])),'unique_C_index':ci(u[label],u[yp]),'unique_RMSE_pKi':np.sqrt(np.mean((u[label]-u[yp])**2)),'unique_MAE_pKi':np.mean(abs(u[label]-u[yp]))}
  delta=max(abs(summary[k]-v) for k,v in metrics.items());errors.append(delta)
  h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
  rec=json.loads((run/'EVALUATION_DONE.json').read_text());checks.append({'batch':batch,'run':run.name,'metric_max_abs_delta_roundtrip':delta,'checkpoint_hash_matches':h(run/'best.pt')==rec['checkpoint_sha256'],'prediction_hash_matches':h(run/'test_predictions.csv')==rec['prediction_sha256'],'config_freeze':cfg['freeze_hash']==rec['freeze_hash']})
  rows.append(dict(batch=batch,setting=setting,model=model,seed=seed,records=len(d),unique_inputs=len(u),**metrics))
  if seed==42 and model=='concat':
   counts.append(dict(batch=batch,setting=setting,partition='test',records=len(d),unique_inputs=len(u),drugs=d['Canonical SMILES'].nunique(),targets=d['Target Sequence'].nunique(),label_mean=d.Label.mean(),label_min=d.Label.min(),label_max=d.Label.max()))
 for setting in ['cold_drug','cold_target']:
  if (root/'prepared'/setting).exists():
   ds={p:pd.read_csv(root/'prepared'/setting/(p+'.csv'),float_precision='round_trip') for p in ['train','val','test']}
   key='Canonical SMILES' if setting=='cold_drug' else 'Target Sequence'
   for p,d in ds.items():
    counts.append(dict(batch=batch,setting=setting,partition=p,records=len(d),unique_inputs=len(d.drop_duplicates(['Canonical SMILES','Target Sequence'])),drugs=d['Canonical SMILES'].nunique(),targets=d['Target Sequence'].nunique(),label_mean=d.Label.mean(),label_min=d.Label.min(),label_max=d.Label.max()))
   for a,b in [('train','val'),('train','test'),('val','test')]:assert not set(ds[a][key])&set(ds[b][key])
R=pd.DataFrame(rows);R.to_csv(O/'recomputed_90_metrics.csv',index=False);pd.DataFrame(checks).to_csv(O/'audit_90.csv',index=False);pd.DataFrame(counts).drop_duplicates(['batch','setting','partition'],keep='last').to_csv(O/'partition_counts.csv',index=False)
S=R.groupby(['batch','setting','model']).agg({x:['mean','std'] for x in ['C_index','RMSE_pKi','MAE_pKi','unique_C_index','unique_RMSE_pKi']});S.columns=['_'.join(c) for c in S.columns];S=S.reset_index();S['rank']=S.groupby(['batch','setting']).C_index_mean.rank(ascending=False);S.to_csv(O/'summary_90.csv',index=False)
for batch in roots:
 a=S[(S.batch==batch)&(S.setting=='cold_drug')].set_index('model');b=S[(S.batch==batch)&(S.setting=='cold_target')].set_index('model');t=kendalltau(a.C_index_mean,b.C_index_mean,method='exact');rankrows.append(dict(batch=batch,comparison='cold_drug_vs_cold_target',tau=t.statistic,p=t.pvalue))
for setting in ['cold_drug','cold_target']:
 a=S[(S.batch=='Protease_split42')&(S.setting==setting)].set_index('model');b=S[(S.batch=='Protease_split2026')&(S.setting==setting)].set_index('model');t=kendalltau(a.C_index_mean,b.C_index_mean,method='exact');rankrows.append(dict(batch='Protease_cross_split',comparison=setting,tau=t.statistic,p=t.pvalue))
pd.DataFrame(rankrows).to_csv(O/'rank_correlations.csv',index=False)
print('MAX metric delta roundtrip',max(errors));print(S.to_string(index=False));print(pd.DataFrame(rankrows).to_string(index=False));print(pd.DataFrame(counts).drop_duplicates(['batch','setting','partition'],keep='last').to_string(index=False));print('AUDIT',pd.DataFrame(checks).iloc[:,3:].all().to_dict())
