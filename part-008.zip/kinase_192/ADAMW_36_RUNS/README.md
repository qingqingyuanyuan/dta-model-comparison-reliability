# New matched AdamW36

36 runs =2 models ×2 datasets ×3 frozen regimes ×3 model seeds42/123/2026,18 per worker. Actual checkpoint metadata records AdamW/torch.optim.AdamW, lr0.001, wd1e-5, batch64, maximum200epochs, patience30 and clip5.0. Model parameter counts are598,497 and581,953.

Received weights, epoch histories, training/evaluation JSON and original handover receipts are byte-identical. RUN_INDEX maps them to108 prediction-only exports. Original receipts hash privately retained original labeled CSVs; the public manifest hashes the projections. The two checksums are not substituted for one another. Source-file linkage was checked against the actual full private files during building.

Verification uses a restricted metadata/tensor-shape reader without importing torch or executing arbitrary pickle globals. Numerical replay checks864 values. This does not claim retraining, inference or independent reconstruction of historical held-out-test access.
