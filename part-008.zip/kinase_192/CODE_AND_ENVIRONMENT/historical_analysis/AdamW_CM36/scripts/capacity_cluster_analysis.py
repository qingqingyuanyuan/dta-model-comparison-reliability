"""Conditional shared-cluster bootstrap on unique inputs, not independent splits or seeds."""
from pathlib import Path
import argparse,zipfile,importlib.util,json,itertools,hashlib
import numpy as np
import pandas as pd
from scipy.stats import rankdata
KEY=['Canonical SMILES','Target Sequence'];SEEDS=[42,123,2026]
MODELS=['concat','product','attention','deepdta_style','graphdta_gcn_style','deepdta_capacity_matched','graphdta_gcn_capacity_matched']
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--workspace',type=Path,default=Path.cwd());ap.add_argument('--replicates',type=int,default=500);a=ap.parse_args();root=a.workspace.resolve()
 intake=root/'work/cm36_intake_20261110';out=root/'outputs/MD_Revision_20261110/Molecular_Diversity_Revision_Package/04_Verified_Statistics/AdamW_CM36';out.mkdir(parents=True,exist_ok=True)
 sp=importlib.util.spec_from_file_location('trusted_kernel',root/'work/recompute_statistics.py');k=importlib.util.module_from_spec(sp);sp.loader.exec_module(k);cache=intake/'cluster_cache';cache.mkdir(exist_ok=True);ci=k.CIndex(cache);assert k.test_kernel(ci)==36
 z=zipfile.ZipFile(next((root/'upload').glob('03-*.zip')));frozen=pd.read_csv(root/'Molecular_Diversity_Revision_Package/04_Verified_Statistics/Source_Metrics_FINAL126_Frozen.csv');frames={}
 for _,r in frozen[frozen.family!='sensitivity'].iterrows():
  m=r.fusion if r.family=='primary' else r.baseline_name;name=Path(r.unique_input_prediction_file).name;member=next(n for n in z.namelist() if n.endswith(name));frames[r.dataset.lower(),r.setting,m,int(r.model_seed)]=pd.read_csv(z.open(member),float_precision='round_trip').sort_values(KEY).reset_index(drop=True)
 for worker,m in zip(['A','B'],MODELS[-2:]):
  p=intake/worker/'AdamW_CM_Checked_20261108/01-源码/adamw_cm_revision'/('worker_'+worker)/'evaluation_outputs'
  for ds,setting,seed in itertools.product(['kiba','davis'],['warm','cold_target','cold_drug'],SEEDS):
   file=next(p.glob(f'{m}__{ds}_{setting}_seed{seed}*unique_input_predictions.csv'));frames[ds,setting,m,seed]=pd.read_csv(file,float_precision='round_trip').sort_values(KEY).reset_index(drop=True)
 schemes=[(ds,s,ax) for ds in ['kiba','davis'] for s in ['warm','cold_target','cold_drug'] for ax in (['drug','target'] if s=='warm' else ['drug'] if s=='cold_drug' else ['target'])];summ=[];pairs=[];rep=[];loo=[];protocol=[];diagnostic=[]
 for sid,(ds,setting,axis) in enumerate(schemes):
  base=frames[ds,setting,'concat',42];y=base.Label_raw.to_numpy();pred=[]
  for model,seed in itertools.product(MODELS,SEEDS):
   q=frames[ds,setting,model,seed];assert q[KEY].equals(base[KEY]);assert np.allclose(q.Label_raw,y,atol=1e-12,rtol=0);pred.append(q.Prediction_raw.to_numpy())
  pred=np.array(pred).T;prepared=ci.prepare(y,pred);point=ci.calc(prepared).reshape(7,3);err=(pred-y[:,None])**2
  ids=np.unique(base[KEY[0] if axis=='drug' else KEY[1]],return_inverse=True)[1];g=int(ids.max()+1);rng=np.random.default_rng(np.random.SeedSequence([20261110,sid]));draws=np.empty((a.replicates,7,3));errors=np.empty_like(draws)
  for b in range(a.replicates):
   counts=np.bincount(rng.integers(0,g,g),minlength=g);w=counts[ids].astype(float);cv=ci.calc(prepared,w).reshape(7,3);rm=np.sqrt(np.sum(err*w[:,None],axis=0)/w.sum()).reshape(7,3);draws[b]=cv;errors[b]=rm
   for mi,m in enumerate(MODELS):
    for sj,seed in enumerate(SEEDS):rep.append(dict(dataset=ds,setting=setting,axis=axis,replicate=b+1,model=m,seed=seed,cindex=cv[mi,sj],rmse_raw=rm[mi,sj],multiplicity_sha256=hashlib.sha256(counts.astype('<i8').tobytes()).hexdigest()))
  means=draws.mean(axis=2);ranks=rankdata(-means,axis=1,method='average')
  for mi,m in enumerate(MODELS):summ.append(dict(dataset=ds,setting=setting,axis=axis,model=m,n_clusters=g,point=point[mi].mean(),lower=np.quantile(means[:,mi],.025),upper=np.quantile(means[:,mi],.975),mean_rank=ranks[:,mi].mean(),rank_lower=np.quantile(ranks[:,mi],.025),rank_upper=np.quantile(ranks[:,mi],.975),p_rank1=np.mean(ranks[:,mi]==1)))
  contrasts=[(m,b) for m in MODELS[:3] for b in MODELS[-2:]]+list(zip(MODELS[-2:],MODELS[3:5]))
  for m,b in contrasts:
   i=MODELS.index(m);j=MODELS.index(b)
   for metric,arr,pt in [('cindex',draws,point),('rmse_raw',errors,np.sqrt(np.mean(err,axis=0)).reshape(7,3))]:
    for sj,seed in [(-1,'mean_of_three'),*enumerate(SEEDS)]:
     v=(arr[:,i,:]-arr[:,j,:]).mean(axis=1) if sj==-1 else arr[:,i,sj]-arr[:,j,sj];pv=float((pt[i]-pt[j]).mean() if sj==-1 else pt[i,sj]-pt[j,sj]);pairs.append(dict(dataset=ds,setting=setting,axis=axis,n_clusters=g,model_a=m,model_b=b,metric=metric,seed=seed,difference='A minus B',point=pv,lower=np.quantile(v,.025),upper=np.quantile(v,.975),bootstrap_mean=v.mean(),valid_replicates=np.isfinite(v).sum()))
  if setting!='warm':
   for left in range(g):
    cv=ci.calc(prepared,(ids!=left).astype(float)).reshape(7,3);rr=rankdata(-cv,axis=0,method='average')
    for mi,m in enumerate(MODELS):
     for sj,seed in enumerate(SEEDS):loo.append(dict(dataset=ds,setting=setting,axis=axis,left_out_cluster=left,model=m,seed=seed,cindex=cv[mi,sj],rank=rr[mi,sj]))
  protocol.append(dict(dataset=ds,setting=setting,axis=axis,clusters=g,replicates=a.replicates,seed_entropy=[20261110,sid],all_finite=bool(np.isfinite(draws).all())));print(ds,setting,axis,g,'done',flush=True)
 for name,rows in [('CM_Cluster_Bootstrap_Ranks',summ),('CM_Paired_Cluster_Bootstrap',pairs),('CM_Cluster_Bootstrap_PerSeed_Replicates',rep),('CM_LOO_PerSeed',loo)]:pd.DataFrame(rows).to_csv(out/(name+'.csv'),index=False,float_format='%.17g')
 ld=pd.DataFrame(loo);ld.groupby(['dataset','setting','model']).agg(mean_rank=('rank','mean'),rank_min=('rank','min'),rank_max=('rank','max'),folds=('left_out_cluster','nunique')).to_csv(out/'CM_LOO_Summary.csv')
 (out/'Cluster_Analysis_Protocol.json').write_text(json.dumps(dict(schemes=protocol,scope='Unique inputs with raw median labels and raw mean predictions. Three fixed per-seed metrics averaged within shared entity resamples; no seed resampling, no independent split or multiplicity correction. Warm axes are separate one-way analyses. Raw-label C-index may differ at floating-point ties from normalized formal C-index.',kernel_reference_cases=36),indent=2))
if __name__=='__main__':main()
