#!/usr/bin/env python3
"""Recompute statistics from frozen uploaded artifacts; never trains or edits inputs.
Requires Python 3, numpy, pandas, scipy, python-docx and g++ (for a small C++ kernel).
Run: python recompute_statistics.py --source-dir /path/to/originals --output-dir /path/to/results
The predictor ZIP contains UNIQUE-INPUT predictions, not original record predictions.
New bootstrap/LOO results therefore use unique inputs (median label, mean prediction).
"""
from pathlib import Path
import argparse, hashlib, json, zipfile, shutil, subprocess, ctypes, itertools, re, sys
import numpy as np
import pandas as pd
from scipy.stats import rankdata, kendalltau
from docx import Document

MODELS=['concat','product','attention','deepdta_style','graphdta_gcn_style']
LABELS=dict(zip(MODELS,['ConcatFusion','ProductFusion','AttentionFusion','DeepDTA-style','GraphDTA-GCN-style']))
KEY=['Canonical SMILES','Target Sequence']
SEEDS=[42,123,2026]
SETTINGS=['warm','cold_target','cold_drug']
PAIRS=list(itertools.combinations(SETTINGS,2))

def sha(p):
    with open(p,'rb') as h:return hashlib.file_digest(h,'sha256').hexdigest()

class CIndex:
    def __init__(self,folder):
        cpp=Path(__file__).with_name('weighted_cindex.cpp');lib=folder/'weighted_cindex.so'
        subprocess.run(['g++','-O3','-shared','-fPIC','-std=c++17',str(cpp),'-o',str(lib)],check=True)
        self.lib=ctypes.CDLL(str(lib));self.fn=self.lib.weighted_ci
        vec=np.ctypeslib.ndpointer(np.float64,flags='C_CONTIGUOUS');rnk=np.ctypeslib.ndpointer(np.int32,flags='C_CONTIGUOUS')
        self.fn.argtypes=[ctypes.c_int,vec,rnk,vec];self.fn.restype=ctypes.c_double
    def prepare(self,y,p):
        order=np.argsort(y,kind='stable');y=np.ascontiguousarray(np.asarray(y)[order],dtype=np.float64)
        p=np.asarray(p)[order];p=p[:,None] if p.ndim==1 else p
        ranks=[np.ascontiguousarray(np.unique(p[:,i],return_inverse=True)[1]+1,dtype=np.int32) for i in range(p.shape[1])]
        return order,y,ranks
    def calc(self,prepared,w=None):
        order,y,ranks=prepared;w=np.ones(len(y)) if w is None else np.asarray(w)[order]
        w=np.ascontiguousarray(w,dtype=np.float64)
        return np.array([self.fn(len(y),y,r,w) for r in ranks])
    def direct(self,y,p,w=None):return self.calc(self.prepare(y,p),w)

def reference_ci(y,p,w):
    num=den=0.
    for i in range(len(y)):
        for j in range(i):
            if y[i]==y[j]:continue
            den+=w[i]*w[j];v=np.sign((y[i]-y[j])*(p[i]-p[j]))
            num+=w[i]*w[j]*(1 if v>0 else .5 if v==0 else 0)
    return num/den if den else np.nan

def test_kernel(ci):
    rng=np.random.default_rng(721);count=0
    for n in [4,9,21]:
        for _ in range(12):
            y=rng.integers(0,4,n);p=rng.integers(0,5,n);w=rng.integers(0,4,n)
            a=reference_ci(y,p,w);b=ci.direct(y,p,w)[0]
            assert np.allclose(a,b,equal_nan=True,atol=1e-14);count+=1
    return count

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--replicates',type=int,default=500);ap.add_argument('--rng-seed',type=int,default=20261108);a=ap.parse_args()
    src=a.source_dir;out=a.output_dir;out.mkdir(parents=True,exist_ok=True)
    cache=out/'_runtime_cache';cache.mkdir(parents=True,exist_ok=True)
    ci=CIndex(cache);checks={'kernel_reference_cases':test_kernel(ci)}
    originals=[p for p in src.iterdir() if p.is_file()]
    pd.DataFrame([dict(filename=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in originals]).to_csv(out/'Source_File_Manifest.csv',index=False)
    candidates=sorted(p for p in src.glob('FINAL126_RAW_METRICS*.csv'))
    assert len(candidates)>=1
    f=pd.read_csv(candidates[0]);checks['formal_metrics_copies_byte_identical']=all(sha(p)==sha(candidates[0]) for p in candidates)
    assert len(f)==126 and f.family.value_counts().to_dict()=={'primary':54,'baseline':36,'sensitivity':36}
    f['model_key']=np.where(f.family=='primary',f.fusion,np.where(f.family=='baseline',f.baseline_name,f.sensitivity_name))
    f['dataset_key']=f.dataset.str.lower()
    assert not f.duplicated(['dataset_key','setting','model_key','model_seed']).any()
    checks['scaler_methods']=sorted(f['scaler.method'].unique().tolist());checks['scaler_fit_on']=sorted(f['scaler.fit_on'].unique().tolist())
    shutil.copyfile(candidates[0],out/'Source_Metrics_FINAL126_Frozen.csv')
    summary_cols={'record_level_metrics.ci':'cindex','record_level_metrics.rmse_raw':'rmse_raw','record_level_metrics.mse_raw':'mse_raw','record_level_metrics.mae_raw':'mae_raw'}
    rec=f[['dataset_key','setting','family','model_key','model_seed','test_samples',*summary_cols]].rename(columns={'dataset_key':'dataset',**summary_cols}).copy()
    rec['rank_within_original_five']=np.nan
    ix=rec.family!='sensitivity';rec.loc[ix,'rank_within_original_five']=rec[ix].groupby(['dataset','setting','model_seed']).cindex.rank(ascending=False,method='average')
    rec.to_csv(out/'Verified_Record_Cindex_All126.csv',index=False,float_format='%.15g')
    p=rec[ix].pivot(index=['dataset','setting','model_seed'],columns='model_key',values='cindex')[MODELS].reset_index()
    p.to_csv(out/'Verified_Primary_PerSeed_Record_Cindex.csv',index=False,float_format='%.15g')
    mean=rec.groupby(['dataset','setting','model_key'])[['cindex','rmse_raw','mse_raw','mae_raw']].agg(['mean','std'])
    mean.columns=['_'.join(x) for x in mean.columns];mean.reset_index().to_csv(out/'Verified_Record_Mean_SD.csv',index=False,float_format='%.15g')
    old=next(src.glob('primary_per_seed_record_ci*.csv'));od=pd.read_csv(old)
    d=p.merge(od,on=['dataset','setting','model_seed'],suffixes=('_formal','_provided'),validate='one_to_one')
    diffs=[]
    for _,row in d.iterrows():
        for model in MODELS:
            delta=row[model+'_formal']-row[model+'_provided']
            diffs.append(dict(dataset=row.dataset,setting=row.setting,seed=row.model_seed,model=model,formal_cindex=row[model+'_formal'],provided_cindex=row[model+'_provided'],difference=delta,agrees=abs(delta)<1e-12))
    pd.DataFrame(diffs).to_csv(out/'Provided_Cindex_Comparison.csv',index=False,float_format='%.15g')
    tau=[];variant_rank=[]
    for ds in ['kiba','davis']:
        for mode in ['mean',*SEEDS]:
            sub=rec[(rec.dataset==ds)&ix]
            vals=sub.groupby(['setting','model_key']).cindex.mean().unstack() if mode=='mean' else sub[sub.model_seed==mode].pivot(index='setting',columns='model_key',values='cindex')
            for s1,s2 in PAIRS:
                ranks1=rankdata(-vals.loc[s1,MODELS]);ranks2=rankdata(-vals.loc[s2,MODELS])
                tau.append(dict(dataset=ds,pair=s1+' vs '+s2,seed=mode,tau=kendalltau(ranks1,ranks2,variant='b').statistic,model_count=5,analysis='original_five',basis='record_level_formal_cindex'))
        for variant in ['drug_pool_mean','protein_len_1000']:
            for mode in ['mean',*SEEDS]:
                sub=rec[(rec.dataset==ds)&(rec.model_key.isin(MODELS+[variant]))]
                vals=sub.groupby(['setting','model_key']).cindex.mean().unstack() if mode=='mean' else sub[sub.model_seed==mode].pivot(index='setting',columns='model_key',values='cindex')
                selected=[variant]+MODELS[1:]
                for s1,s2 in PAIRS:
                    t=kendalltau(rankdata(-vals.loc[s1,selected]),rankdata(-vals.loc[s2,selected]),variant='b').statistic
                    base=next(x['tau'] for x in tau if x['dataset']==ds and x['seed']==mode and x['pair']==s1+' vs '+s2 and x['analysis']=='original_five')
                    tau.append(dict(dataset=ds,pair=s1+' vs '+s2,seed=mode,tau=t,model_count=5,analysis='replace_concat_with_'+variant,basis='record_level_formal_cindex',original_tau=base,delta_tau=t-base))
                for s in SETTINGS:
                    for m,r in zip(MODELS+[variant],rankdata(-vals.loc[s,MODELS+[variant]])):
                        variant_rank.append(dict(dataset=ds,setting=s,seed=mode,variant=variant,model=m,cindex=vals.loc[s,m],rank_of_six=r))
    td=pd.DataFrame(tau);td.to_csv(out/'Verified_Kendall_Tau_All.csv',index=False,float_format='%.15g')
    pd.DataFrame(variant_rank).to_csv(out/'Verified_Variant_Joint_Ranks.csv',index=False,float_format='%.15g')
    oldtau=pd.read_csv(next(src.glob('per_seed_tau_corrected*.csv')));tc=td[(td.analysis=='original_five')&(td.seed!='mean')].copy();tc.seed=tc.seed.astype(int)
    tc=tc.merge(oldtau,on=['dataset','pair','seed'],suffixes=('_formal','_provided'),validate='one_to_one');tc['difference']=tc.tau_formal-tc.tau_provided
    tc.to_csv(out/'Provided_Tau_Comparison.csv',index=False,float_format='%.15g')
    print('Formal rankings and tau completed',flush=True)
    zin=zipfile.ZipFile(next(src.glob('05-*.zip')));zp=zipfile.ZipFile(next(src.glob('03-*.zip')))
    testsets={};audit=[];composition=[];entity_label_stats=[]
    for ds in ['KIBA','DAVIS']:
        for setting in SETTINGS:
            parts={};rawhash={}
            for split in ['train','val','test']:
                nm=next(n for n in zin.namelist() if '/data-final-' in n and n.endswith(f'{ds}/{setting}/{split}.csv'))
                raw=zin.read(nm);rawhash[split]=hashlib.sha256(raw).hexdigest()
                import io
                parts[split]=pd.read_csv(io.BytesIO(raw))
            train=parts['train'];scmin=train.Label.min();scmax=train.Label.max()
            for split,data in parts.items():
                delta=np.max(np.abs((data.Label-scmin)/(scmax-scmin)-data.Label_norm))
                audit.append(dict(dataset=ds.lower(),setting=setting,partition=split,n=len(data),unique_inputs=len(data.drop_duplicates(KEY)),unique_drugs=data[KEY[0]].nunique(),unique_full_sequences=data[KEY[1]].nunique(),sha256=rawhash[split],scaler_min=scmin,scaler_max=scmax,max_scaler_discrepancy=delta))
            for x,y in itertools.combinations(['train','val','test'],2):
                assert not (set(map(tuple,parts[x][KEY].values)) & set(map(tuple,parts[y][KEY].values)))
                if setting=='cold_drug':assert not(set(parts[x][KEY[0]])&set(parts[y][KEY[0]]))
                if setting=='cold_target':assert not(set(parts[x][KEY[1]])&set(parts[y][KEY[1]]))
            test=parts['test'];testsets[ds.lower(),setting]=test
            composition.append(dict(dataset=ds.lower(),setting=setting,records=len(test),unique_inputs=len(test.drop_duplicates(KEY)),unique_drugs=test[KEY[0]].nunique(),unique_full_sequences=test[KEY[1]].nunique()))
            entity_label_stats.append(dict(dataset=ds.lower(),setting=setting,n=len(test),mean=test.Label.mean(),sd=test.Label.std(),median=test.Label.median(),minimum=test.Label.min(),maximum=test.Label.max()))
    pd.DataFrame(audit).to_csv(out/'Verified_Partition_Audit.csv',index=False,float_format='%.15g')
    pd.DataFrame(composition).to_csv(out/'Verified_Test_Composition.csv',index=False)
    pd.DataFrame(entity_label_stats).to_csv(out/'Verified_Test_Label_Statistics.csv',index=False,float_format='%.15g')
    unique_metrics=[];reconstructed=[];frames={};structure=[];table_audit=[]
    for _,row in f.iterrows():
        basename=Path(row.unique_input_prediction_file).name
        folder={'primary':'/主模型-','baseline':'/基线-','sensitivity':'/敏感性-'}[row.family]
        matches=[n for n in zp.namelist() if folder in n and n.endswith(basename)]
        assert len(matches)==1,(basename,matches)
        nm=matches[0]
        pred=pd.read_csv(zp.open(nm));assert not pred.duplicated(KEY).any()
        ds=row.dataset_key;setting=row.setting;test=testsets[ds,setting]
        lab=test.groupby(KEY,sort=True,as_index=False).agg(label_median=('Label','median'),record_count=('Label','size'))
        q=lab.merge(pred,on=KEY,validate='one_to_one',how='outer',indicator=True)
        assert (q._merge=='both').all();assert np.allclose(q.Label_raw,q.label_median,atol=1e-12,rtol=0)
        assert (q.RecordCount==q.record_count).all()
        y=q.Label_raw.to_numpy();v=q.Prediction_raw.to_numpy();c=ci.direct(y,v)[0]
        metrics=dict(cindex=c,mse_raw=float(np.mean((v-y)**2)),rmse_raw=float(np.sqrt(np.mean((v-y)**2))),mae_raw=float(np.mean(abs(v-y))))
        for k,vv in metrics.items():
            official='unique_input_level_metrics.'+('ci' if k=='cindex' else k)
            table_audit.append(dict(dataset=ds,setting=setting,model=row.model_key,seed=row.model_seed,metric=k,recomputed=vv,formal=row[official],difference=vv-row[official]))
        unique_metrics.append(dict(dataset=ds,setting=setting,model=row.model_key,family=row.family,seed=row.model_seed,n=len(q),**metrics))
        spread=float(pred.PredictionSpread_norm.max()) if 'PredictionSpread_norm' in pred else None
        structure.append(dict(file=basename,dataset=ds,setting=setting,model=row.model_key,seed=row.model_seed,n_unique=len(pred),recordcount_sum=int(pred.RecordCount.sum()),max_prediction_spread_norm=spread,baseline_spread_field_missing=spread is None))
        # This reconstruction is a diagnostic ONLY. The new bootstrap never uses it.
        join=test.merge(pred[KEY+['Prediction_raw']],on=KEY,validate='many_to_one',how='left')
        rc=ci.direct(join.Label.to_numpy(),join.Prediction_raw.to_numpy())[0]
        reconstructed.append(dict(dataset=ds,setting=setting,model=row.model_key,seed=row.model_seed,reconstructed_cindex=rc,formal_cindex=row['record_level_metrics.ci'],difference=rc-row['record_level_metrics.ci'],prediction_spread_verified=spread==0 if spread is not None else False,note='diagnostic expansion of mean input prediction; not original record prediction file'))
        if row.family!='sensitivity':frames[ds,setting,row.model_key,int(row.model_seed)]=q[KEY+['Label_raw','Prediction_raw','RecordCount']].sort_values(KEY).reset_index(drop=True)
    ud=pd.DataFrame(unique_metrics);ud.to_csv(out/'Verified_UniqueInput_Metrics_All126.csv',index=False,float_format='%.15g')
    pd.DataFrame(table_audit).to_csv(out/'UniqueInput_Recomputation_vs_Formal.csv',index=False,float_format='%.15g')
    pd.DataFrame(structure).to_csv(out/'Prediction_File_Structure_Audit.csv',index=False,float_format='%.15g')
    pd.DataFrame(reconstructed).to_csv(out/'Record_Reconstruction_Diagnostic.csv',index=False,float_format='%.15g')
    ud.groupby(['dataset','setting','model'])[['mse_raw','rmse_raw','mae_raw','cindex']].agg(['mean','std']).to_csv(out/'Verified_UniqueInput_Mean_SD.csv',float_format='%.15g')
    print('126 unique-input files recomputed and input labels checked',flush=True)
    # Preserve all source supplementary tables as auditable CSVs.
    supp=Document(next(src.glob('revised-supplementary*.docx')))
    for i,t in enumerate(supp.tables):
        pd.DataFrame([[c.text for c in r.cells] for r in t.rows[1:]],columns=[c.text for c in t.rows[0].cells]).to_csv(out/f'Original_Table_S{i+1:02d}_Preserved.csv',index=False)
    # VEGFR2 identity obtained from supplied S3 SMILES and full frozen target metadata.
    smi=[r.cells[2].text for r in list(supp.tables[2].rows)[1:]]
    test=testsets['davis','cold_target'];seqs=test[test[KEY[0]].isin(smi)].groupby(KEY[1])[KEY[0]].nunique()
    seqs=seqs[seqs==10].index.tolist();assert len(seqs)>=1
    seqs=[s for s in seqs if test[test[KEY[1]]==s]['Target ID'].nunique()==1 and 'VEGFR2' in str(test[test[KEY[1]]==s]['Target ID'].iloc[0])]
    assert len(seqs)==1;seq=seqs[0];veg=[];veg_preds={}
    for model in MODELS:
        vals=[]
        for seed in SEEDS:
            v=frames['davis','cold_target',model,seed];v=v[v[KEY[1]]==seq].sort_values(KEY[0]);assert len(v)==68
            vals.append(v.Prediction_raw.to_numpy());yy=v.Label_raw.to_numpy()
            for name,mask in [('all68',np.ones(68,bool)),('above5_33',yy>5)]:
                veg.append(dict(model=model,seed=str(seed),subset=name,n=int(mask.sum()),cindex=ci.direct(yy[mask],vals[-1][mask])[0],tau_b=kendalltau(yy[mask],vals[-1][mask],variant='b').statistic,rmse_raw=float(np.sqrt(np.mean((yy[mask]-vals[-1][mask])**2)))))
        pm=np.mean(vals,axis=0);veg_preds[model]=pm
        for name,mask in [('all68',np.ones(68,bool)),('above5_33',yy>5)]:
            observed_top=set(np.argsort(-yy)[:10]);predicted_top=set(np.argsort(-pm)[:10])
            veg.append(dict(model=model,seed='mean_prediction',subset=name,n=int(mask.sum()),cindex=ci.direct(yy[mask],pm[mask])[0],tau_b=kendalltau(yy[mask],pm[mask],variant='b').statistic,rmse_raw=float(np.sqrt(np.mean((yy[mask]-pm[mask])**2))),top10_overlap=len(observed_top&predicted_top) if name=='all68' else np.nan))
    assert (yy==5).sum()==35 and (yy>5).sum()==33
    pd.DataFrame(veg).to_csv(out/'Verified_VEGFR2_Metrics.csv',index=False,float_format='%.15g')
    vv=pd.DataFrame({'Canonical SMILES':v[KEY[0]],'Label_raw':yy,**veg_preds}).sort_values('Label_raw',ascending=False)
    vv.to_csv(out/'Verified_VEGFR2_68_Predictions.csv',index=False,float_format='%.15g')
    # Bootstrap: resample clusters, keep all unique pairs in sampled clusters, same weights for all models/seeds.
    bootstrap=[];pairwise=[];rank_summ=[];loo=[];bootcheck=[]
    schemes=[(ds,s,axis) for ds in ['kiba','davis'] for s in SETTINGS for axis in (['drug','target'] if s=='warm' else ['drug'] if s=='cold_drug' else ['target'])]
    for scheme_id,(ds,setting,axis) in enumerate(schemes):
        base=frames[ds,setting,'concat',42];y=base.Label_raw.to_numpy();n=len(base)
        vals=[]
        for model in MODELS:
            for seed in SEEDS:
                q=frames[ds,setting,model,seed];assert q[KEY].equals(base[KEY]);assert np.array_equal(q.Label_raw.to_numpy(),y)
                vals.append(q.Prediction_raw.to_numpy())
        pred=np.array(vals).T;prepared=ci.prepare(y,pred);err2=(pred-y[:,None])**2;err1=abs(pred-y[:,None])
        clusters=np.unique(base[KEY[0] if axis=='drug' else KEY[1]],return_inverse=True)[1];g=int(clusters.max()+1)
        seed_sequence=np.random.SeedSequence([a.rng_seed,scheme_id]);rng=np.random.default_rng(seed_sequence)
        ci_reps=np.empty((a.replicates,5,3));rmse_reps=np.empty_like(ci_reps)
        for b in range(a.replicates):
            counts=np.bincount(rng.integers(0,g,g),minlength=g);weights=counts[clusters].astype(float)
            cv=ci.calc(prepared,weights).reshape(5,3);rv=np.sqrt(np.sum(err2*weights[:,None],axis=0)/weights.sum()).reshape(5,3)
            av=(np.sum(err1*weights[:,None],axis=0)/weights.sum()).reshape(5,3)
            ci_reps[b]=cv;rmse_reps[b]=rv;means=cv.mean(axis=1);ranks=rankdata(-means,method='average')
            digest=hashlib.sha256(counts.astype('<i8').tobytes()).hexdigest()
            for mi,model in enumerate(MODELS):bootstrap.append(dict(dataset=ds,setting=setting,cluster_axis=axis,replicate=b+1,n_clusters=g,n_unique_rows_sampled=int(weights.sum()),model=model,cindex_seed_mean=means[mi],rmse_raw_seed_mean=rv[mi].mean(),mae_raw_seed_mean=av[mi].mean(),rank_by_mean_cindex=ranks[mi],cluster_multiplicity_sha256=digest))
        cr=ci_reps.mean(axis=2);rr=rankdata(-cr,axis=1,method='average')
        for mi,model in enumerate(MODELS):
            rank_summ.append(dict(dataset=ds,setting=setting,cluster_axis=axis,model=model,n_clusters=g,n_unique_inputs=n,replicates=a.replicates,cindex_point=float(ci.calc(prepared).reshape(5,3)[mi].mean()),cindex_lower=np.nanquantile(cr[:,mi],.025),cindex_upper=np.nanquantile(cr[:,mi],.975),mean_rank=rr[:,mi].mean(),rank_lower=np.quantile(rr[:,mi],.025),rank_upper=np.quantile(rr[:,mi],.975),rank_min=rr[:,mi].min(),rank_max=rr[:,mi].max(),p_rank1=np.mean(rr[:,mi]==1),fixed_training_seeds=3))
        for mi,mj in itertools.combinations(range(5),2):
            for metric,arr in [('cindex',ci_reps),('rmse_raw',rmse_reps)]:
                for seed_index,seed in [(-1,'mean_of_three'),*enumerate(SEEDS)]:
                    aa=arr.mean(axis=2) if seed_index==-1 else arr[:,:,seed_index]
                    dv=aa[:,mi]-aa[:,mj];valid=np.isfinite(dv)
                    pairwise.append(dict(dataset=ds,setting=setting,cluster_axis=axis,n_clusters=g,metric=metric,seed=seed,model_a=MODELS[mi],model_b=MODELS[mj],difference='A minus B',delta_bootstrap_mean=np.nanmean(dv),delta_lower=np.nanquantile(dv,.025),delta_upper=np.nanquantile(dv,.975),p_delta_gt_zero=np.mean(dv[valid]>0),p_delta_eq_zero=np.mean(dv[valid]==0),valid_replicates=int(valid.sum()),replicates=a.replicates))
        bootcheck.append(dict(dataset=ds,setting=setting,axis=axis,clusters=g,seed_entropy=[a.rng_seed,scheme_id],nonfinite_cindex=int((~np.isfinite(ci_reps)).sum())))
        if setting!='warm':
            for leave in range(g):
                weights=(clusters!=leave).astype(float);cv=ci.calc(prepared,weights).reshape(5,3)
                rr=rankdata(-cv,axis=0,method='average');rm=rankdata(-cv.mean(axis=1),method='average')
                for mi,model in enumerate(MODELS):
                    for sj,seed in enumerate(SEEDS):loo.append(dict(dataset=ds,setting=setting,cluster_axis=axis,left_out_cluster=leave,model=model,seed=seed,cindex=cv[mi,sj],rank=rr[mi,sj],mean_seed_cindex=cv[mi].mean(),rank_by_mean_seed_cindex=rm[mi]))
        print(f'Bootstrap {ds} {setting} {axis}: {g} clusters, {a.replicates} replicates done',flush=True)
    pd.DataFrame(bootstrap).to_csv(out/'Cluster_Bootstrap_Replicate_Means.csv',index=False,float_format='%.15g')
    pd.DataFrame(rank_summ).to_csv(out/'Cluster_Bootstrap_Rank_Summary.csv',index=False,float_format='%.15g')
    pd.DataFrame(pairwise).to_csv(out/'Cluster_Bootstrap_Paired_Differences.csv',index=False,float_format='%.15g')
    ld=pd.DataFrame(loo);ld.to_csv(out/'UniqueInput_LOO_PerSeed.csv',index=False,float_format='%.15g')
    ls=ld.groupby(['dataset','setting','model']).agg(mean_rank=('rank','mean'),rank_min=('rank','min'),rank_max=('rank','max'),mean_cindex=('cindex','mean'),folds=('left_out_cluster','nunique'))
    ls.to_csv(out/'UniqueInput_LOO_Summary.csv',float_format='%.15g')
    checks.update(bootstrap=bootcheck,replicates=a.replicates,rng_seed=a.rng_seed,unique_metric_max_abs_error=float(pd.DataFrame(table_audit).difference.abs().max()),record_diagnostic_max_abs_error=float(pd.DataFrame(reconstructed).difference.abs().max()),source_files=len(originals),prediction_files=126,new_bootstrap_reporting_level='unique-input; three fixed training seeds averaged within each resample; no seed resampling',python=sys.version,numpy=np.__version__,pandas=pd.__version__)
    (out/'Recomputation_Checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
    print(json.dumps(checks,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':main()
