"""Re-run the read-only audit and optional 500-replicate analysis from this package.
Linux, Python with numpy/pandas/scipy/python-docx, and g++ are required.
No torch, GPU, training, or network access is used.
"""
from pathlib import Path
import argparse,tempfile,shutil,subprocess,sys
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--package',type=Path,default=Path(__file__).resolve().parents[3]);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--bootstrap',action='store_true');a=ap.parse_args();p=a.package.resolve();out=a.output.resolve();assert not out.exists(),'Choose a new output directory to preserve prior results.'
 with tempfile.TemporaryDirectory(prefix='dta_verified_') as td:
  r=Path(td);scripts=p/'04_Verified_Statistics/AdamW_CM36/scripts';project=p/'06_Reproducibility/AdamW_CM_Checked_20261108'
  def link(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);dst.symlink_to(src, target_is_directory=src.is_dir())
  link(project,r/'AdamW_CM_Checked_20261108');link(p/'04_Verified_Statistics/Frozen126',r/'Molecular_Diversity_Revision_Package/04_Verified_Statistics')
  for w in ['A','B']:link(project,r/'work/cm36_intake_20261110'/w/'AdamW_CM_Checked_20261108')
  for name in ['recompute_statistics.py','weighted_cindex.cpp']:link(scripts/name,r/'work'/name)
  for f in (p/'06_Reproducibility/Original_Inputs').iterdir():link(f,r/'upload'/f.name)
  q=r/'work/cm36_intake_20261110/Archive_Integrity.json';shutil.copy2(p/'04_Verified_Statistics/AdamW_CM36/Archive_Integrity.json',q)
  subprocess.run([sys.executable,str(scripts/'audit_adamw36.py'),'--workspace',str(r)],check=True)
  if a.bootstrap:subprocess.run([sys.executable,str(scripts/'capacity_cluster_analysis.py'),'--workspace',str(r)],check=True)
  result=r/'outputs/MD_Revision_20261110/Molecular_Diversity_Revision_Package/04_Verified_Statistics/AdamW_CM36';shutil.copytree(result,out)
 print('Saved independently recalculated files:',out)
if __name__=='__main__':main()
