"""Independent artifact and metric audit; never imports received training code or runs inference."""
from pathlib import Path
import argparse, importlib.util, json, hashlib, shutil, itertools, math
import numpy as np
import pandas as pd
from scipy.stats import kendalltau

def sha(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load_module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workspace',type=Path,default=Path.cwd());a=ap.parse_args();root=a.workspace.resolve()
    intake=root/'work/cm36_intake_20261110';pkg=root/'outputs/MD_Revision_20261110/Molecular_Diversity_Revision_Package';out=pkg/'04_Verified_Statistics/AdamW_CM36';out.mkdir(parents=True,exist_ok=True)
    old=root/'Molecular_Diversity_Revision_Package/04_Verified_Statistics';frozen=old/'Source_Metrics_FINAL126_Frozen.csv';before=sha(frozen)
    h=load_module('checked_handover',root/'AdamW_CM_Checked_20261108/handover_checked.py')
    kernel=load_module('trusted_statistics',root/'work/recompute_statistics.py');cache=intake/'ci_cache';cache.mkdir(exist_ok=True);ci=kernel.CIndex(cache);assert kernel.test_kernel(ci)==36
    rows=[];comparisons=[];metrics=[];checkpoints=[];filehashes=[];guards=[];tensors=[]
    def metric(yn,pn,sc):
        yn=np.asarray(yn,dtype='float64');pn=np.asarray(pn,dtype='float64');y=yn*sc['range']+sc['min'];p=pn*sc['range']+sc['min']
        return dict(ci=float(ci.direct(yn,pn)[0]),mse_norm=float(np.mean((yn-pn)**2)),rmse_norm=float(np.sqrt(np.mean((yn-pn)**2))),mae_norm=float(np.mean(abs(yn-pn))),mse_raw=float(np.mean((y-p)**2)),rmse_raw=float(np.sqrt(np.mean((y-p)**2))),mae_raw=float(np.mean(abs(y-p))),scaler_range=sc['range'])
    for worker in ['A','B']:
        pr=intake/worker/'AdamW_CM_Checked_20261108';h.ROOT=pr;h.SRC=pr/'01-源码';h.RESULTS=h.SRC/'adamw_cm_revision'
        # Compare every supplied immutable handover file with the local trusted package.
        for line in (root/'AdamW_CM_Checked_20261108/MANIFEST-sha256.txt').read_text().splitlines():
            expected,rel=line.split('  ',1);assert sha(pr/rel)==expected,rel
        manifest=h.data_check(pr/'data_final',True)
        for p in (intake/worker).rglob('*'):
            if p.is_file():filehashes.append(dict(worker=worker,path=str(p.relative_to(intake/worker)),bytes=p.stat().st_size,sha256=sha(p)))
        expected=[r for r in h.expected_rows() if r['worker']=='worker_'+worker]
        for r in expected:
            state=h.training_status(r,manifest);assert state['status']=='COMPATIBLE_COMPLETE',state
            h.evaluation_receipt(r,manifest);paths=h.paths(r);_,_,ef=h.evaluation_files(r)
            e=json.loads(ef['metadata'].read_text());t=json.loads(paths['training'].read_text());ck=h.read_checkpoint_metadata(paths['checkpoint']);sc=e['scaler']
            assert e['experiment_family']==h.FAMILY and e['optimizer_implementation']=='torch.optim.AdamW'
            test=pd.read_csv(pr/'data_final'/r['dataset']/r['setting']/'test.csv');val=pd.read_csv(pr/'data_final'/r['dataset']/r['setting']/'val.csv');rec=pd.read_csv(ef['record'],float_precision='round_trip').sort_values('TestRowIndex').reset_index(drop=True);u=pd.read_csv(ef['unique'],float_precision='round_trip');v=pd.read_csv(paths['validation'],float_precision='round_trip')
            assert len(test)==len(rec) and len(val)==len(v)
            for original,pred in [(test,rec),(val,v)]:
                for k in original.columns.intersection(pred.columns):
                    if pd.api.types.is_numeric_dtype(original[k]):assert np.allclose(original[k],pred[k],rtol=0,atol=1e-12,equal_nan=True),(r,k)
                    else:assert original[k].fillna('').astype(str).equals(pred[k].fillna('').astype(str)),(r,k)
            key=['Canonical SMILES','Target Sequence'];rec['Prediction_norm']=rec.Prediction_norm.astype('float32')
            g=rec.groupby(key,sort=True).agg(Label_raw=('Label','median'),Label_norm=('Label_norm','median'),Prediction_norm=('Prediction_norm','mean'),Prediction_raw=('Prediction_raw','mean'),RecordCount=('Label','size')).reset_index();us=u.sort_values(key).reset_index(drop=True)
            assert g[key].equals(us[key])
            for k in ['Label_raw','Label_norm','Prediction_raw','RecordCount']:assert np.allclose(g[k],us[k],atol=1e-12,rtol=0),(r,k)
            assert np.array_equal(g.Prediction_norm.to_numpy(),us.Prediction_norm.to_numpy(dtype='float32'))
            for level,frame,recorded in [('record',rec,e['record_level_metrics']),('unique_input',u,e['unique_input_level_metrics']),('validation',v,t['validation_metrics'])]:
                yn=frame.Label_norm.to_numpy(dtype='float64' if level=='unique_input' else 'float32');pn=frame.Prediction_norm.to_numpy(dtype='float32');m=metric(yn,pn,sc)
                assert len(frame)==recorded['n']
                for k,z in m.items():
                    d=z-recorded[k];comparisons.append(dict(stem=r['stem'],level=level,metric=k,reported=recorded[k],recomputed=z,difference=d));assert abs(d)<1e-12,(r,level,k,d)
                metrics.append(dict(dataset=r['dataset'].lower(),setting=r['setting'],model=r['baseline'],seed=r['seed'],level=level,n=len(frame),**m))
            c=dict(dataset=r['dataset'].lower(),setting=r['setting'],model=r['baseline'],seed=r['seed'],parameters=ck['parameter_summary']['total'],best_epoch=ck['best_epoch'],stop_epoch=ck['stop_epoch'],optimizer=ck['config']['TRAINING']['optimizer'],optimizer_implementation=e['optimizer_implementation'],checkpoint_sha256=sha(paths['checkpoint']))
            checkpoints.append(c);rows.append(dict(**r,status=state['status'],receipt_verified=True,test_rows=len(rec),unique_inputs=len(u),validation_rows=len(v)))
            for name,ten in ck['model_state_dict'].items():tensors.append(dict(stem=r['stem'],name=name,shape=str(ten.shape),elements=math.prod(ten.shape)))
        guards.append(dict(worker=worker,source_manifest_matches=True,frozen_inputs_match=True,complete_runs=len(expected)))
    assert len(rows)==36 and len({r['stem'] for r in rows})==36 and len(comparisons)==864
    for name,data in [('Run_Checks',rows),('Metric_Comparison',comparisons),('Recomputed_Metrics',metrics),('Checkpoint_Metadata',checkpoints),('Checkpoint_Tensor_Shapes',tensors),('All_Received_File_Hashes',filehashes),('Guard_Audit',guards)]:pd.DataFrame(data).to_csv(out/(name+'.csv'),index=False,float_format='%.17g')
    rec=pd.DataFrame(metrics).query('level=="record"').rename(columns={'seed':'model_seed','model':'model_key','ci':'cindex'});rec.to_csv(out/'Verified_CM36_Record_Per_Run.csv',index=False)
    unique=pd.DataFrame(metrics).query('level=="unique_input"');unique.to_csv(out/'Verified_CM36_UniqueInput_Per_Run.csv',index=False)
    original=pd.read_csv(old/'Verified_Record_Cindex_All126.csv');full=pd.concat([original,rec],ignore_index=True);full.to_csv(out/'Combined_Record_Metrics_162.csv',index=False)
    summary=full.groupby(['dataset','setting','model_key'])[['cindex','mse_raw','rmse_raw','mae_raw']].agg(['mean','std']);summary.columns=['_'.join(x) for x in summary.columns];summary.reset_index().to_csv(out/'Verified_Seven_Model_Mean_SD.csv',index=False)
    sets={'original_five':['concat','product','attention','deepdta_style','graphdta_gcn_style'],'capacity_replacement':['concat','product','attention',*h.BASELINES],'all_seven':['concat','product','attention','deepdta_style','graphdta_gcn_style',*h.BASELINES]};tau=[];ranks=[];delta=[]
    for ds,setting in itertools.product(['kiba','davis'],['warm','cold_drug','cold_target']):
        p=full[(full.dataset==ds)&(full.setting==setting)].pivot(index='model_seed',columns='model_key',values='cindex')
        for b,o in zip(h.BASELINES,['deepdta_style','graphdta_gcn_style']):delta.append(dict(dataset=ds,setting=setting,baseline=b,mean_delta=float((p[b]-p[o]).mean()),sd_delta=float((p[b]-p[o]).std())))
    for ds,(name,models),seed in itertools.product(['kiba','davis'],sets.items(),['mean',42,123,2026]):
        sub=full[(full.dataset==ds)&full.model_key.isin(models)];p=sub.groupby(['setting','model_key']).cindex.mean().unstack() if seed=='mean' else sub[sub.model_seed==seed].pivot(index='setting',columns='model_key',values='cindex');rank=p[models].rank(axis=1,ascending=False,method='average')
        for x,y in [('warm','cold_target'),('warm','cold_drug'),('cold_target','cold_drug')]:tau.append(dict(dataset=ds,model_set=name,model_count=len(models),seed=seed,pair=x+' vs '+y,tau=kendalltau(rank.loc[x],rank.loc[y]).statistic))
        for setting in p.index:
            for m in models:ranks.append(dict(dataset=ds,setting=setting,model_set=name,seed=seed,model=m,cindex=p.loc[setting,m],rank=rank.loc[setting,m]))
    for name,data in [('Verified_Model_Set_Kendall_Tau',tau),('Verified_Model_Set_Ranks',ranks),('Record_Paired_CM_minus_Original',delta)]:pd.DataFrame(data).to_csv(out/(name+'.csv'),index=False)
    assert sha(frozen)==before
    report=dict(runs=36,complete_per_worker=18,metric_comparisons=len(comparisons),metric_max_absolute_difference=max(abs(x['difference']) for x in comparisons),kernel_reference_cases=36,source126_sha256_before=before,source126_sha256_after=sha(frozen),passed=True,scope='Configuration, restricted checkpoint metadata, file provenance and independent numerical audit. No inference rerun or historical access reconstruction.')
    (out/'Audit_Summary.json').write_text(json.dumps(report,indent=2));shutil.copy2(intake/'Archive_Integrity.json',out/'Archive_Integrity.json');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
