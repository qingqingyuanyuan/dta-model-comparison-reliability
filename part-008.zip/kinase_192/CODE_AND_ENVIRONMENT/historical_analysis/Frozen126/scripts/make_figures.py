#!/usr/bin/env python3
"""Draw deterministic scientific figures from verified frozen statistics."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
from scipy.stats import rankdata
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

MODELS=['concat','product','attention','deepdta_style','graphdta_gcn_style']
LABEL=['ConcatFusion','ProductFusion','AttentionFusion','DeepDTA-style','GraphDTA-GCN-style']
COL=['#318a7e','#cb7718','#4894bf','#636363','#285d99'];MARK=['o','s','^','D','v']
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--statistics-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);a=ap.parse_args();o=a.output_dir;o.mkdir(parents=True,exist_ok=True)
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
 def save(fig,n):
  for ext in ['png','pdf','svg']:fig.savefig(o/f'Fig{n}.{ext}',dpi=400,bbox_inches='tight',facecolor='white')
  plt.close(fig)
 fig=plt.figure(figsize=(7,6.0));ax=fig.add_axes([.02,.02,.96,.96]);ax.set(xlim=(0,100),ylim=(0,100));ax.axis('off')
 def box(x,y,w,h,title,text,fc='#f4f7fa'):
  ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.5,rounding_size=1',lw=.9,edgecolor='#60768a',facecolor=fc))
  ax.text(x+w/2,y+h-2.3,title,ha='center',va='top',weight='bold',fontsize=10)
  ax.text(x+w/2,y+h-6.5,text,ha='center',va='top',fontsize=9,linespacing=1.25)
 def arrow(x,y,u,v):ax.add_patch(FancyArrowPatch((x,y),(u,v),arrowstyle='-|>',mutation_scale=10,color='#60768a',lw=1))
 box(1,86,98,13,'Frozen inputs and evaluation regimes','KIBA 118,036 records · Davis 30,056 records\nWarm · cold-drug (canonical SMILES) · cold-target (full sequence)')
 box(1,64,47,17,'Drug GAT encoder','3 layers · sum pooling\n41-d atoms · 10-d bonds\n128-d global vector + atom tokens')
 box(52,64,47,17,'Protein CNN encoder','Embedding · kernels 3 / 5 / 7\nMasked max · max_len 1,500\n128-d global vector + residue tokens')
 arrow(25,86,25,82);arrow(75,86,75,82)
 ax.text(50,59,'Three alternative models, trained independently',ha='center',weight='bold',fontsize=9)
 box(1,37,30,17,'ConcatFusion','Global concatenation\n256-d projection\n66,304 parameters','#edf6f3')
 box(35,37,30,17,'ProductFusion','Projected product\n128-d → 256-d\n66,560 parameters','#fcf4e8')
 box(69,37,30,17,'AttentionFusion','Atom Q; residue K/V\n4 heads · 80-d internal\n68,288 parameters','#edf4fa')
 for x in [16,50,84]:arrow(x,58,x,55);arrow(x,37,x,33)
 box(1,20,98,12,'Same head specification in each independently trained model','256 → 512 → 256 → 128 → 1 · LayerNorm · ReLU · dropout')
 box(1,1,47,15,'Original training matrix','DeepDTA-style · GraphDTA-GCN-style\nSeeds 42 / 123 / 2026 · same budget\n126 original runs: 54 + 36 + 36')
 box(52,1,47,15,'Frozen test evaluation','C-index and raw-scale errors\nRecord primary · unique-input sensitivity\nFixed predictions for resampling')
 arrow(50,20,50,17)
 save(fig,1)
 f=pd.read_csv(a.statistics_dir/'Verified_Record_Cindex_All126.csv');f=f[f.family!='sensitivity']
 stats=f.groupby(['dataset','setting','model_key'])[['cindex','rmse_raw']].agg(['mean','std'])
 settings=['warm','cold_target','cold_drug'];ticks=['Warm','Cold-target','Cold-drug']
 fig,axs=plt.subplots(2,2,figsize=(7,5.3));fig.subplots_adjust(bottom=.20,hspace=.45,wspace=.33)
 for di,ds in enumerate(['kiba','davis']):
  for qi,metric in enumerate(['rmse_raw','cindex']):
   ax=axs[di,qi];x=np.arange(3)
   for mi,model in enumerate(MODELS):
    mean=[stats.loc[(ds,s,model),(metric,'mean')] for s in settings];sd=[stats.loc[(ds,s,model),(metric,'std')] for s in settings]
    ax.errorbar(x+(mi-2)*.13,mean,yerr=sd,color=COL[mi],marker=MARK[mi],ms=4,lw=1,capsize=2,label=LABEL[mi],linestyle='none')
   ax.set_xticks(x,ticks,fontsize=8);ax.set_ylabel(('KIBA' if ds=='kiba' else 'Davis')+('\nRMSE (raw)' if metric=='rmse_raw' else '\nC-index'));ax.grid(axis='y',alpha=.25)
 axs[0,0].text(-.18,1.02,'a',transform=axs[0,0].transAxes,weight='bold');axs[0,1].text(-.18,1.02,'b',transform=axs[0,1].transAxes,weight='bold');axs[1,0].text(-.18,1.02,'c',transform=axs[1,0].transAxes,weight='bold');axs[1,1].text(-.18,1.02,'d',transform=axs[1,1].transAxes,weight='bold')
 fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=2,frameon=False,fontsize=8.5);save(fig,2)
 fig,axs=plt.subplots(1,2,figsize=(7,3.6));fig.subplots_adjust(bottom=.29,wspace=.22)
 for ax,ds in zip(axs,['kiba','davis']):
  means=f[f.dataset==ds].groupby(['setting','model_key']).cindex.mean().unstack().loc[settings,MODELS]
  ranks=rankdata(-means.to_numpy(),axis=1)
  for mi in range(5):ax.plot(range(3),ranks[:,mi],marker=MARK[mi],color=COL[mi],label=LABEL[mi],lw=1.5)
  ax.set(ylim=(5.3,.7),yticks=range(1,6));ax.set_xticks(range(3),ticks,fontsize=8);ax.grid(axis='y',alpha=.25);ax.text(.04,.98,ds.upper() if ds=='kiba' else 'Davis',transform=ax.transAxes,va='top',weight='bold')
 axs[0].set_ylabel('Rank by three-seed mean C-index')
 fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncol=2,frameon=False,fontsize=8.5);save(fig,3)
 fig,axs=plt.subplots(2,2,figsize=(7,4.8));fig.subplots_adjust(bottom=.22,hspace=.45,wspace=.32)
 for di,ds in enumerate(['kiba','davis']):
  for qi,metric in enumerate(['rmse_raw','cindex']):
   ax=axs[di,qi]
   for mi,model in enumerate(MODELS):
    y=stats.loc[(ds,'cold_drug',model),(metric,'mean')];sd=stats.loc[(ds,'cold_drug',model),(metric,'std')]
    ax.errorbar(mi,y,yerr=sd,color=COL[mi],marker=MARK[mi],lw=1.2,ms=5,capsize=3,label=LABEL[mi])
   ax.set_xticks(range(5),['C','P','A','D','G']);ax.set_ylabel(('KIBA' if ds=='kiba' else 'Davis')+('\nRMSE (raw)' if metric=='rmse_raw' else '\nC-index'));ax.grid(axis='y',alpha=.25)
 fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=2,frameon=False,fontsize=8.5);save(fig,4)
 v=pd.read_csv(a.statistics_dir/'Verified_VEGFR2_68_Predictions.csv').sort_values('Label_raw',ascending=False).reset_index(drop=True)
 vm=pd.read_csv(a.statistics_dir/'Verified_VEGFR2_Metrics.csv');vm=vm[(vm.seed=='mean_prediction')&(vm.subset=='all68')].set_index('model')
 fig,ax=plt.subplots(figsize=(7,4.4));fig.subplots_adjust(bottom=.37)
 x=np.arange(1,11);ax.plot(x,x,'k--',lw=1.1,label='Observed reference')
 for mi,m in enumerate(MODELS):
  ranks=rankdata(-v[m].to_numpy(),method='average')
  ax.plot(x,ranks[:10],color=COL[mi],marker=MARK[mi],lw=1.3,ms=4,label=f'{LABEL[mi]} (τ-b {vm.loc[m,"tau_b"]:.3f}; top-10 {int(vm.loc[m,"top10_overlap"])}/10)')
 ax.set_xticks(x,[f'V{i:02d}' for i in x],fontsize=8);ax.set(ylim=(35,0),yticks=[1,5,10,15,20,25,30,35],ylabel='Predicted rank among 68 compounds',xlabel='Observed top-10 VEGFR2 compounds');ax.grid(alpha=.2)
 fig.legend(*ax.get_legend_handles_labels(),loc='lower center',ncol=1,frameon=False,fontsize=8.5);save(fig,5)
 print('Figures 1–5 exported as PNG, vector PDF and editable SVG')
if __name__=='__main__':main()
