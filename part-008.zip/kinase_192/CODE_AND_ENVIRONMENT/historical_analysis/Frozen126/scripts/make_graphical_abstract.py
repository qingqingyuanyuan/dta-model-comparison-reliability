#!/usr/bin/env python3
"""Precisely drawn graphical abstract using formal mean ranks, with no invented data."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
from scipy.stats import rankdata
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ap=argparse.ArgumentParser();ap.add_argument('--statistics-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none'})
fig=plt.figure(figsize=(10,4));fig.patch.set_facecolor('white')
fig.text(.035,.94,'DTA model rankings vary across evaluation regimes',size=17,weight='bold')
fig.text(.035,.865,'Controlled comparison',size=12,weight='bold',color='#285d99')
fig.text(.035,.79,'KIBA: 118,036 records\nDavis: 30,056 records\n\n126 original frozen runs\n3 paired training seeds\n\nWarm / cold-target / cold-drug\nCanonical SMILES + full sequence',size=10.5,va='top',linespacing=1.45)
ax=fig.add_axes([.35,.29,.32,.49]);f=pd.read_csv(a.statistics_dir/'Verified_Record_Cindex_All126.csv');models=['concat','product','attention','deepdta_style','graphdta_gcn_style'];colors=['#318a7e','#cb7718','#4894bf','#636363','#285d99'];markers=['o','s','^','D','v']
sub=f[(f.dataset=='kiba')&(f.family!='sensitivity')].groupby(['setting','model_key']).cindex.mean().unstack().loc[['cold_target','cold_drug'],models];r=rankdata(-sub.to_numpy(),axis=1)
for j,m in enumerate(models):ax.plot([0,1],r[:,j],color=colors[j],marker=markers[j],lw=2,ms=6,label=['Concat','Product','Attention','DeepDTA-style','GraphDTA-GCN-style'][j])
ax.set_xticks([0,1],['Cold-target','Cold-drug']);ax.set_yticks(range(1,6));ax.set_ylim(5.3,.7);ax.set_ylabel('Mean C-index rank');ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.2)
fig.text(.51,.865,'KIBA mean rankings',ha='center',size=12,weight='bold',color='#285d99');fig.text(.51,.81,'Kendall τ = −1.00',ha='center',size=12,weight='bold')
fig.legend(*ax.get_legend_handles_labels(),loc='lower center',bbox_to_anchor=(.51,.075),ncol=3,frameon=False,fontsize=8.5,columnspacing=1.0,handlelength=1.4)
fig.text(.72,.865,'Uncertainty and scope',size=12,weight='bold',color='#285d99')
fig.text(.72,.79,'Seed-wise τ\n42: −0.60\n123: −0.40\n2026: +0.20\n\nConfiguration changes matter\n\nVEGFR2: 68 benchmark compounds\nPost-hoc ranking for a\ntraining-unseen target',size=10.5,va='top',linespacing=1.4)
fig.text(.035,.03,'One frozen split · entity resampling does not replace independent-split retraining',size=10,color='#4d4d4d')
for ext in ['png','pdf','svg']:fig.savefig(a.output_dir/f'Graphical_Abstract_Revised.{ext}',dpi=400,facecolor='white',bbox_inches='tight',pad_inches=.12)
desc='DTA model rankings vary across regimes and configurations, with seed and entity uncertainty limiting universal model-selection claims.'
(a.output_dir/'Graphical_Abstract_Description.txt').write_text(desc+'\n')
print('Graphical abstract generated with',len(desc.split()),'description words')
