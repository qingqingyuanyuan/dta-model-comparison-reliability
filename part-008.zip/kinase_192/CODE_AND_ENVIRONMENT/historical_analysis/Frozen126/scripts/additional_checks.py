#!/usr/bin/env python3
"""Small deterministic handover checks derived from supplied inputs and completed recomputation."""
from pathlib import Path
import argparse,hashlib,json,re,zipfile,sys
import pandas as pd
import numpy as np
from scipy.stats import rankdata
from docx import Document

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source-dir',type=Path,required=True);ap.add_argument('--statistics-dir',type=Path,required=True);ap.add_argument('--package-dir',type=Path);a=ap.parse_args();s=a.statistics_dir
 f=pd.read_csv(s/'Source_Metrics_FINAL126_Frozen.csv');f['dataset_key']=f.dataset.str.lower();pa=pd.read_csv(s/'Verified_Partition_Audit.csv')
 t=pa[pa.partition=='test'][['dataset','setting','sha256','scaler_min','scaler_max']].rename(columns={'dataset':'dataset_key','sha256':'supplied_test_sha256','scaler_min':'training_min','scaler_max':'training_max'})
 joined=f.merge(t,on=['dataset_key','setting'],validate='many_to_one')
 joined['test_hash_matches_supplied_bytes']=joined.test_csv_sha256==joined.supplied_test_sha256
 joined[['evaluation_file','dataset','setting','test_csv_sha256','supplied_test_sha256','test_hash_matches_supplied_bytes']].to_csv(s/'Verified_Test_Hash_Correspondence.csv',index=False)
 sc=joined[['evaluation_file','dataset','setting','scaler.method','scaler.fit_on','scaler.min','scaler.max','scaler.range','training_min','training_max']].copy();sc['min_matches_training']=np.isclose(sc['scaler.min'],sc.training_min,rtol=0,atol=1e-12);sc['max_matches_training']=np.isclose(sc['scaler.max'],sc.training_max,rtol=0,atol=1e-12);sc['range_matches_training']=np.isclose(sc['scaler.range'],sc.training_max-sc.training_min,rtol=0,atol=1e-12);sc.to_csv(s/'Verified_Scaler_Correspondence.csv',index=False,float_format='%.15g')
 r=pd.read_csv(s/'Verified_Record_Cindex_All126.csv');five=r[r.family!='sensitivity'].copy();five.to_csv(s/'Verified_Record_PerSeed_Ranks_FiveModels.csv',index=False,float_format='%.15g')
 means=five.groupby(['dataset','setting','model_key']).cindex.agg(['mean','std']).reset_index();means['rank_by_three_seed_mean']=means.groupby(['dataset','setting'])['mean'].rank(ascending=False,method='average');means.to_csv(s/'Verified_Record_Mean_Ranks_FiveModels.csv',index=False,float_format='%.15g')
 orders=[]
 for (ds,setting),g in five.groupby(['dataset','setting']):
  ordering=[tuple(z.sort_values('cindex',ascending=False).model_key) for seed,z in g.groupby('model_seed')]
  orders.append(dict(dataset=ds,setting=setting,n_training_seeds=len(ordering),n_distinct_complete_orderings=len(set(ordering))))
 pd.DataFrame(orders).to_csv(s/'Verified_Seed_Order_Diversity.csv',index=False)
 u=pd.read_csv(s/'Verified_UniqueInput_Metrics_All126.csv');pw=pd.read_csv(s/'Cluster_Bootstrap_Paired_Differences.csv')
 for i,row in pw.iterrows():
  g=u[(u.dataset==row.dataset)&(u.setting==row.setting)]
  if row.seed!='mean_of_three':g=g[g.seed==int(row.seed)]
  v=g.groupby('model')[row.metric].mean();pw.loc[i,'delta_observed']=v[row.model_a]-v[row.model_b]
 pw.to_csv(s/'Cluster_Bootstrap_Paired_Differences.csv',index=False,float_format='%.15g')
 old=pd.read_csv(s/'Original_Table_S06_Preserved.csv');new=pd.read_csv(s/'Cluster_Bootstrap_Rank_Summary.csv');labels={'ConcatFusion':'concat','ProductFusion':'product','AttentionFusion':'attention','DeepDTA-style':'deepdta_style','GraphDTA-GCN-style':'graphdta_gcn_style'};rows=[]
 for _,row in old.iterrows():
  ds=row.Dataset.lower();setting=row.Setting.replace('-','_');axis='target' if setting=='cold_target' else 'drug'
  z=new[(new.dataset==ds)&(new.setting==setting)&(new.cluster_axis==axis)&(new.model==labels[row.Model])].iloc[0]
  rows.append(dict(dataset=ds,setting=setting,model=labels[row.Model],original_clustering='drug',new_clustering=axis,original_rank_interval_as_reported=row['Rank interval'],new_rank_percentile_interval=f'{z.rank_lower:g} to {z.rank_upper:g}',original_p_rank1=row['P(rank 1)'],new_p_rank1=z.p_rank1,original_cindex_lower=row['CI 2.5%'],original_cindex_upper=row['CI 97.5%'],new_cindex_lower=z.cindex_lower,new_cindex_upper=z.cindex_upper,note='new: unique inputs, ranks of mean per-seed CI; original RNG/indices/reporting-level/seed-pooling convention not fully documented; changes cannot be attributed only to clustering'))
 pd.DataFrame(rows).to_csv(s/'Bootstrap_Original_vs_New_Comparison.csv',index=False,float_format='%.15g')
 inv=[]
 for archive in a.source_dir.glob('*.zip'):
  z=zipfile.ZipFile(archive)
  for info in z.infolist():
   if not info.is_dir():inv.append(dict(archive=archive.name,member=info.filename,uncompressed_bytes=info.file_size,crc32=f'{info.CRC:08x}'))
 pd.DataFrame(inv).to_csv(s/'Input_Archive_Inventory.csv',index=False)
 z=zipfile.ZipFile(next(a.source_dir.glob('05-*.zip')));upstream=[]
 for ds in ['KIBA','DAVIS']:
  for split in ['train','test']:
   name=next(n for n in z.namelist() if n.endswith(f'/BatchDTA-processed/{ds}/{split}_{ds}_unseenP_seenD.csv'))
   with z.open(name) as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
   upstream.append(dict(dataset=ds,source_partition=split,archive_member=name,bytes=z.getinfo(name).file_size,sha256=digest,upstream_commit='not supplied',download_date='not supplied'))
 pd.DataFrame(upstream).to_csv(s/'Verified_Upstream_Input_File_Hashes.csv',index=False)
 checks={'all_126_test_hashes_match_supplied_bytes':bool(joined.test_hash_matches_supplied_bytes.all()),'all_126_scaler_fields_match_training_labels':bool(sc[['min_matches_training','max_matches_training','range_matches_training']].all().all()),'formal_metric_rows':len(f),'record_rank_rows_for_five_original_models':len(five),'mean_rank_rows':len(means),'new_bootstrap_schemes':8,'new_replicates_per_scheme':500,'new_bootstrap_model_mean_rows':len(pd.read_csv(s/'Cluster_Bootstrap_Replicate_Means.csv')),'paired_summary_rows':len(pw),'new_training_runs_performed_by_analysis_scripts':0}
 if a.package_dir:
  d=Document(a.package_dir/'03_Response/Response_to_Reviewers_Revised.docx');original=Document(next(a.source_dir.glob('revised-manuscript*.docx')));main=Document(a.package_dir/'01_Manuscript/Revised_Manuscript.docx')
  # Compare the 21 comments to the exact text reconstructed from supplied PDF in build workflow.
  comments_json=Path(__file__).parent/'reviewer_comments.json'
  if not comments_json.exists():comments_json=a.package_dir/'05_Audit_and_Handover/Reviewer_Comments_Source.json'
  if comments_json.exists():
   source_comments=json.loads(comments_json.read_text());paras=[p.text for p in d.paragraphs];integrity=[]
   for row in source_comments:integrity.append(dict(reviewer=row['reviewer'],comment=row['comment'],source_comment=row['text'],present_exactly_once=paras.count(row['text'])==1))
   pd.DataFrame(integrity).to_csv(a.package_dir/'05_Audit_and_Handover/Reviewer_Comments_Integrity.csv',index=False);checks['all_21_comments_preserved']=bool(all(x['present_exactly_once'] for x in integrity))
  refs=[];ref_start=next(i for i,p in enumerate(main.paragraphs) if p.text=='References');body=' '.join(p.text for p in main.paragraphs[:ref_start]);cited=set()
  for group in re.findall(r'\[([\d,\s–-]+)\]',body):
   for item in group.split(','):
    ns=re.findall(r'\d+',item)
    if len(ns)==2:cited.update(range(int(ns[0]),int(ns[1])+1))
    elif len(ns)==1:cited.add(int(ns[0]))
  for p in main.paragraphs[ref_start+1:]:
   n=re.match(r'^(\d+)\. ',p.text)
   if n:refs.append(dict(reference_number=int(n.group(1)),entry=p.text,cited_in_main=int(n.group(1)) in cited,metadata_audit='focused independent metadata check' if int(n.group(1)) in [10,16,17,29,30,31,32,33,34,36] else 'numbering/citation match checked; full metadata not independently re-audited'))
  pd.DataFrame(refs).to_csv(a.package_dir/'05_Audit_and_Handover/Reference_Citation_Crosswalk.csv',index=False);checks['references']=len(refs);checks['all_references_cited']=all(x['cited_in_main'] for x in refs);checks['main_word_count_including_reference_list_and_tables_by_whitespace']=sum(len(p.text.split()) for p in main.paragraphs)+sum(len(c.text.split()) for t in main.tables for row in t.rows for c in row.cells)
  checks['main_body_REF_fields']=sum('REF ' in x.text for x in main._element.body.iter() if x.tag.endswith('instrText'))
  checks['source_files_still_match_initial_hashes']=all(hashlib.file_digest((a.source_dir/row.filename).open('rb'),'sha256').hexdigest()==row.sha256 for _,row in pd.read_csv(s/'Source_File_Manifest.csv').iterrows())
 (s/'Additional_Verification_Checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2));print(json.dumps(checks,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
