# Preflight — AdamW capacity-matched control (R1#6)

Root: `/root/rivermind-data/dta_cm_adamw/`
Outputs: `adamw_cm_revision/worker_A` (DeepDTA-CM), `adamw_cm_revision/worker_B` (GraphDTA-GCN-CM)
Frozen data (read-only): `/root/rivermind-data/dta_cm/data_final`

## 1. Why this control exists

The frozen 126-run study and the first widened 36 runs used different optimizers,
so the earlier width comparison was not a single-factor control. This revision
re-runs the same two widened baselines with the **real** optimizer used by the
frozen study, keeping topology, width, data splits, seeds, lr and all other
protocol settings identical. Only the optimizer implementation is brought into
alignment.

## 2. Optimizer evidence (code-level)

- Frozen 126 runs (`代码-ZhiYaoGraph-ADAMW-FORMAL`):
  - `config.py:165` -> `"optimizer": "adamw"`
  - `train/trainer.py:46-56` -> default `adamw`; `adamw` -> `torch.optim.AdamW`,
    `adam` -> `torch.optim.Adam`, then a single `optimizer_cls(...)` call.
- First widened 36 runs (`capacity_matched_train`):
  - `config.py:161` -> `"optimizer": "adam"`
  - `train/trainer.py` -> hard-coded `torch.optim.Adam`; checkpoints record
    `decoupled_weight_decay = False` (coupled weight decay).
- This revision: `config.py` TRAINING -> `"optimizer": "adamw"`; trainer now
  branches to `torch.optim.AdamW` and explicitly passes lr=1e-3, weight_decay=1e-5
  (the AdamW default weight decay is not relied on).

## 3. CPU verification performed before GPU launch (no GPU available)

- TRAINING optimizer = `adamw`; lr = 0.001; weight_decay = 1e-5.
- `build_matrix()` returns 36 rows: 18 worker_A + 18 worker_B; 36 unique stems.
- Every checkpoint path is isolated under
  `dta_cm_adamw/adamw_cm_revision/worker_<X>/checkpoints/`; none points at the
  frozen `dta_cm` tree.
- Trainable parameters (CPU build): DeepDTA-CM = **598,497**;
  GraphDTA-GCN-CM = **581,953** (matches the frozen widened targets).
- Concrete optimizer instantiated by the trainer for both models:
  **`torch.optim.adamw.AdamW`** (param-group lr 0.001, wd 1e-5).
- Frozen data root exists; all 6 dataset/setting combos (KIBA/DAVIS x
  warm/cold_drug/cold_target) contain train/val/test/scaler/split_metadata.
- `load_fixed_train_val` works; scaler is train-only MinMax (e.g. Davis warm:
  24,051 train / 3,000 val; KIBA cold_target: 85,975 / 12,421).
- Plan frozen at `adamw_cm_revision/capacity_matched_adamw_plan.json`
  (36 runs; recorded training_protocol.optimizer = adamw).

## 4. Launch commands (run only after switching to GPU mode)

Smoke test — single run, Worker B, Davis warm seed 42:

```
cd /root/rivermind-data/dta_cm_adamw
python3 scripts/run_one.py --stem graphdta_gcn_capacity_matched__davis_warm_seed42 --device auto
```

After the smoke checkpoint is verified, full Worker B lane (18 runs, resumable):

```
cd /root/rivermind-data/dta_cm_adamw
nohup python3 scripts/train_lane.py --baseline graphdta_gcn_capacity_matched --device auto \
  > adamw_cm_revision/worker_B/worker_B_train.log 2>&1 &
```

Worker A (DeepDTA) uses the same commands with baseline
`deepdta_capacity_matched` and the worker_A log path.

Held-out evaluation (after training) and three-seed aggregation:

```
python3 scripts/run_all_evals.py
python3 scripts/aggregate_capacity_matched.py
```

## 5. Boundaries

- No frozen model is retrained or modified; the frozen `dta_cm` tree is untouched.
- No new dataset, split, scaler or seed is introduced; split/scaler files are read
  from the frozen data root and never re-fit.
- Held-out test stays sealed during training; checkpoints are selected on
  validation only, then evaluated separately.
- No batch/lr/epoch/patience change; training protocol otherwise identical to the
  frozen widened runs.
