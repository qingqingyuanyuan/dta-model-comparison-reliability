# 三十六次 AdamW 加宽基线两人分工

这是任务分配包，没有启动远程训练，也不包含未经核验的训练命令。原 126 次实验及已有 36 次 Adam 加宽基线保持冻结，新 36 次使用单独目录。

## 分工

| 执行人 | 模型 | 矩阵 | 次数 |
| --- | --- | --- | --- |
| 你 A | DeepDTA-CM | 2 数据集 × 3 场景 × 3 种子 | 18 |
| 队友 B | GraphDTA-GCN-CM | 2 数据集 × 3 场景 × 3 种子 | 18 |

两份 JSON 的 job_id 没有交集，合并后恰好覆盖全部 36 项。每个 run 独立从头训练，不需要把一个模型拆给两个人做分布式训练。按模型分工便于维护模型代码；两份实际用时不必相等。

## 开跑顺序

双方先共用同一版训练代码、输入与 scaler，并核对原 126 次实际使用 AdamW 的训练证据。已经确定本轮训练 AdamW，但其能否严格称为与原实验同优化器，仍要依据原训练代码或日志。

每人清单中的第一项为 Davis warm seed 42。先各完成这一项，检查实际 optimizer 类、参数数目、数据/scaler 哈希和预测产物。有效试跑计入 36 次。随后各完成 seed 42 的其余五项，再运行 seed 123 和 2026 各六项。不要用分数好坏决定保留哪些任务。

## 双方必须一致的内容

1. 使用实际 torch.optim.AdamW，并显式设置 lr=0.001、weight_decay=0.00001；不能只把 Adam 的显示名称改成 AdamW，也不能误用 AdamW 默认 weight decay。其余 optimizer 参数与经过核验的原协议保持一致。
2. 使用原 frozen split 和训练集拟合的 min-max scaler；本批不新增 split、不变更验证或测试实体。对比数据内容哈希，不能只看文件名。
3. 保留已核验的加宽结构和参数数目：DeepDTA-CM 为 598497，GraphDTA-GCN-CM 为 581953；继承原 loss、scheduler、early stopping、选择准则、输入处理和评价精度，双方核对完整配置。Shared_Protocol.json 中可查证的旧 CM 参数只是一部分，不能代替完整实际配置。
4. 每个 run 按 42、123、2026 分别重新初始化随机状态。不同机器可以使用相同的模型种子；实际环境、GPU 型号和数值设置要记录。不要从已有 Adam checkpoint 接续训练。
5. validation 决定 best checkpoint，最终 test 单独评价；不能按 test 分数选择 epoch 或调参。
6. 新结果分别写入清单给出的 worker_A/worker_B 子目录，路径含 AdamW 对照的 job_id。两人不写同一结果目录，不覆盖旧权重、预测、metrics 或旧统计结果。

## 每个 run 保留的产物

完整实际配置与代码哈希、数据/分区/scaler 哈希、实际 optimizer 类和参数组、参数数目、训练验证历史、验证所选 checkpoint 及哈希、training.json、evaluation.json、validation 预测、record test 预测、unique-input 预测、环境信息。记录原始与 normalized 指标及其评价精度。

## 合并方式

以模型、数据集、场景、训练种子以及 experiment_family 识别运行。最终检查每模型每场景均有三个种子，共 36 项；不把“机器 A/B”当种子，不对每人摘要再随意平均。保留逐次指标，从全精度值生成三种子 mean 和 sample SD，随后统一重算配对差值、Bootstrap、LOO 和涉及新模型集合的 τ。

原 126、已有 36 Adam 与新 36 AdamW 分开标记，避免同名模型文件被当成同一批结果。AdamW 结果到齐后再同步主稿、Supplementary、回复信和公开归档。

如果每人有独立 GPU，可以同时执行各自任务；如果共用一张 GPU，两个进程会争用显存和算力，是否提速应实测。历史两模型耗时不同，不能承诺两人各自耗时完全相等或整体时间减半。
