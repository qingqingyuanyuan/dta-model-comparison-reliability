# Code and environment scope

`training/` retains received numerical training/model/evaluation code. Only two path defaults in config were adapted to DTA_LOCAL_DATA/DTA_OUTPUT_ROOT; the original remains in `CONFIGS/ORIGINAL_training_config.py`. TRAINING and BASELINES dictionaries were structurally compared and are unchanged. All scientific output files remain unchanged.

`original126_snapshot/` is the available local v1.0.0 source snapshot, not verified live v1.0.1. `historical_analysis/`, `historical_authoring/`, `historical_helpers/` and `execution_records/` preserve source/provenance with original path assumptions. Some historical authoring scripts need private Word/ZIP inputs deliberately withheld here. They are not the portable public entry points.

Use `public_tools/dta_reproduce.py` and `public_tools/shared_cluster_bootstrap.py` as shown in the root README. Saved-prediction replay needs Python, NumPy, pandas, SciPy, python-docx and g++; no torch/GPU/network is used. Run with python -B and put outputs outside this archive. Actual replay versions are recorded in the audit report.

Received AdamW training records identify Python3.12.3, torch2.5.1+cu124, torch-geometric2.6.1, NumPy1.26.4, pandas2.2.3, SciPy1.13.1, scikit-learn1.5.2 and RDKit2024.9.6. Exact received environment freezes/logs are retained; do not blindly copy historical local filesystem references into a new installation. The earlier data-generation manifest records another Python/RDKit environment.

Optional feature restoration, not run during packaging:

```bash
python -B CODE_AND_ENVIRONMENT/public_tools/restore_frozen_inputs.py --source ../BatchDTA_processed_data --output ../dta_local_features
```

Use a compatible recorded RDKit/data-generation environment and require all original CSV byte hashes to match. If the gate fails, report the difference and resolve the environment; do not relabel the new files as identical.

Optional training after the frozen data hash gate passes, not run during packaging:

```bash
DTA_OUTPUT_ROOT="/your/new/output/directory" python -B CODE_AND_ENVIRONMENT/training/scripts/run_one.py --stem deepdta_capacity_matched__davis_warm_seed42 --data-root /your/local/frozen/data --device cuda
```

Use a fresh output directory outside the archive. The original no-overwrite run implementation and validation-only checkpoint selection remain in effect; this command does not evaluate the held-out test. Full inference/retraining determinism and historical test-access behavior are not established by archive verification.
