#!/usr/bin/env python3
"""Optional local feature reconstruction with RDKit and exact original hash gates.
This path is not claimed tested during archive preparation. Outputs stay local.
"""
from pathlib import Path
import argparse,json,shutil,sys
sys.dont_write_bytecode=True
import pandas as pd
from dta_reproduce import PACKAGE,read,sha,module,output_dir,save
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();out=output_dir(a.output)
 assert not any(out.iterdir()),'Choose a new empty output directory.'
 for ds,parts in read(PACKAGE/'SPLITS_AND_MANIFESTS/UPSTREAM_FILES.json').items():
  for part,meta in parts.items():
   p=a.source/ds/Path(meta['path']).name;assert p.stat().st_size==meta['bytes'] and sha(p)==meta['sha256']
 legacy=module('archived_data_preparation',PACKAGE/'CODE_AND_ENVIRONMENT/original126_snapshot/scripts/prepare_final_datasets.py');expected=read(PACKAGE/'SPLITS_AND_MANIFESTS/Frozen_Data_Manifest.json');checks=[]
 for ds in ['KIBA','DAVIS']:
  train,test=legacy.read_sources(a.source,ds);cleaned,*_=legacy.clean_full_dataset(ds,train,test,'keep_grouped');lookup=cleaned.set_index(['Source Split','Source Row'],drop=False);assert not lookup.index.duplicated().any()
  for setting in ['warm','cold_target','cold_drug']:
   dest=out/ds/setting;dest.mkdir(parents=True);metadata=PACKAGE/f'SPLITS_AND_MANIFESTS/metadata/{ds}/{setting}';scaler=read(metadata/'scaler.json')
   for part in ['train','val','test']:
    idx=pd.read_csv(PACKAGE/f'SPLITS_AND_MANIFESTS/row_indices/{ds}/{setting}/{part}.csv');order=pd.MultiIndex.from_frame(idx[['SourceSplit','SourceRow']].rename(columns={'SourceSplit':'Source Split','SourceRow':'Source Row'}));data=legacy.apply_scaler(lookup.loc[order].reset_index(drop=True),scaler);target=dest/(part+'.csv');data.to_csv(target,index=False);rel=f'{ds}/{setting}/{part}.csv';checks.append(dict(path=rel,expected_sha256=expected[rel]['sha256'],actual_sha256=sha(target),passed=sha(target)==expected[rel]['sha256']))
   for name in ['scaler.json','split_metadata.json']:shutil.copy2(metadata/name,dest/name)
 result=dict(checks=checks,passed=all(c['passed'] for c in checks),warning='If byte hashes differ, resolve recorded data-generation/Python/pandas/RDKit versions. Do not call regenerated inputs identical until the hash gate passes.');save(out/'LOCAL_FEATURE_RESTORATION.json',result);assert result['passed']
 print('All frozen CSV byte hashes match.')
if __name__=='__main__':main()
