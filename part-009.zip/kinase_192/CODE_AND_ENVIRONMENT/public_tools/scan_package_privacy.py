"""Structured credential/privacy scan and complete source/nested hash inventory."""
from pathlib import Path
import collections,hashlib,io,json,re,sys,zipfile
sys.dont_write_bytecode=True

PATTERNS={
 'private_key':re.compile(rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----'),
 'github_token':re.compile(rb'(?<![A-Za-z0-9])(?:gh[pousr]_[A-Za-z0-9]{30,255}|github_pat_[A-Za-z0-9_]{30,255})'),
 'cloud_access_key':re.compile(rb'(?<![A-Za-z0-9])(?:AKIA|ASIA)[A-Z0-9]{16}(?![A-Za-z0-9])'),
 'api_token':re.compile(rb'(?<![A-Za-z0-9])sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{35,255}'),
 'credential_url':re.compile(rb'https?://[^\s/@:]{1,120}:[^\s/@]{1,255}@'),
 'credential_assignment':re.compile(rb'(?i)(?:password|passwd|api[_-]?key|access[_-]?token|secret[_-]?key)\s*[=:]\s*[\x22\x27][^\x22\x27\r\n]{8,200}[\x22\x27]')}
EMAIL=re.compile(rb'(?<![A-Za-z0-9_.+%-])[A-Za-z0-9_.+%-]{1,100}@[A-Za-z0-9.-]{1,180}\.[A-Za-z]{2,24}(?![A-Za-z])')
PUBLIC_EMAILS={b'2993272783@qq.com'}
def stream(f,text=True):
 h=hashlib.sha256();size=0;cats=set();emails=set();tail=b''
 while True:
  chunk=f.read(1024*1024)
  if not chunk:break
  h.update(chunk);size+=len(chunk)
  if not text:continue
  data=tail+chunk
  for name,pat in PATTERNS.items():
   if name=='private_key' and b'PRIVATE KEY' not in data:continue
   if name=='credential_url' and b'@' not in data:continue
   if name=='credential_assignment' and not any(s in data.lower() for s in [b'password',b'passwd',b'api_key',b'access_token',b'secret_key',b'apikey']):continue
   if pat.search(data):cats.add(name)
  if b'@' in data:emails.update(m.group().lower() for m in EMAIL.finditer(data))
  tail=data[-4096:]
 return dict(bytes=size,sha256=h.hexdigest(),credential_categories=sorted(cats),unapproved_email_count=len(emails-PUBLIC_EMAILS),approved_author_email_count=len(emails&PUBLIC_EMAILS))
def inspect(p):
 container=p.suffix.lower() in {'.zip','.docx','.xlsx','.pt'} and zipfile.is_zipfile(p)
 with p.open('rb') as f:r=stream(f,not container)
 nested=[]
 if container:
  with zipfile.ZipFile(p) as z:
   for item in z.infolist():
    if item.is_dir():continue
    text=Path(item.filename).suffix.lower() in {'.py','.csv','.json','.jsonl','.txt','.log','.md','.xml','.rels','.yaml','.yml','.cff','.cpp','.pkl','.sha256'}
    with z.open(item) as f:q=stream(f,text)
    q.update(member=item.filename,scan_scope='text/metadata' if text else 'binary hashed; not interpreted as contact text');nested.append(q)
    r['credential_categories']=sorted(set(r['credential_categories'])|set(q['credential_categories']));r['unapproved_email_count']+=q['unapproved_email_count']
 # Read actual PDF text/metadata as well, not just its compressed bytes.
 if p.suffix.lower()=='.pdf':
  import fitz
  doc=fitz.open(p);data=('\n'.join(page.get_text() for page in doc)+'\n'+json.dumps(doc.metadata)).encode();q=stream(io.BytesIO(data));r['credential_categories']=sorted(set(r['credential_categories'])|set(q['credential_categories']));r['unapproved_email_count']+=q['unapproved_email_count'];doc.close()
 if p.suffix.lower() in {'.png','.jpg','.jpeg'}:
  from PIL import Image
  with Image.open(p) as image:
   if 34853 in image.getexif():r['credential_categories'].append('image_gps_metadata_requires_review')
 return r,nested
def main():
 import argparse
 ap=argparse.ArgumentParser(description='Structured public-package privacy scan; optional PyMuPDF/Pillow for PDF/image inspection. No secret values are printed.')
 ap.add_argument('--folder',type=Path,default=Path(__file__).resolve().parents[2]);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();folder=a.folder.resolve();out=a.output.resolve()
 assert folder.is_dir() and out!=folder and folder not in out.parents
 out.mkdir(parents=True,exist_ok=True);rows=[]
 for p in sorted(folder.rglob('*')):
  if not p.is_file():continue
  r,children=inspect(p);rows.append(dict(path=str(p.relative_to(folder)),bytes=r['bytes'],sha256=r['sha256'],credential_categories=r['credential_categories'],unapproved_email_count=r['unapproved_email_count']))
 findings=[r for r in rows if r['credential_categories'] or r['unapproved_email_count']]
 (out/'PRIVACY_SCAN.json').write_text(json.dumps(dict(files=len(rows),findings=findings,policy='Pattern/structured scan, not proof against arbitrary encoded secrets. Protein/tensor false positives are controlled; approved author contact is retained.'),indent=2))
 print(json.dumps(dict(files=len(rows),flagged_files=len(findings))))
if __name__=='__main__':main()
