#!/usr/bin/env python3
"""Read-only public-package checks and saved-prediction replay; no downloads or GPU.
Run from any directory. Acquire official inputs independently. Generated local
labels/results must be outside this immutable archive.
"""
from pathlib import Path
import argparse,csv,hashlib,importlib.util,json,math,sys
sys.dont_write_bytecode=True
import numpy as np
import pandas as pd
PACKAGE=Path(__file__).resolve().parents[2]
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def output_dir(path):
 p=Path(path).expanduser().resolve()
 if p==PACKAGE or PACKAGE in p.parents:raise ValueError('Use an output directory outside the immutable public archive.')
 p.mkdir(parents=True,exist_ok=True);return p
def kernel(out):
 m=module('received_cindex',PACKAGE/'CODE_AND_ENVIRONMENT/historical_analysis/AdamW_CM36/scripts/recompute_statistics.py');cache=out/'_runtime_cache';cache.mkdir(exist_ok=True);ci=m.CIndex(cache);assert m.test_kernel(ci)==36;return ci
def save(p,data):p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def verify(a):
 out=output_dir(a.output);count=0
 if not a.metadata_only:
  hashes={}
  for line in (PACKAGE/'SHA256SUMS.txt').read_text().splitlines():
   h,name=line.split('  ',1);assert not Path(name).is_absolute() and '..' not in Path(name).parts;assert sha(PACKAGE/name)==h,name;hashes[name]=h;count+=1
  actual={str(p.relative_to(PACKAGE)) for p in PACKAGE.rglob('*') if p.is_file()};assert actual==set(hashes)|{'SHA256SUMS.txt'}
  with (PACKAGE/'PUBLIC_FILE_MANIFEST.csv').open(newline='') as f:manifest=list(csv.DictReader(f))
  assert {r['path'] for r in manifest}==set(hashes)-{'PUBLIC_FILE_MANIFEST.csv'}
  assert all(r['sha256']==hashes[r['path']] and int(r['bytes'])==(PACKAGE/r['path']).stat().st_size for r in manifest)
 h=module('restricted_checkpoint_reader',PACKAGE/'CODE_AND_ENVIRONMENT/historical_helpers/handover_checked.py');runs=read(PACKAGE/'ADAMW_36_RUNS/RUN_INDEX.json');rows=[];hashes=set();tensor_shapes=[];frozen=read(PACKAGE/'SPLITS_AND_MANIFESTS/Frozen_Data_Manifest.json')
 assert len(runs)==36 and len({r['stem'] for r in runs})==36
 for r in runs:
  p={k:PACKAGE/r[k] for k in ['checkpoint','history','training','evaluation','receipt']};assert all(v.is_file() for v in p.values())
  ck=h.read_checkpoint_metadata(p['checkpoint']);t=read(p['training']);e=read(p['evaluation']);rc=read(p['receipt']);digest=sha(p['checkpoint']);hashes.add(digest)
  assert digest==t['checkpoint_sha256']==e['checkpoint_sha256']==rc['checkpoint_sha256']
  assert sha(p['evaluation'])==rc['files']['metadata'] and rc['files']['record']==r['record']['source_sha256'] and rc['files']['unique']==r['unique_input']['source_sha256']
  assert e['test_csv_sha256']==rc['test_csv_sha256']
  prefix=f"{r['dataset'].upper()}/{r['setting']}/"
  assert e['test_csv_sha256']==frozen[prefix+'test.csv']['sha256']
  for name in ['train','val','scaler']:assert ck['data_provenance'][name]['sha256']==frozen[prefix+name+('.json' if name=='scaler' else '.csv')]['sha256']
  assert ck['scaler']==e['scaler']==read(PACKAGE/f'SPLITS_AND_MANIFESTS/metadata/{r["dataset"].upper()}/{r["setting"]}/scaler.json')
  assert ck['baseline_name']==r['model'] and ck['dataset']==r['dataset'].upper() and ck['setting']==r['setting']
  protocol=ck['config']['TRAINING'];expected=dict(optimizer='adamw',learning_rate=.001,weight_decay=1e-5,batch_size=64,num_epochs=200,early_stopping_patience=30,gradient_clip_norm=5.)
  assert all(protocol[k]==v for k,v in expected.items())
  assert t['optimizer_implementation']==e['optimizer_implementation']=='torch.optim.AdamW'
  params=598497 if r['worker']=='worker_A' else 581953
  assert ck['parameter_summary']['total']==t['parameter_summary']['total']==e['parameter_summary']['total']==params and ck['model_seed']==r['seed']
  with p['history'].open(newline='') as f:history=list(csv.DictReader(f))
  assert len(history)==ck['stop_epoch'] and int(history[-1]['epoch'])==ck['stop_epoch'] and 1<=ck['best_epoch']<=ck['stop_epoch']<=200
  assert ck['stop_reason'] in ['early_stopping_patience','max_epochs_reached']
  assert ck['test_evaluated_during_training'] is False and t['test_evaluated'] is False
  for level in ['record','unique_input','validation']:assert (PACKAGE/r[level]['public_path']).is_file()
  rows.append(dict(stem=r['stem'],checkpoint_sha256=digest,optimizer=protocol['optimizer'],parameters=params,best_epoch=ck['best_epoch'],stop_epoch=ck['stop_epoch'],original_receipt_consistent=True))
  for name,ten in ck['model_state_dict'].items():tensor_shapes.append(dict(stem=r['stem'],name=name,shape=list(ten.shape),elements=math.prod(ten.shape)))
 assert len(hashes)==36
 source=PACKAGE/'PREDICTIONS_AND_METRICS/statistics/Frozen126/Source_Metrics_FINAL126_Frozen.csv';oldhash='8de0061679c33c7b154db50cdcd595afe7d2770a34d9d4ccb52df209b7888880';assert sha(source)==oldhash
 old=pd.read_csv(source);assert len(old)==126 and not hashes.intersection(set(old.checkpoint_sha256))
 save(out/'CHECKPOINT_CHECKS.json',rows);save(out/'TENSOR_SHAPES.json',tensor_shapes)
 result=dict(passed=True,payload_hashes_verified=count,new36_complete=True,distinct_new_checkpoints=36,original126_source_sha256=oldhash,scope='File hashes and restricted metadata/receipt/history checks. No tensor loading, inference, retraining or reconstruction of historical test access.')
 save(out/'PACKAGE_VERIFICATION.json',result);print(json.dumps(result,indent=2))

def labels(a):
 out=output_dir(a.output);up=read(PACKAGE/'SPLITS_AND_MANIFESTS/UPSTREAM_FILES.json');sources={};checks=[];partitions=[]
 for dataset,parts in up.items():
  for part,info in parts.items():
   p=a.source/dataset/Path(info['path']).name;assert p.stat().st_size==info['bytes'] and sha(p)==info['sha256'],f'Source mismatch: {dataset}/{p.name}'
   frame=pd.read_csv(p);sources[dataset,'source_'+part]=pd.to_numeric(frame['Label']).to_numpy(dtype=np.float64);checks.append(dict(dataset=dataset,partition=part,bytes=p.stat().st_size,sha256=info['sha256'],passed=True))
 for dataset in ['KIBA','DAVIS']:
  for setting in ['warm','cold_target','cold_drug']:
   scaler=read(PACKAGE/f'SPLITS_AND_MANIFESTS/metadata/{dataset}/{setting}/scaler.json')
   for part in ['train','val','test']:
    idx=pd.read_csv(PACKAGE/f'SPLITS_AND_MANIFESTS/row_indices/{dataset}/{setting}/{part}.csv');assert np.array_equal(idx.RowIndex,np.arange(len(idx))) and set(idx.SourceSplit)<={'source_train','source_test'}
    y=np.empty(len(idx),dtype=np.float64)
    for source_split in ['source_train','source_test']:
     mask=idx.SourceSplit.eq(source_split).to_numpy();y[mask]=sources[dataset,source_split][idx.loc[mask,'SourceRow'].to_numpy(dtype=np.int64)]
    idx['Label_raw']=y;idx['Label_norm']=(y-scaler['min'])/scaler['range'];dest=out/dataset/setting/(part+'.csv');dest.parent.mkdir(parents=True,exist_ok=True);idx.to_csv(dest,index=False,float_format='%.17g');partitions.append(dict(dataset=dataset,setting=setting,partition=part,n=len(idx),groups=int(idx.GroupId.nunique())))
 result=dict(upstream_checks=checks,partitions=partitions,local_labels_restored=True,public_package_modified=False,caveat='Restored labels are third-party local data; do not add them to a public archive without redistribution review.')
 save(out/'LOCAL_LABEL_RESTORATION.json',result);print(json.dumps(dict(upstream_files=4,partitions=18,passed=True)))

def calculate(ci,yn,pn,scaler):
 yn=np.asarray(yn,dtype=np.float64);pn=np.asarray(pn,dtype=np.float64);y=yn*scaler['range']+scaler['min'];p=pn*scaler['range']+scaler['min']
 return dict(ci=float(ci.direct(yn,pn)[0]),mse_norm=float(np.mean((yn-pn)**2)),rmse_norm=float(np.sqrt(np.mean((yn-pn)**2))),mae_norm=float(np.mean(abs(yn-pn))),mse_raw=float(np.mean((y-p)**2)),rmse_raw=float(np.sqrt(np.mean((y-p)**2))),mae_raw=float(np.mean(abs(y-p))),scaler_range=scaler['range'])
def metrics(a):
 out=output_dir(a.output);ci=kernel(out);cache={};checks=[];values=[]
 for r in read(PACKAGE/'ADAMW_36_RUNS/RUN_INDEX.json'):
  e=read(PACKAGE/r['evaluation']);t=read(PACKAGE/r['training']);ds=r['dataset'].upper();setting=r['setting']
  for level,expected in [('record',e['record_level_metrics']),('unique_input',e['unique_input_level_metrics']),('validation',t['validation_metrics'])]:
   part='val' if level=='validation' else 'test';key=(ds,setting,part)
   if key not in cache:cache[key]=pd.read_csv(a.labels/ds/setting/(part+'.csv'),float_precision='round_trip')
   lab=cache[key];pred=pd.read_csv(PACKAGE/r[level]['public_path'],float_precision='round_trip')
   if level=='unique_input':
    grouped=lab.groupby('GroupId',sort=True).agg(Label_norm=('Label_norm','median'),RecordCount=('RowIndex','size')).reset_index();q=grouped.merge(pred,on='GroupId',how='outer',validate='one_to_one',indicator=True,suffixes=('_local','_public'));assert np.array_equal(q.RecordCount_local,q.RecordCount_public);yn=q.Label_norm.to_numpy(dtype=np.float64)
   else:
    q=lab.merge(pred,on='RowIndex',how='outer',validate='one_to_one',indicator=True);yn=q.Label_norm.to_numpy(dtype=np.float32)
   assert q._merge.eq('both').all() and len(q)==expected['n'];computed=calculate(ci,yn,q.Prediction_norm.to_numpy(dtype=np.float32),e['scaler'])
   for metric,value in computed.items():
    delta=float(value-expected[metric]);checks.append(dict(stem=r['stem'],level=level,metric=metric,reported=expected[metric],recomputed=value,difference=delta,passed=abs(delta)<=1e-12))
   values.append(dict(dataset=ds.lower(),setting=setting,model=r['model'],seed=r['seed'],level=level,n=len(q),**computed))
 df=pd.DataFrame(checks);df.to_csv(out/'AdamW36_Metric_Comparison.csv',index=False,float_format='%.17g');pd.DataFrame(values).to_csv(out/'Recomputed_Metrics.csv',index=False,float_format='%.17g');assert len(df)==864 and df.passed.all()
 result=dict(runs=36,comparisons=864,passed=True,max_absolute_difference=float(df.difference.abs().max()),kernel_reference_cases=36);save(out/'ADAMW36_METRIC_REPLAY.json',result)
 # Original unique-input sensitivity statistics intentionally use the received
 # original126 analysis's default pandas decimal parser, not the AdamW parser.
 expected=pd.read_csv(PACKAGE/'PREDICTIONS_AND_METRICS/statistics/Frozen126/Verified_UniqueInput_Metrics_All126.csv');original=[]
 for r in read(PACKAGE/'ORIGINAL_126_RUNS/PREDICTION_INDEX.json'):
  ds=r['dataset'];setting=r['setting'];key=(ds.upper(),setting,'test');lab=cache[key]
  y=lab.groupby('GroupId',sort=True).agg(Label_raw=('Label_raw','median')).reset_index();p=pd.read_csv(PACKAGE/r['public_path']);q=y.merge(p,on='GroupId',validate='one_to_one').sort_values('GroupId');yv=q.Label_raw.to_numpy();pv=q.Prediction_raw.to_numpy();m=dict(cindex=float(ci.direct(yv,pv)[0]),mse_raw=float(np.mean((pv-yv)**2)),rmse_raw=float(np.sqrt(np.mean((pv-yv)**2))),mae_raw=float(np.mean(abs(pv-yv))))
  row=expected[(expected.dataset==ds)&(expected.setting==setting)&(expected.model==r['model'])&(expected.seed==r['seed'])];assert len(row)==1
  for metric,value in m.items():
   delta=float(value-row.iloc[0][metric]);original.append(dict(dataset=ds,setting=setting,model=r['model'],seed=r['seed'],metric=metric,reported=float(row.iloc[0][metric]),recomputed=value,difference=delta,passed=abs(delta)<=1e-12))
 od=pd.DataFrame(original);od.to_csv(out/'Original126_Unique_Metric_Comparison.csv',index=False,float_format='%.17g');save(out/'ORIGINAL126_UNIQUE_REPLAY.json',dict(comparisons=len(od),passed=bool(od.passed.all()),max_absolute_difference=float(od.difference.abs().max()),scope='Raw-label unique-input sensitivity statistics; missing original record predictions are not reconstructed.'))
 print(json.dumps(result,indent=2));print('Original126 unique comparisons:',len(od),'passed',bool(od.passed.all()))

def main():
 ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='command',required=True)
 v=sub.add_parser('verify');v.add_argument('--output',type=Path,required=True);v.add_argument('--metadata-only',action='store_true',help='Build-time check before the manifest is sealed')
 l=sub.add_parser('labels');l.add_argument('--source',type=Path,required=True);l.add_argument('--output',type=Path,required=True)
 m=sub.add_parser('metrics');m.add_argument('--labels',type=Path,required=True);m.add_argument('--output',type=Path,required=True)
 a=ap.parse_args();{'verify':verify,'labels':labels,'metrics':metrics}[a.command](a)
if __name__=='__main__':main()
