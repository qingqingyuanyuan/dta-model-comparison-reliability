from pathlib import Path
import csv, hashlib, json

root = Path(__file__).resolve().parents[2]
index = json.loads((root / "INDEPENDENT_SPLIT_30_RUNS/RUN_INDEX.json").read_text(encoding="utf-8"))
assert len(index) == 30, len(index)

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

checked = 0
for run in index:
    for key in ("checkpoint", "training", "history", "evaluation"):
        path = root / run[key]
        assert path.is_file(), path
        if key == "checkpoint":
            evaluation = json.loads((root / run["evaluation"]).read_text(encoding="utf-8"))
            assert sha(path) == evaluation["checkpoint_sha256"], path
    for level in ("record", "unique_input", "validation"):
        item = run[level]
        path = root / item["public_path"]
        assert sha(path) is not None
        with path.open(encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            expected = ["GroupId", "Prediction_norm", "Prediction_raw", "RecordCount"] if level == "unique_input" else ["RowIndex", "Prediction_norm", "Prediction_raw"]
            assert reader.fieldnames == expected, (path, reader.fieldnames)
            rows = sum(1 for _ in reader)
        assert rows == item["rows"], (path, rows, item["rows"])
        checked += 1
print(f"PASS: {len(index)} independent-split runs; {checked} prediction-only exports; schemas, row counts and checkpoint hashes verified.")
