#!/usr/bin/env bash
set -Eeuo pipefail
cd /root/dta_kiba_split_robustness_adamw
export PYTHONUNBUFFERED=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export DTA_SEAL_SCOPE=v2_robustness

# Do not rerun on partially/fully populated outputs. Recover a failed run
# deliberately, after reviewing logs. Never overwrite prior checkpoints.
for d in checkpoints training_outputs evaluation_outputs; do
  if [ -d "$d" ] && [ -n "$(find "$d" -type f -print -quit)" ]; then
    echo "STOP: $d contains files. Refusing to overwrite or mix old runs." >&2
    exit 2
  fi
done
mkdir -p logs eval_logs checkpoints training_outputs evaluation_outputs

# Validate the shared optimizer path for all five model families.
python - <<'PY_RUNTIME'
import config as cfg
from baselines.registry import get_baseline_config
assert cfg.TRAINING['optimizer'].lower() == 'adamw'
for name in ('deepdta_style', 'graphdta_gcn_style'):
    assert get_baseline_config(name)['TRAINING']['optimizer'].lower() == 'adamw'
print('PRECHECK PASS: 3 fusion models and 2 baselines use shared AdamW training protocol')
PY_RUNTIME

pids=()
labels=()
wait_batch() {
  local fail=0 i
  for i in "${!pids[@]}"; do
    if wait "${pids[$i]}"; then
      echo "PASS: ${labels[$i]}"
    else
      echo "FAIL: ${labels[$i]} (inspect its log; stopping after this batch)" >&2
      fail=1
    fi
  done
  pids=()
  labels=()
  if (( fail )); then exit 1; fi
}

launch_fusion() {
  local setting="$1" fusion="$2" seed="$3"
  local log="logs/adamw_fusion_${setting}_${fusion}_seed${seed}.log"
  python run.py --mode train --data kiba --setting "$setting" --fusion "$fusion" \
    --model-seed "$seed" --final-run --epochs 200 --batch 64 --num-workers 2 \
    --device cuda --data-root data_final_v2 --no-progress > "$log" 2>&1 &
  pids+=("$!")
  labels+=("$setting/$fusion/seed$seed")
  if (( ${#pids[@]} >= 4 )); then wait_batch; fi
}

launch_baseline() {
  local setting="$1" baseline="$2" seed="$3"
  local log="logs/adamw_baseline_${baseline}_${setting}_seed${seed}.log"
  python scripts/run_one_baseline.py --baseline "$baseline" --setting "$setting" \
    --seed "$seed" --data-root data_final_v2 --num-workers 2 \
    --device cuda --no-progress > "$log" 2>&1 &
  pids+=("$!")
  labels+=("$setting/$baseline/seed$seed")
  if (( ${#pids[@]} >= 4 )); then wait_batch; fi
}

echo "=== $(date) START: 18 AdamW fusion runs ==="
for setting in cold_drug cold_target; do
  for fusion in concat product attention; do
    for seed in 42 123 2026; do
      launch_fusion "$setting" "$fusion" "$seed"
    done
  done
done
wait_batch
echo "=== $(date) fusion training PASS ==="

echo "=== $(date) START: 12 AdamW baselines ==="
for setting in cold_drug cold_target; do
  for baseline in deepdta_style graphdta_gcn_style; do
    for seed in 42 123 2026; do
      launch_baseline "$setting" "$baseline" "$seed"
    done
  done
done
wait_batch
echo "=== $(date) baseline training PASS ==="

# The R2 v2 seal must see all 30 complete, valid training checkpoints.
python - <<'PY_SEAL'
from scripts.experiment_integrity import require_full_training_complete
status = require_full_training_complete()
print('TRAINING SEAL PASS:', status)
PY_SEAL

# Confirm every saved checkpoint really used AdamW (not just today's config).
python - <<'PY_CKPT'
import torch
from pathlib import Path
for setting in ('cold_drug','cold_target'):
    for fusion in ('concat','product','attention'):
        for seed in (42,123,2026):
            path = Path('checkpoints') / f'kiba_{setting}_{fusion}_seed{seed}.pt'
            cfg = torch.load(path, map_location='cpu', weights_only=True)['config']
            assert cfg['TRAINING']['optimizer'].lower() == 'adamw', str(path)
    for model in ('deepdta_style','graphdta_gcn_style'):
        for seed in (42,123,2026):
            path = Path('checkpoints/baselines') / f'{model}__kiba_{setting}_seed{seed}.pt'
            cfg = torch.load(path, map_location='cpu', weights_only=True)['config']
            assert cfg['TRAINING']['optimizer'].lower() == 'adamw', str(path)
print('CHECKPOINT PASS: all 30 saved configurations identify AdamW')
PY_CKPT

echo "=== $(date) evaluating 18 fusion checkpoints ==="
for setting in cold_drug cold_target; do
  for fusion in concat product attention; do
    for seed in 42 123 2026; do
      python scripts/evaluate_model.py --data kiba --setting "$setting" \
        --ckpt "checkpoints/kiba_${setting}_${fusion}_seed${seed}.pt" \
        --data-root data_final_v2 --no-progress \
        > "eval_logs/adamw_eval_${setting}_${fusion}_${seed}.log" 2>&1
    done
  done
done

echo "=== $(date) evaluating 12 baseline checkpoints ==="
for setting in cold_drug cold_target; do
  for baseline in deepdta_style graphdta_gcn_style; do
    for seed in 42 123 2026; do
      python scripts/evaluate_baseline.py --data kiba --setting "$setting" \
        --ckpt "checkpoints/baselines/${baseline}__kiba_${setting}_seed${seed}.pt" \
        --data-root data_final_v2 --num-workers 2 --device cuda --no-progress \
        > "eval_logs/adamw_eval_baseline_${baseline}_${setting}_${seed}.log" 2>&1
    done
  done
done

# The real evaluation names contain __kiba__<setting> and baselines/.
python - <<'PY_VALIDATE'
import json, math
from pathlib import Path
expected_n = {'cold_drug':11784, 'cold_target':26965}
count=0
for setting in ('cold_drug','cold_target'):
    for model in ('concat','product','attention','deepdta_style','graphdta_gcn_style'):
        for seed in (42,123,2026):
            baseline = model in ('deepdta_style','graphdta_gcn_style')
            stem = (f'{model}__kiba_{setting}_seed{seed}' if baseline else
                    f'kiba_{setting}_{model}_seed{seed}')
            base = Path('evaluation_outputs') / ('baselines' if baseline else '')
            path = base / f'{stem}__kiba__{setting}__evaluation.json'
            if not path.is_file(): raise RuntimeError(f'MISSING: {path}')
            p=json.loads(path.read_text(encoding='utf-8'))
            assert p.get('seal_scope') == 'v2_robustness', str(path)
            assert str(p.get('dataset')).upper() == 'KIBA', str(path)
            assert p.get('setting') == setting and int(p.get('model_seed'))==seed, str(path)
            identity = p.get('baseline_name') if baseline else p.get('fusion')
            assert identity == model, str(path)
            metric=p['record_level_metrics']
            ci=float(metric['ci'])
            assert math.isfinite(ci) and 0<=ci<=1, str(path)
            assert int(metric['n'])==expected_n[setting], str(path)
            assert int(p['test_samples'])==expected_n[setting], str(path)
            pred=Path(p['record_prediction_file'])
            assert pred.is_file(), f'MISSING predictions: {pred}'
            count+=1
assert count == 30, count
print('EVALUATION PASS: exactly the expected 30 evaluation JSONs are valid')
PY_VALIDATE

echo "=== $(date) ALL_30_TRAIN_AND_EVAL_VERIFIED ==="
echo "NOTE: S22 NOT generated here. Recompute with verified metrics/aggregation code; do not reuse the old Adam S22."
