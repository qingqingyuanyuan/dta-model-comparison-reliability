#!/usr/bin/env python3
"""Batch held-out evaluation for all 36 capacity-matched checkpoints.

Resumable: rows whose evaluation JSON already exists are skipped. Uses the same
record-level + unique-input evaluator and frozen data; no retraining.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

import config as cfg  # noqa: E402
import run_capacity_matched as m  # noqa: E402
from evaluate_capacity_matched import evaluate_capacity_matched  # noqa: E402

OUT = ROOT / "evaluation_outputs" / "capacity_matched"


def main():
    rows = m.build_matrix()
    print(f"BATCH EVAL: {len(rows)} checkpoints", flush=True)
    for i, r in enumerate(rows, 1):
        ck_stem = Path(r["checkpoint"]).stem
        eval_json = OUT / f"{ck_stem}__{r['dataset'].lower()}__{r['setting']}__evaluation.json"
        print(f"[{i}/{len(rows)}] {r['stem']}", flush=True)
        if eval_json.exists():
            print(" SKIP: evaluation exists", flush=True)
            continue
        try:
            evaluate_capacity_matched(
                dataset_name=r["dataset"],
                setting=r["setting"],
                ckpt_path=r["checkpoint"],
                data_root=ROOT / "data_final",
                batch_size=int(cfg.TRAINING["batch_size"]),
                num_workers=4,
                device_name="auto",
                output_dir=OUT,
                show_progress=False,
                overwrite=False,
            )
        except Exception:
            import traceback
            traceback.print_exc()
    print("ALL_EVALS_DONE", flush=True)


if __name__ == "__main__":
    main()
