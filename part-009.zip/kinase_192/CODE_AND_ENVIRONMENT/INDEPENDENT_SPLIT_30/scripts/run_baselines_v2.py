"""Wrapper: run the 2 controlled baselines x 2 v2 settings x 3 seeds = 12 runs.

Patches cfg.BASELINE_EXPERIMENT_MATRIX to the KIBA v2 robustness scope WITHOUT
modifying frozen config.py, and uses a separate plan file so the original
frozen baseline_plan.json is never touched.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config as cfg  # noqa: E402

# Scope the matrix to the R2#1 campaign. Baselines and seeds stay exactly the
# frozen ones (deepdta_style, graphdta_gcn_style; 42/123/2026).
cfg.BASELINE_EXPERIMENT_MATRIX["datasets"] = ["KIBA"]
cfg.BASELINE_EXPERIMENT_MATRIX["settings"] = ["cold_drug", "cold_target"]

if __name__ == "__main__":
    argv = sys.argv[1:]
    # Force our own plan file; allow caller to override otherwise.
    if "--plan-file" not in argv:
        argv += ["--plan-file", str(ROOT / "experiments" / "baseline_plan_v2.json")]
    sys.argv = ["run_baseline_matrix"] + argv
    import scripts.run_baseline_matrix as rbm  # noqa: E402
    rbm.main()
