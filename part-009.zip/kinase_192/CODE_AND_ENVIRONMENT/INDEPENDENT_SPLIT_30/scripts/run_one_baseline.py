#!/usr/bin/env python3
"""Train a single baseline row for parallel execution."""
import sys, argparse
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import config as cfg  # noqa: E402
cfg.BASELINE_EXPERIMENT_MATRIX["datasets"] = ["KIBA"]
cfg.BASELINE_EXPERIMENT_MATRIX["settings"] = ["cold_drug", "cold_target"]

from scripts.run_baseline_matrix import _train_one, build_matrix  # noqa: E402

p = argparse.ArgumentParser()
p.add_argument("--baseline", required=True)
p.add_argument("--setting", required=True)
p.add_argument("--seed", type=int, required=True)
p.add_argument("--data-root", type=Path, default=ROOT / "data_final_v2")
p.add_argument("--num-workers", type=int, default=2)
p.add_argument("--device", default="cuda")
p.add_argument("--no-progress", action="store_true")
p.add_argument("--overwrite", action="store_true")
args = p.parse_args()

rows = build_matrix()
row = next(r for r in rows
           if r["baseline"] == args.baseline
           and r["setting"] == args.setting
           and r["seed"] == args.seed)
print(f"=== TRAIN ONE BASELINE {row['stem']} ===")
_train_one(row, args)
