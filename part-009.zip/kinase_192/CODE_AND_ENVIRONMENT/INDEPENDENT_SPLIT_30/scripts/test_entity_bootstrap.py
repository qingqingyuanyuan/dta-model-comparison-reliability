"""Test-entity cluster bootstrap for the R2#1 v2 campaign (post-processing, no retraining).

For each setting and seed, the 5 models' held-out test predictions are grouped by
the held-out entity (Target Sequence for cold_target; Canonical SMILES for
cold_drug). Whole entities are resampled with replacement. Because duplicate
copies of an entity only create identical (non-comparable) pairs, the C-index of
a resample is an exact weighted combination of pre-computed within-entity and
cross-entity pair counts; no O(n^2) recomputation per resample is needed.

Reports per (setting, seed):
  * P(bootstrap ranking identical to the observed ranking)
  * each model's observed C-index and 2.5/97.5 percentile CI
  * cross-setting: P(Kendall tau = -1)

Scope: this measures test-entity sampling stability, NOT full split-to-split
variability (which requires retraining).
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
EVAL = ROOT / "evaluation_outputs"

SETTINGS = {
    "cold_target": "Target Sequence",
    "cold_drug": "Canonical SMILES",
}
FUSIONS = ["concat", "product", "attention"]
BASELINES = ["deepdta_style", "graphdta_gcn_style"]
MODELS = FUSIONS + BASELINES
SEEDS = [42, 123, 2026]


def pred_csv(setting, model, seed):
    if model in FUSIONS:
        pat = f"kiba_{setting}_{model}_seed{seed}__kiba__{setting}__test_predictions.csv"
    else:
        pat = f"{model}__kiba_{setting}_seed{seed}__kiba__{setting}__test_predictions.csv"
    hits = list(EVAL.rglob(pat))
    if not hits:
        raise FileNotFoundError(pat)
    return hits[0]


def load_setting_seed(setting, group_col, seed):
    """Return entity ids, per-entity row indices, and per-model (yt, yp)."""
    frames = {}
    for model in MODELS:
        p = pred_csv(setting, model, seed)
        if not p.is_file():
            raise FileNotFoundError(p)
        frames[model] = pd.read_csv(p)
    base = frames[MODELS[0]]
    n = len(base)
    # assert all models share identical rows/order and true labels
    for model in MODELS[1:]:
        d = frames[model]
        if len(d) != n:
            raise RuntimeError(f"row count mismatch {model}")
        if not np.allclose(d["Label_norm"].to_numpy(float),
                           base["Label_norm"].to_numpy(float)):
            raise RuntimeError(f"true label mismatch {model}")
        if not (d[group_col].to_numpy() == base[group_col].to_numpy()).all():
            raise RuntimeError(f"entity key mismatch {model}")

    entities = base[group_col].to_numpy()
    uniq_entities = pd.unique(entities)
    entity_idx = {e: np.flatnonzero(entities == e) for e in uniq_entities}
    model_data = {
        m: (frames[m]["Label_norm"].to_numpy(np.float64),
            frames[m]["Prediction_norm"].to_numpy(np.float64))
        for m in MODELS
    }
    return list(uniq_entities), entity_idx, model_data


def build_pair_counts(yt, yp, row_idx_a, row_idx_b):
    """Concordant numerator (conc + 0.5 pred-tie) and comparable count over
    all record pairs between index sets a and b (a may equal b)."""
    ya, pa = yt[row_idx_a], yp[row_idx_a]
    yb, pb = yt[row_idx_b], yp[row_idx_b]
    dyt = ya[:, None] - yb[None, :]
    dyp = pa[:, None] - pb[None, :]
    comparable = dyt != 0.0
    if row_idx_a is row_idx_b or np.array_equal(row_idx_a, row_idx_b):
        # use upper triangle to avoid double counting and self pairs
        iu = np.triu_indices(len(row_idx_a), k=1)
        comparable = comparable[iu]
        dyt, dyp = dyt[iu], dyp[iu]
    concord = (dyt * dyp > 0.0) & comparable
    pred_tie = (dyp == 0.0) & comparable
    num = float(concord.sum()) + 0.5 * float(pred_tie.sum())
    den = float(comparable.sum())
    return num, den


def build_one_model_matrix(uniq_entities, entity_idx, yt, yp):
    """Within vectors and symmetric cross matrices (zero diagonal) for one model."""
    E = len(uniq_entities)
    w_num = np.zeros(E)
    w_den = np.zeros(E)
    x_num = np.zeros((E, E))
    x_den = np.zeros((E, E))
    for i, e in enumerate(uniq_entities):
        idx = entity_idx[e]
        w_num[i], w_den[i] = build_pair_counts(yt, yp, idx, idx)
    for i in range(E):
        for j in range(i + 1, E):
            n, d = build_pair_counts(yt, yp,
                                     entity_idx[uniq_entities[i]],
                                     entity_idx[uniq_entities[j]])
            x_num[i, j] = x_num[j, i] = n
            x_den[i, j] = x_den[j, i] = d
    # observed full-data C-index
    obs_num = w_num.sum() + 0.5 * x_num.sum()
    obs_den = w_den.sum() + 0.5 * x_den.sum()
    return {
        "w_num": w_num, "w_den": w_den,
        "x_num": x_num, "x_den": x_den,
        "observed_cindex": obs_num / obs_den if obs_den else np.nan,
    }


def build_matrices(uniq_entities, entity_idx, model_data):
    """Per-model within vectors and symmetric cross matrices (zero diagonal)."""
    return {
        model: build_one_model_matrix(uniq_entities, entity_idx, *model_data[model])
        for model in MODELS
    }


def resample_cindex(mat, k):
    """Exact C-index under entity multiplicity vector k."""
    k2 = k * k
    num = float(k2 @ mat["w_num"]) + 0.5 * float(k @ mat["x_num"] @ k)
    den = float(k2 @ mat["w_den"]) + 0.5 * float(k @ mat["x_den"] @ k)
    return num / den if den else np.nan


def ranking(values):
    order = sorted(MODELS, key=lambda m: values[m], reverse=True)
    return order


def self_test():
    """Validate the weighted formula against direct, explicit duplication."""
    rng = np.random.default_rng(1)
    # 3 tiny entities
    data = {}
    ent_rows = []
    for e in range(3):
        a = rng.integers(4, 7)
        yt = rng.random(a)
        yp = yt + rng.normal(0, 0.1, a)
        ent_rows.append((np.full(a, e), yt, yp))
    ent = np.concatenate([x[0] for x in ent_rows])
    yt = np.concatenate([x[1] for x in ent_rows])
    yp = np.concatenate([x[2] for x in ent_rows])
    uniq = [0, 1, 2]
    eidx = {e: np.flatnonzero(ent == e) for e in uniq}
    mat = build_one_model_matrix(uniq, eidx, yt, yp)
    k = np.array([2, 1, 3])
    # explicit pooled arrays with duplication
    pooled_t, pooled_p = [], []
    for e, kk in enumerate(k):
        for _ in range(kk):
            pooled_t.append(yt[eidx[e]])
            pooled_p.append(yp[eidx[e]])
    pt = np.concatenate(pooled_t)
    pp = np.concatenate(pooled_p)
    # direct pairwise
    num = den = 0.0
    for i in range(len(pt)):
        for j in range(i + 1, len(pt)):
            if pt[i] == pt[j]:
                continue
            den += 1
            if pp[i] == pp[j]:
                num += 0.5
            elif (pp[i] > pp[j]) == (pt[i] > pt[j]):
                num += 1
    direct = num / den
    fast = resample_cindex(mat, k)
    assert abs(direct - fast) < 1e-12, (direct, fast)
    print("SELF TEST PASS: weighted formula matches explicit duplication "
          f"({direct:.6f} == {fast:.6f})")


def jackknife_analysis(precomp, setting, seed):
    """Leave-one-entity-out: does the ranking survive removing any single entity?"""
    pc = precomp[setting][seed]
    E = pc["n_entities"]
    entities = pc["entities"]
    mats = pc["mats"]
    obs_ranking = ranking({m: mats[m]["observed_cindex"] for m in MODELS})
    flips = []
    for e in range(E):
        k = np.ones(E, dtype=int)
        k[e] = 0
        r = ranking({m: resample_cindex(mats[m], k) for m in MODELS})
        if r != obs_ranking:
            flips.append({"removed_entity": str(entities[e]), "ranking": r})
    return {
        "n_entities": E,
        "observed_ranking": obs_ranking,
        "n_orderings_preserved": E - len(flips),
        "all_preserved": len(flips) == 0,
        "flips": flips,
    }


def seed_rank_agreement(precomp, setting):
    """Observed per-seed rankings and whether they are identical across seeds."""
    rankings = {}
    for s in SEEDS:
        mats = precomp[setting][s]["mats"]
        rankings[s] = ranking({m: mats[m]["observed_cindex"] for m in MODELS})
    first = rankings[SEEDS[0]]
    return {
        "per_seed_ranking": {str(s): r for s, r in rankings.items()},
        "identical_across_seeds": all(r == first for r in rankings.values()),
    }


def pooled_bootstrap(precomp, setting, n_boot, rng):
    """Same entity resample applied to all seeds; rank by mean C-index to match
    the three-seed mean ranking reported in S22."""
    E = precomp[setting][SEEDS[0]]["n_entities"]
    obs_mean = {
        m: float(np.mean([precomp[setting][s]["mats"][m]["observed_cindex"]
                          for s in SEEDS]))
        for m in MODELS
    }
    obs_ranking = ranking(obs_mean)
    boot = {m: np.zeros(n_boot) for m in MODELS}
    identical = 0
    for b in range(n_boot):
        k = np.bincount(rng.integers(0, E, size=E), minlength=E)
        vals = {}
        for m in MODELS:
            c = float(np.mean([resample_cindex(precomp[setting][s]["mats"][m], k)
                               for s in SEEDS]))
            boot[m][b] = c
            vals[m] = c
        if ranking(vals) == obs_ranking:
            identical += 1
    ci = {
        m: {
            "observed_mean_cindex": obs_mean[m],
            "ci95_low": float(np.percentile(boot[m], 2.5)),
            "ci95_high": float(np.percentile(boot[m], 97.5)),
        }
        for m in MODELS
    }
    return {
        "observed_mean_ranking": obs_ranking,
        "prob_ranking_identical": identical / n_boot,
        "model_mean_cindex_ci": ci,
    }


def pooled_jackknife(precomp, setting):
    """Leave-one-entity-out on the three-seed mean ranking."""
    E = precomp[setting][SEEDS[0]]["n_entities"]
    entities = precomp[setting][SEEDS[0]]["entities"]
    obs_mean = {
        m: float(np.mean([precomp[setting][s]["mats"][m]["observed_cindex"]
                          for s in SEEDS]))
        for m in MODELS
    }
    obs_ranking = ranking(obs_mean)
    flips = []
    for e in range(E):
        k = np.ones(E, dtype=int)
        k[e] = 0
        vals = {
            m: float(np.mean([resample_cindex(precomp[setting][s]["mats"][m], k)
                              for s in SEEDS]))
            for m in MODELS
        }
        r = ranking(vals)
        if r != obs_ranking:
            flips.append({"removed_entity": str(entities[e]), "ranking": r})
    return {
        "n_entities": E,
        "observed_mean_ranking": obs_ranking,
        "n_orderings_preserved": E - len(flips),
        "all_preserved": len(flips) == 0,
        "flips": flips,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-boot", type=int, default=1000)
    ap.add_argument("--bootstrap-seed", type=int, default=2026)
    args = ap.parse_args()

    self_test()
    rng = np.random.default_rng(args.bootstrap_seed)

    # precompute matrices for every (setting, seed)
    precomp = {}
    for setting, group_col in SETTINGS.items():
        precomp[setting] = {}
        for seed in SEEDS:
            uniq, eidx, mdata = load_setting_seed(setting, group_col, seed)
            precomp[setting][seed] = {
                "n_entities": len(uniq),
                "entities": list(uniq),
                "mats": build_matrices(uniq, eidx, mdata),
            }

    # the held-out entities are the same across model seeds; assert this so one
    # shared multiplicity vector can be applied to all three seeds
    for setting in SETTINGS:
        base_entities = precomp[setting][SEEDS[0]]["entities"]
        for s in SEEDS[1:]:
            if precomp[setting][s]["entities"] != base_entities:
                raise RuntimeError(f"entity sets differ across seeds in {setting}")

    rng3 = np.random.default_rng(args.bootstrap_seed + 2)
    result = {"n_boot": args.n_boot, "bootstrap_seed": args.bootstrap_seed,
              "settings": {}}

    for setting in SETTINGS:
        result["settings"][setting] = {
            "seed_rank_agreement": seed_rank_agreement(precomp, setting),
            "pooled": {
                "bootstrap": pooled_bootstrap(precomp, setting, args.n_boot, rng3),
                "jackknife": pooled_jackknife(precomp, setting),
            },
        }
        for seed in SEEDS:
            E = precomp[setting][seed]["n_entities"]
            mats = precomp[setting][seed]["mats"]
            obs_values = {m: mats[m]["observed_cindex"] for m in MODELS}
            obs_ranking = ranking(obs_values)

            boot_cindex = {m: np.zeros(args.n_boot) for m in MODELS}
            identical = 0
            for b in range(args.n_boot):
                k = np.bincount(rng.integers(0, E, size=E), minlength=E)
                vals = {}
                for m in MODELS:
                    c = resample_cindex(mats[m], k)
                    boot_cindex[m][b] = c
                    vals[m] = c
                if ranking(vals) == obs_ranking:
                    identical += 1

            model_report = {}
            for m in MODELS:
                arr = boot_cindex[m]
                model_report[m] = {
                    "observed_cindex": obs_values[m],
                    "ci95_low": float(np.percentile(arr, 2.5)),
                    "ci95_high": float(np.percentile(arr, 97.5)),
                }
            result["settings"][setting][str(seed)] = {
                "n_entities": E,
                "observed_ranking": obs_ranking,
                "prob_ranking_identical": identical / args.n_boot,
                "model_cindex_ci": model_report,
                "jackknife": jackknife_analysis(precomp, setting, seed),
            }

    # cross-setting P(tau = -1) per seed, paired by bootstrap iteration
    def kendall_tau(order_a, order_b):
        items = list(order_a)
        n = len(items)
        pos = {x: i for i, x in enumerate(order_b)}
        ranks = [pos[x] for x in items]
        conc = disc = 0
        for i in range(n):
            for j in range(i + 1, n):
                if ranks[i] < ranks[j]:
                    conc += 1
                else:
                    disc += 1
        return (conc - disc) / (conc + disc) if (conc + disc) else np.nan

    cross = {}
    rng2 = np.random.default_rng(args.bootstrap_seed + 1)
    for seed in SEEDS:
        E_ct = precomp["cold_target"][seed]["n_entities"]
        E_cd = precomp["cold_drug"][seed]["n_entities"]
        m_ct = precomp["cold_target"][seed]["mats"]
        m_cd = precomp["cold_drug"][seed]["mats"]
        n_minus = 0
        taus = []
        for b in range(args.n_boot):
            k_ct = np.bincount(rng2.integers(0, E_ct, size=E_ct), minlength=E_ct)
            k_cd = np.bincount(rng2.integers(0, E_cd, size=E_cd), minlength=E_cd)
            r_ct = ranking({m: resample_cindex(m_ct[m], k_ct) for m in MODELS})
            r_cd = ranking({m: resample_cindex(m_cd[m], k_cd) for m in MODELS})
            t = kendall_tau(r_cd, r_ct)
            taus.append(t)
            if abs(t - (-1.0)) < 1e-12:
                n_minus += 1
        cross[str(seed)] = {
            "prob_tau_minus_one": n_minus / args.n_boot,
            "mean_tau": float(np.mean(taus)),
        }

    # pooled cross-setting tau on the three-seed mean rankings
    rng4 = np.random.default_rng(args.bootstrap_seed + 3)
    E_ct = precomp["cold_target"][SEEDS[0]]["n_entities"]
    E_cd = precomp["cold_drug"][SEEDS[0]]["n_entities"]
    n_minus = 0
    taus = []
    for b in range(args.n_boot):
        k_ct = np.bincount(rng4.integers(0, E_ct, size=E_ct), minlength=E_ct)
        k_cd = np.bincount(rng4.integers(0, E_cd, size=E_cd), minlength=E_cd)
        mean_ct = {
            m: float(np.mean([resample_cindex(precomp["cold_target"][s]["mats"][m],
                                              k_ct) for s in SEEDS]))
            for m in MODELS
        }
        mean_cd = {
            m: float(np.mean([resample_cindex(precomp["cold_drug"][s]["mats"][m],
                                              k_cd) for s in SEEDS]))
            for m in MODELS
        }
        t = kendall_tau(ranking(mean_cd), ranking(mean_ct))
        taus.append(t)
        if abs(t - (-1.0)) < 1e-12:
            n_minus += 1
    pooled_cross = {
        "prob_tau_minus_one": n_minus / args.n_boot,
        "mean_tau": float(np.mean(taus)),
    }
    result["cross_setting_tau_stability"] = {"per_seed": cross,
                                             "pooled": pooled_cross}

    out = ROOT / "reports"
    out.mkdir(exist_ok=True)
    path = out / "test_entity_bootstrap.json"
    path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print(f"\nwrote {path}")


if __name__ == "__main__":
    main()
