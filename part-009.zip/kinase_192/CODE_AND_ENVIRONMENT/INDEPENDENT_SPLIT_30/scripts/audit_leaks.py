"""Post-hoc leak audit for v2 splits (advisor-required checks).

Checks, per setting:
  1. Entity overlap across ALL pairs of splits (train-val, val-test, train-test),
     not just train-test.
  2. Identical (Canonical SMILES, Target Sequence) input pairs must NOT appear
     in two different splits, in EITHER setting.
"""
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data_final_v2" / "KIBA"

report = {}
for setting in ["cold_drug", "cold_target"]:
    d = DATA / setting
    tr = pd.read_csv(d / "train.csv")
    va = pd.read_csv(d / "val.csv")
    te = pd.read_csv(d / "test.csv")
    parts = {"train": tr, "val": va, "test": te}

    # 1. entity overlaps, all pairs
    ent = {}
    for name, df in parts.items():
        ent[name] = {
            "drug": set(df["Canonical SMILES"]),
            "prot": set(df["Target Sequence"]),
        }
    pair_overlap = {}
    for a, b in [("train", "val"), ("val", "test"), ("train", "test")]:
        pair_overlap[f"{a}-{b}"] = {
            "drug_overlap": len(ent[a]["drug"] & ent[b]["drug"]),
            "prot_overlap": len(ent[a]["prot"] & ent[b]["prot"]),
        }

    # 2. identical (drug, protein) input pairs across splits
    def keys(df):
        return set(zip(df["Canonical SMILES"], df["Target Sequence"]))
    k = {n: keys(df) for n, df in parts.items()}
    pair_leak = {}
    for a, b in [("train", "val"), ("val", "test"), ("train", "test")]:
        pair_leak[f"{a}-{b}"] = len(k[a] & k[b])

    report[setting] = {
        "rows": {n: len(df) for n, df in parts.items()},
        "entity_overlap_all_pairs": pair_overlap,
        "identical_pair_leak_all_pairs": pair_leak,
    }

out = ROOT / "SPLIT_V2_LEAK_AUDIT.json"
out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(report, indent=2, ensure_ascii=False))

# verdict
ok = True
for setting, r in report.items():
    for pair, n in r["identical_pair_leak_all_pairs"].items():
        if n != 0:
            ok = False
    eo = r["entity_overlap_all_pairs"]
    if setting == "cold_drug":
        for pair, v in eo.items():
            if v["drug_overlap"] != 0:
                ok = False
    else:
        for pair, v in eo.items():
            if v["prot_overlap"] != 0:
                ok = False
print("\nVERDICT:", "PASS" if ok else "FAIL")
