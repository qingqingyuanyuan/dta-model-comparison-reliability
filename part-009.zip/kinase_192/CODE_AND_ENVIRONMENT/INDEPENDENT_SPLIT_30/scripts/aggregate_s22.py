"""Aggregate Table S22 from the 30 v2 robustness runs.

Rule (locked with the user):
  * Per-seed record-level C-index first, then average across the 3 seeds per
    model. NEVER average the three predictions then compute one C-index.
  * Report mean +/- SD per model per setting, the ranking, and Kendall's tau
    between the v1 (frozen) and v2 rankings for each cold setting.
  * v1 numbers are read from v1_reference/v1_kiba_rankings.json (filled from
    the frozen FINAL126 audit, not estimated).
"""
import argparse
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent


def concordance_index(y_true, y_pred) -> float:
    """Pairwise concordance C-index (ties count as 0.5)."""
    y_true = list(y_true)
    y_pred = list(y_pred)
    n = len(y_true)
    num = den = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            if y_true[i] == y_true[j]:
                continue
            den += 1.0
            if y_pred[i] == y_pred[j]:
                num += 0.5
            elif (y_pred[i] > y_pred[j]) == (y_true[i] > y_true[j]):
                num += 1.0
    return num / den if den else float("nan")


def find_cindex(d: dict):
    for k, v in d.items():
        if isinstance(v, dict):
            r = find_cindex(v)
            if r is not None:
                return r
        ks = k.lower().replace("_", "").replace("-", "")
        if "cindex" in ks or "concordance" in ks or ks == "ci":
            return float(v)
    return None


def macro_cindex(record_csv_path: Path, group_col: str):
    """Per-entity equal-weighted C-index (post-processing, no retraining).

    For cold_target use group_col='Target Sequence'; for cold_drug use
    group_col='Canonical SMILES'. Entities with fewer than 3 unique labels
    are excluded (coverage reported).
    """
    df = pd.read_csv(record_csv_path)
    yt_col, yp_col = "Label_norm", "Prediction_norm"
    vals = []
    for _, g in df.groupby(group_col):
        # require >=3 unique labels (>=5 comparable pairs), else C-index too noisy
        if g[yt_col].nunique() < 3:
            continue
        vals.append(concordance_index(g[yt_col], g[yp_col]))
    n_total = int(df[group_col].nunique())
    return {
        "macro_cindex": float(sum(vals) / len(vals)) if vals else None,
        "n_entities_scored": len(vals),
        "n_entities_total": n_total,
        "coverage": (len(vals) / n_total) if n_total else None,
    }


def kendall_tau(order_a, order_b):
    """Kendall tau between two rankings given as ordered lists of same items."""
    pos_b = {m: i for i, m in enumerate(order_b)}
    items = list(order_a)
    n = len(items)
    concordant = discordant = 0
    for i in range(n):
        for j in range(i + 1, n):
            a_ij = pos_b[items[i]] < pos_b[items[j]]
            if a_ij:
                concordant += 1
            else:
                discordant += 1
    total = n * (n - 1) / 2
    return (concordant - discordant) / total if total else float("nan")


def exact_permutation_p_tau(order_a, order_b):
    """Exact two-sided permutation p for Kendall tau.

    Fix order_a; enumerate all n! permutations of the same items for order_b.
    p = fraction of permutations with |tau| >= observed |tau|.
    """
    import itertools
    items = list(order_a)
    obs = kendall_tau(items, list(order_b))
    count = total = 0
    for perm in itertools.permutations(items):
        t = kendall_tau(items, list(perm))
        total += 1
        if abs(t) >= abs(obs) - 1e-12:
            count += 1
    return {"kendall_tau": obs, "exact_p_two_sided": count / total,
            "n_permutations": total}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", default=ROOT / "data_final_v2")
    ap.add_argument("--eval-dir", default=ROOT / "evaluation_outputs")
    args = ap.parse_args()

    rows = []
    for meta in Path(args.eval_dir).rglob("*.json"):
        try:
            payload = json.loads(meta.read_text(encoding="utf-8"))
        except Exception:
            continue
        rlm = payload.get("record_level_metrics", {})
        c = find_cindex(rlm)
        if c is None:
            continue
        rows.append({
            "file": str(meta),
            "dataset": payload.get("dataset"),
            "setting": payload.get("setting"),
            "model": payload.get("model") or payload.get("fusion") or payload.get("baseline_name"),
            "seed": payload.get("model_seed"),
            "record_cindex": c,
            "record_prediction_file": payload.get("record_prediction_file"),
        })

    out = Path("reports")
    out.mkdir(exist_ok=True)
    (out / "v2_all_records_cindex.json").write_text(
        json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")

    # mean +/- sd per (setting, model)
    import statistics as st
    agg = {}
    for r in rows:
        agg.setdefault((r["setting"], r["model"]), []).append(r["record_cindex"])
    summary = []
    for (setting, model), vals in sorted(agg.items()):
        summary.append({
            "setting": setting, "model": model, "n_seeds": len(vals),
            "mean_cindex": st.mean(vals),
            "sd_cindex": st.pstdev(vals) if len(vals) > 1 else 0.0,
            "per_seed": vals,
        })
    (out / "table_s22_v2.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    # v2 rankings per setting (by mean C-index)
    v2_rankings = {}
    for setting in sorted({r["setting"] for r in rows}):
        v2_models = [s for s in summary if s["setting"] == setting]
        v2_rankings[setting] = [s["model"] for s in sorted(
            v2_models, key=lambda x: x["mean_cindex"], reverse=True)]

    v1_ref = ROOT / "v1_reference" / "v1_kiba_rankings.json"
    rank_comparison = {"within_setting_v1_vs_v2": {}, "cross_setting": {}}

    # Per-seed ranking stability: 3 seeds = 3 independent reproductions of the
    # same 5-model ordering. This evidence does not rely on the small-n p floor.
    seed_rankings = {}  # setting -> seed -> ordered model list
    per_seed_lookup = {}
    for r in rows:
        per_seed_lookup.setdefault((r["setting"], r["seed"]), {})[r["model"]] = r["record_cindex"]
    for (setting, seed), model_c in sorted(per_seed_lookup.items()):
        order = [m for m, _ in sorted(model_c.items(), key=lambda kv: kv[1], reverse=True)]
        seed_rankings.setdefault(setting, {})[seed] = order

    per_seed_agreement = {}
    for setting, by_seed in sorted(seed_rankings.items()):
        orders = list(by_seed.values())
        distinct = {tuple(o) for o in orders}
        per_seed_agreement[setting] = {
            "rankings_per_seed": {str(s): o for s, o in sorted(by_seed.items())},
            "identical_across_seeds": len(distinct) == 1,
            "n_seeds": len(by_seed),
        }
    rank_comparison["per_seed_rank_agreement"] = per_seed_agreement

    # Per-seed cross-setting tau (how each individual seed reproduces the inversion)
    per_seed_cross = {}
    seeds_seen = sorted({s for by_seed in seed_rankings.values() for s in by_seed})
    for seed in seeds_seen:
        if "cold_drug" in seed_rankings and "cold_target" in seed_rankings                 and seed in seed_rankings["cold_drug"] and seed in seed_rankings["cold_target"]:
            cd = seed_rankings["cold_drug"][seed]
            ct = seed_rankings["cold_target"][seed]
            common = [m for m in cd if m in ct]
            per_seed_cross[str(seed)] = exact_permutation_p_tau(
                [m for m in cd if m in common], [m for m in ct if m in common])
    rank_comparison["per_seed_cross_setting_tau"] = per_seed_cross
    if v1_ref.exists():
        v1 = json.loads(v1_ref.read_text(encoding="utf-8"))
        print("v1 reference rankings loaded")

        # (a) within-setting: did the new split reorder models relative to v1?
        for setting in sorted(v2_rankings):
            v1_ranking = v1["settings"][setting]["ranking_by_mean_cindex"]
            v2_ranking = v2_rankings[setting]
            common = [m for m in v1_ranking if m in v2_ranking]
            v1_order = [m for m in v1_ranking if m in common]
            v2_order = [m for m in v2_ranking if m in common]
            rank_comparison["within_setting_v1_vs_v2"][setting] = {
                "v1_ranking": v1_ranking,
                "v2_ranking": v2_ranking,
                **exact_permutation_p_tau(v1_order, v2_order),
                "n_models": len(common),
            }

        # (b) cross-setting: is the headline inversion reproduced on v2?
        v1_cd = v1["settings"]["cold_drug"]["ranking_by_mean_cindex"]
        v1_ct = v1["settings"]["cold_target"]["ranking_by_mean_cindex"]
        rank_comparison["cross_setting"]["v1"] = {
            "cold_drug_ranking": v1_cd,
            "cold_target_ranking": v1_ct,
            **exact_permutation_p_tau(v1_cd, v1_ct),
            "n_models": len(v1_cd),
        }
        if "cold_drug" in v2_rankings and "cold_target" in v2_rankings:
            v2_cd = v2_rankings["cold_drug"]
            v2_ct = v2_rankings["cold_target"]
            common = [m for m in v2_cd if m in v2_ct]
            rank_comparison["cross_setting"]["v2"] = {
                "cold_drug_ranking": v2_cd,
                "cold_target_ranking": v2_ct,
                **exact_permutation_p_tau([m for m in v2_cd if m in common],
                                          [m for m in v2_ct if m in common]),
                "n_models": len(common),
            }
        (out / "rank_comparison_v1_v2.json").write_text(
            json.dumps(rank_comparison, indent=2, ensure_ascii=False),
            encoding="utf-8")
    else:
        print("WARNING: v1_reference/v1_kiba_rankings.json missing; rank comparison NOT computed")

    # Macro (per-entity equal-weighted) C-index: v2-only diagnostic. v1 has no
    # macro counterpart, so no v1<->v2 macro comparison is made.
    GROUP_COL = {"cold_target": "Target Sequence", "cold_drug": "Canonical SMILES"}
    macro_entries = []
    for r in rows:
        pred_csv = r.get("record_prediction_file")
        setting = r["setting"]
        if pred_csv and setting in GROUP_COL and Path(pred_csv).is_file():
            macro_entries.append({**r, "macro": macro_cindex(Path(pred_csv), GROUP_COL[setting])})
    macro_agg = {}
    for r in macro_entries:
        macro_agg.setdefault((r["setting"], r["model"]), []).append(r["macro"])
    macro_summary = []
    for (setting, model), entries in sorted(macro_agg.items()):
        vals = [e["macro_cindex"] for e in entries if e["macro_cindex"] is not None]
        first = entries[0]
        macro_summary.append({
            "setting": setting, "model": model, "n_seeds": len(entries),
            "mean_macro_cindex": st.mean(vals) if vals else None,
            "sd_macro_cindex": st.pstdev(vals) if len(vals) > 1 else 0.0,
            "per_seed_macro": [e["macro_cindex"] for e in entries],
            "n_entities_scored": first["n_entities_scored"],
            "n_entities_total": first["n_entities_total"],
            "coverage": first["coverage"],
        })
    (out / "macro_summary.json").write_text(
        json.dumps(macro_summary, indent=2, ensure_ascii=False), encoding="utf-8")

    macro_rankings = {}
    for setting in sorted({s["setting"] for s in macro_summary}):
        ms = [s for s in macro_summary if s["setting"] == setting]
        macro_rankings[setting] = [s["model"] for s in sorted(
            ms, key=lambda x: x["mean_macro_cindex"], reverse=True)]

    # micro vs macro ranking tau: same predictions, two weighting schemes.
    # tau=+1 -> record-level ranking is not driven by high-degree entities.
    micro_macro_tau = {}
    for setting in sorted(macro_rankings):
        if setting in v2_rankings:
            micro_r, macro_r = v2_rankings[setting], macro_rankings[setting]
            common = [m for m in micro_r if m in macro_r]
            micro_macro_tau[setting] = {
                "micro_ranking": micro_r,
                "macro_ranking": macro_r,
                **exact_permutation_p_tau([m for m in micro_r if m in common],
                                          [m for m in macro_r if m in common]),
                "n_models": len(common),
            }
    rank_comparison["micro_vs_macro_ranking"] = micro_macro_tau

    # also write a combined table including all tau
    table_payload = {
        "per_model_summary": summary,
        "macro_summary": macro_summary,
        "rank_comparison": rank_comparison,
    }
    (out / "table_s22_v2.json").write_text(
        json.dumps(table_payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(rank_comparison, indent=2, ensure_ascii=False))
    print(f"\nwrote reports/table_s22_v2.json ({len(rows)} seed-level records)")


if __name__ == "__main__":
    main()
