#!/usr/bin/env python3
"""Subset lane launcher: trains only an explicit, disjoint list of run stems.

Same protocol as train_lane.py (batch 64, paired seeds, frozen splits); it only
restricts which runs are scheduled, so two processes can cover disjoint subsets
without changing config.py or the frozen plan hash.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import run_capacity_matched as m  # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--baseline", required=True)
    p.add_argument("--stems", required=True, help="comma-separated run stems")
    p.add_argument("--data-root", type=Path, default=ROOT / "data_final")
    p.add_argument("--plan-file", type=Path,
                   default=ROOT / "experiments" / "capacity_matched_plan.json")
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--device", default="auto")
    p.add_argument("--no-progress", action="store_true")
    a = p.parse_args()

    wanted = {s.strip() for s in a.stems.split(",") if s.strip()}
    rows = [
        r for r in m.build_matrix()
        if r["baseline"] == a.baseline and r["stem"] in wanted
    ]
    missing = wanted - {r["stem"] for r in rows}
    if missing:
        raise ValueError(f"stems not found in matrix: {sorted(missing)}")

    args = SimpleNamespace(
        data_root=a.data_root,
        num_workers=a.num_workers,
        device=a.device,
        overwrite=False,
        continue_on_error=True,
        no_progress=a.no_progress,
        plan_file=a.plan_file,
    )

    print(f"LANE-SUBSET {a.baseline}: {len(rows)} runs", flush=True)
    for i, row in enumerate(rows, 1):
        print(f"\n[{i}/{len(rows)}] {row['stem']}", flush=True)
        if m._checkpoint_matches(row) and not args.overwrite:
            print("SKIP: valid checkpoint exists", flush=True)
            continue
        try:
            m._train_one(row, args)
        except Exception:
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    main()
