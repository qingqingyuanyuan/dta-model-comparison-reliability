#!/usr/bin/env python3
"""Strict, standalone Table S22 post-processing for the KIBA v2 30-run campaign.

No training or evaluation is launched here. By default this script ONLY checks
whether all 30 expected evaluation artifacts are ready and consistent. Pass
--write after the 30 evaluations have finished to independently recheck the
record-level C-index from exported CSVs and produce reports/s22_verified/.

This intentionally does not replace an active run_rest.sh or overwrite any
existing reports. The S22 primary analysis is per-seed record-level C-index,
then three-seed model means and population SD (matching v1_reference), then
rankings and Kendall tau. Macro C-index is a supplementary v2-only diagnostic.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics as st
import sys

ROOT = Path(__file__).resolve().parent.parent
SETTINGS = ("cold_drug", "cold_target")
FUSIONS = ("concat", "product", "attention")
BASELINES = ("deepdta_style", "graphdta_gcn_style")
MODELS = FUSIONS + BASELINES
SEEDS = (42, 123, 2026)
EXPECTED_TEST_N = {"cold_drug": 11784, "cold_target": 26965}
GROUP_COLUMNS = {"cold_drug": "Canonical SMILES", "cold_target": "Target Sequence"}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def model_stem(setting: str, model: str, seed: int) -> str:
    if model in FUSIONS:
        return f"kiba_{setting}_{model}_seed{seed}"
    return f"{model}__kiba_{setting}_seed{seed}"


def expected_meta_filename(setting: str, model: str, seed: int) -> str:
    return f"{model_stem(setting, model, seed)}__kiba__{setting}__evaluation.json"


def expected_predict_filename(setting: str, model: str, seed: int) -> str:
    return f"{model_stem(setting, model, seed)}__kiba__{setting}__test_predictions.csv"


def require(condition: bool, message: str):
    if not condition:
        raise ValueError(message)


def read_expected(eval_dir: Path, data_root: Path, verify_checkpoint_hashes: bool):
    errors, rows = [], []
    expected_names = {
        expected_meta_filename(s, m, seed)
        for s in SETTINGS for m in MODELS for seed in SEEDS
    }
    unexpected = sorted({p.name for p in eval_dir.rglob("*__evaluation.json")} - expected_names) if eval_dir.exists() else []
    if unexpected:
        print(f"NOTE: {len(unexpected)} noncampaign evaluation JSON(s) ignored: {unexpected[:6]}")

    test_hashes = {}
    for setting in SETTINGS:
        path = data_root / "KIBA" / setting / "test.csv"
        if not path.is_file():
            errors.append(f"Missing test split: {path}")
        else:
            test_hashes[setting] = digest(path)

    for setting in SETTINGS:
        for model in MODELS:
            for seed in SEEDS:
                tag = f"{setting}/{model}/seed{seed}"
                stem = model_stem(setting, model, seed)
                meta = eval_dir / expected_meta_filename(setting, model, seed)
                if not meta.is_file():
                    errors.append(f"Missing evaluation: {tag} ({meta.name})")
                    continue
                try:
                    p = json.loads(meta.read_text(encoding="utf-8"))
                    name = p.get("fusion") if model in FUSIONS else p.get("baseline_name")
                    require(str(p.get("dataset")).upper() == "KIBA", "dataset mismatch")
                    require(p.get("setting") == setting, "setting mismatch")
                    require(str(name).lower() == model, "model identity mismatch")
                    require(int(p.get("model_seed")) == seed, "seed mismatch")
                    require(p.get("seal_scope") == "v2_robustness", "seal_scope is not v2_robustness")
                    require(p.get("primary_metrics_level") == "record", "metrics level is not record")
                    metrics = p.get("record_level_metrics") or {}
                    ci = float(metrics["ci"])  # Exact output key from train/evaluate.py
                    require(math.isfinite(ci) and 0 <= ci <= 1, "invalid C-index")
                    require(int(metrics["n"]) == EXPECTED_TEST_N[setting], "metric sample count mismatch")
                    require(int(p["test_samples"]) == EXPECTED_TEST_N[setting], "test sample count mismatch")
                    require(p.get("test_csv_sha256") == test_hashes.get(setting), "test CSV SHA-256 mismatch")
                    pred_file = Path(str(p["record_prediction_file"]))
                    require(pred_file.name == expected_predict_filename(setting, model, seed), "prediction filename mismatch")
                    require(pred_file.is_file(), "record-level prediction CSV missing")
                    checkpoint = Path(str(p["checkpoint"]))
                    require(checkpoint.name == stem + ".pt", "checkpoint filename mismatch")
                    require(checkpoint.is_file(), "checkpoint missing")
                    require(len(str(p.get("checkpoint_sha256", ""))) == 64, "checkpoint hash missing")
                    if verify_checkpoint_hashes:
                        require(digest(checkpoint) == p.get("checkpoint_sha256"), "checkpoint SHA-256 mismatch")
                    rows.append({
                        "file": str(meta), "dataset": "KIBA", "setting": setting,
                        "model": model, "seed": seed, "record_cindex": ci,
                        "record_prediction_file": str(pred_file),
                        "checkpoint_sha256": p["checkpoint_sha256"],
                        "test_csv_sha256": p["test_csv_sha256"],
                    })
                except (ValueError, TypeError, KeyError, OSError, json.JSONDecodeError) as exc:
                    errors.append(f"Invalid evaluation {tag}: {exc}")
    return rows, errors


def ci_fast(y, p):
    """Pairwise concordance including exact 0.5 prediction ties, O(n log n)."""
    import numpy as np
    y = np.asarray(y, dtype=float).reshape(-1)
    p = np.asarray(p, dtype=float).reshape(-1)
    require(len(y) == len(p) and len(y) > 0 and np.isfinite(y).all() and np.isfinite(p).all(),
            "non-finite, empty, or mismatched predictions")
    ranks = np.unique(p, return_inverse=True)[1] + 1
    order = np.argsort(y, kind="mergesort")
    y, ranks = y[order], ranks[order]
    tree = [0] * (int(ranks.max()) + 1)

    def prefix(k):
        total = 0
        while k:
            total += tree[k]
            k -= k & -k
        return total

    def add(k):
        while k < len(tree):
            tree[k] += 1
            k += k & -k

    concordant, comparable, seen = 0.0, 0, 0
    i = 0
    while i < len(y):
        j = i + 1
        while j < len(y) and y[j] == y[i]:
            j += 1
        for rank in ranks[i:j]:
            lower = prefix(int(rank) - 1)
            equal = prefix(int(rank)) - lower
            concordant += lower + 0.5 * equal
            comparable += seen
        for rank in ranks[i:j]:
            add(int(rank))
        seen += j - i
        i = j
    return concordant / comparable if comparable else 0.5


def compute_macro_and_check(rows):
    import pandas as pd
    macro_rows = []
    for row in rows:
        setting, model, seed = row["setting"], row["model"], row["seed"]
        group_col = GROUP_COLUMNS[setting]
        d = pd.read_csv(row["record_prediction_file"], usecols=[group_col, "Label_norm", "Prediction_norm"])
        require(len(d) == EXPECTED_TEST_N[setting], f"CSV row count mismatch: {setting}/{model}/{seed}")
        actual = ci_fast(d["Label_norm"].to_numpy(), d["Prediction_norm"].to_numpy())
        require(abs(actual - row["record_cindex"]) <= 1e-8,
                f"record C-index mismatch {setting}/{model}/{seed}: JSON={row['record_cindex']}, recomputed={actual}")
        vals = []
        group = d.groupby(group_col, dropna=False, sort=False)
        for _, g in group:
            if g["Label_norm"].nunique() >= 3:
                vals.append(ci_fast(g["Label_norm"].to_numpy(), g["Prediction_norm"].to_numpy()))
        n_total = int(group.ngroups)
        macro_rows.append({
            **row,
            "macro": {
                "macro_cindex": st.mean(vals) if vals else None,
                "n_entities_scored": len(vals),
                "n_entities_total": n_total,
                "coverage": len(vals) / n_total if n_total else None,
            },
        })
    return macro_rows


def ordering(mean_lookup: dict):
    require(len(mean_lookup) == len(MODELS) and set(mean_lookup) == set(MODELS), "incomplete model ranking")
    ordered = sorted(MODELS, key=lambda m: mean_lookup[m], reverse=True)
    for a, b in zip(ordered, ordered[1:]):
        require(abs(mean_lookup[a] - mean_lookup[b]) > 1e-12, f"C-index tie in ranking: {a}, {b}")
    return ordered


def tau(a, b):
    require(len(a) == len(b) == len(MODELS) and set(a) == set(b) == set(MODELS), "rankings do not contain same five models")
    pos = {m: i for i, m in enumerate(b)}
    inversions = sum(pos[a[i]] > pos[a[j]] for i in range(len(a)) for j in range(i + 1, len(a)))
    return 1 - 2 * inversions / (len(a) * (len(a) - 1) / 2)


def tau_with_p(a, b):
    observed = tau(a, b)
    all_tau = [tau(a, perm) for perm in itertools.permutations(a)]
    p_two = sum(abs(x) >= abs(observed) - 1e-12 for x in all_tau) / len(all_tau)
    return {"kendall_tau": observed, "exact_p_two_sided": p_two, "n_permutations": len(all_tau)}


def build_reports(rows, macro_rows, v1):
    lookup = {(r["setting"], r["model"], r["seed"]): r["record_cindex"] for r in rows}
    require(len(lookup) == 30, "duplicate or missing model/setting/seed rows")
    summary, v2_orders, per_seed_orders = [], {}, {}
    for setting in SETTINGS:
        means = {}
        per_seed_orders[setting] = {}
        for model in MODELS:
            vals = [lookup[(setting, model, seed)] for seed in SEEDS]
            means[model] = st.mean(vals)
            summary.append({"setting": setting, "model": model, "n_seeds": 3,
                            "mean_cindex": means[model], "sd_cindex": st.pstdev(vals),
                            "per_seed": vals, "seeds": list(SEEDS)})
        v2_orders[setting] = ordering(means)
        for seed in SEEDS:
            per_seed_orders[setting][seed] = ordering({m: lookup[(setting, m, seed)] for m in MODELS})
    v1_orders = {}
    for setting in SETTINGS:
        spec = v1["settings"][setting]
        v1_orders[setting] = list(spec["ranking_by_mean_cindex"])
        require(set(v1_orders[setting]) == set(MODELS) and len(v1_orders[setting]) == len(MODELS),
                "v1 ranking does not have five original models")
    comparisons = {
        "within_setting_v1_vs_v2": {
            setting: {"v1_ranking": v1_orders[setting], "v2_ranking": v2_orders[setting],
                      **tau_with_p(v1_orders[setting], v2_orders[setting]), "n_models": 5}
            for setting in SETTINGS
        },
        "cross_setting": {
            "v1": {"cold_drug_ranking": v1_orders["cold_drug"],
                   "cold_target_ranking": v1_orders["cold_target"],
                   **tau_with_p(v1_orders["cold_drug"], v1_orders["cold_target"]), "n_models": 5},
            "v2": {"cold_drug_ranking": v2_orders["cold_drug"],
                   "cold_target_ranking": v2_orders["cold_target"],
                   **tau_with_p(v2_orders["cold_drug"], v2_orders["cold_target"]), "n_models": 5},
        },
        "per_seed_rank_agreement": {
            setting: {"rankings_per_seed": {str(seed): per_seed_orders[setting][seed] for seed in SEEDS},
                      "identical_across_seeds": len(set(tuple(per_seed_orders[setting][seed]) for seed in SEEDS)) == 1,
                      "n_seeds": 3}
            for setting in SETTINGS
        },
        "per_seed_cross_setting_tau": {
            str(seed): tau_with_p(per_seed_orders["cold_drug"][seed], per_seed_orders["cold_target"][seed])
            for seed in SEEDS
        },
    }
    macro_summary = []
    macro_map = {(r["setting"], r["model"], r["seed"]): r["macro"] for r in macro_rows}
    for setting in SETTINGS:
        for model in MODELS:
            entries = [macro_map[(setting, model, seed)] for seed in SEEDS]
            v = [e["macro_cindex"] for e in entries]
            require(all(x is not None for x in v), "missing macro C-index")
            macro_summary.append({
                "setting": setting, "model": model, "n_seeds": 3,
                "mean_macro_cindex": st.mean(v), "sd_macro_cindex": st.pstdev(v),
                "per_seed_macro": v,
                "n_entities_scored": entries[0]["n_entities_scored"],
                "n_entities_total": entries[0]["n_entities_total"],
                "coverage": entries[0]["coverage"],
            })
    macro_orders = {}
    for setting in SETTINGS:
        macro_orders[setting] = ordering({r["model"]: r["mean_macro_cindex"]
                                          for r in macro_summary if r["setting"] == setting})
        comparisons.setdefault("micro_vs_macro_ranking", {})[setting] = {
            "micro_ranking": v2_orders[setting], "macro_ranking": macro_orders[setting],
            **tau_with_p(v2_orders[setting], macro_orders[setting]), "n_models": 5,
        }
    return {
        "v2_all_records_cindex.json": rows,
        "macro_summary.json": macro_summary,
        "rank_comparison_v1_v2.json": comparisons,
        "table_s22_v2.json": {"per_model_summary": summary, "macro_summary": macro_summary,
                             "rank_comparison": comparisons,
                             "notes": {"sd_definition": "population SD (ddof=0; matches v1_reference)",
                                       "primary_metric": "record-level C-index per seed, then mean across three seeds",
                                       "macro": "v2-only secondary diagnostic", "n_expected": 30}},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eval-dir", type=Path, default=ROOT / "evaluation_outputs")
    parser.add_argument("--data-root", type=Path, default=ROOT / "data_final_v2")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "reports" / "s22_verified")
    parser.add_argument("--verify-checkpoint-hashes", action="store_true")
    parser.add_argument("--write", action="store_true", help="ONLY after all 30 evaluations; recompute CSV CI and write reports")
    args = parser.parse_args()
    rows, errors = read_expected(args.eval_dir, args.data_root, args.verify_checkpoint_hashes)
    print(f"Expected 30 evaluation files; valid {len(rows)}/30.")
    if errors:
        for issue in errors[:40]:
            print("NOT READY:", issue, file=sys.stderr)
        return 2
    require(len(rows) == 30, "expected exactly 30 valid evaluation rows")
    print("PASS: all 30 evaluation metadata, sealed-test scope, test split hashes, and prediction files match.")
    if not args.write:
        print("CHECK ONLY: no reports written. To independently recompute C-index and create S22, pass --write.")
        return 0
    v1_path = ROOT / "v1_reference" / "v1_kiba_rankings.json"
    require(v1_path.is_file(), f"missing frozen v1 reference: {v1_path}")
    v1 = json.loads(v1_path.read_text(encoding="utf-8"))
    macro_rows = compute_macro_and_check(rows)
    reports = build_reports(rows, macro_rows, v1)
    targets = {name: args.output_dir / name for name in reports}
    for target in targets.values():
        require(not target.exists(), f"refusing to overwrite existing report: {target}")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, data in reports.items():
        target = targets[name]
        target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        print("WROTE:", target)
    print("PASS: independently recomputed all 30 record C-indices and generated verified S22.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print("STOP:", exc, file=sys.stderr)
        raise SystemExit(2)
