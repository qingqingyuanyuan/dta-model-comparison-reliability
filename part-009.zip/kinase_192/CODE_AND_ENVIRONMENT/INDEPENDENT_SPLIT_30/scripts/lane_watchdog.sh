#!/bin/bash
# lane_watchdog.sh - 云端看门狗：train_lane 双通道若中断则自动补启
# 不依赖本地电脑；已完成 checkpoint 会被 train_lane 自动跳过，重启安全。
BASE=/root/rivermind-data/dta_cm
CK=$BASE/checkpoints/capacity_matched
INTERVAL=300
LOG=$BASE/watchdog.log

start_lane() {
  local baseline="$1"
  local logfile="$2"
  cd "$BASE"
  setsid python3 scripts/train_lane.py --baseline "$baseline" --num-workers 4 --no-progress >> "$logfile" 2>&1 < /dev/null &
  echo "$(date '+%F %T') STARTED lane=$baseline pid=$!" >> "$LOG"
}

echo "$(date '+%F %T') watchdog online" >> "$LOG"
while true; do
  n=$(ls -1 "$CK" 2>/dev/null | wc -l)
  if [ "$n" -ge 36 ]; then
    echo "$(date '+%F %T') ALL 36 DONE (N=$n), watchdog exit" >> "$LOG"
    exit 0
  fi
  if ! pgrep -f "train_lane.py --baseline deepdta_capacity_matched" >/dev/null; then
    echo "$(date '+%F %T') deepdta lane MISSING (N=$n), restarting" >> "$LOG"
    start_lane "deepdta_capacity_matched" "$BASE/lane_deepdta.log"
    sleep 20
  fi
  if ! pgrep -f "train_lane.py --baseline graphdta_gcn_capacity_matched" >/dev/null; then
    echo "$(date '+%F %T') graphdta lane MISSING (N=$n), restarting" >> "$LOG"
    start_lane "graphdta_gcn_capacity_matched" "$BASE/lane_graphdta.log"
    sleep 20
  fi
  echo "$(date '+%F %T') heartbeat N=$n lanes_alive=$(pgrep -f train_lane.py | wc -l)" >> "$LOG"
  sleep "$INTERVAL"
done
