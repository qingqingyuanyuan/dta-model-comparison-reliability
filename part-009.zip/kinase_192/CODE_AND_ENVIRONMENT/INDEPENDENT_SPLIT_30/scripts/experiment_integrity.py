"""Shared integrity checks for the full prespecified training program.

The purpose is to keep held-out test access sealed until *all* model families
that were prespecified before test access—primary fusion models, controlled
baselines and sensitivity variants—have completed training.
"""

from __future__ import annotations

import itertools
import os
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import config as cfg


ROBUSTNESS_SCOPE = os.environ.get("DTA_SEAL_SCOPE", "").strip()


def expected_robustness_v2_rows():
    """R2#1 independent-split campaign: 30 declared runs (KIBA x 2 settings).

    18 primary fusion rows (3 fusions x 3 seeds) + 12 controlled baseline rows
    (2 baselines x 3 seeds). The main-campaign 126-run seal is unchanged.
    """
    rows = []
    for setting, fusion, seed in itertools.product(
        ["cold_drug", "cold_target"],
        cfg.EXPERIMENT_MATRIX["fusions"],
        cfg.EXPERIMENT_MATRIX["model_seeds"],
    ):
        stem = f"kiba_{setting}_{fusion}_seed{seed}"
        rows.append({
            "family": "primary",
            "dataset": "KIBA",
            "setting": setting,
            "model": fusion,
            "seed": int(seed),
            "stem": stem,
            "checkpoint": Path(cfg.MODEL_DIR) / f"{stem}.pt",
        })
    for setting, baseline, seed in itertools.product(
        ["cold_drug", "cold_target"],
        cfg.BASELINE_EXPERIMENT_MATRIX["baselines"],
        cfg.BASELINE_EXPERIMENT_MATRIX["model_seeds"],
    ):
        stem = f"{baseline}__kiba_{setting}_seed{seed}"
        rows.append({
            "family": "controlled_baseline",
            "dataset": "KIBA",
            "setting": setting,
            "model": baseline,
            "seed": int(seed),
            "stem": stem,
            "checkpoint": Path(cfg.MODEL_DIR) / "baselines" / f"{stem}.pt",
        })
    return rows


def trusted_load(path: Path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def expected_primary_rows():
    rows = []
    for dataset, setting, fusion, seed in itertools.product(
        cfg.EXPERIMENT_MATRIX["datasets"],
        cfg.EXPERIMENT_MATRIX["settings"],
        cfg.EXPERIMENT_MATRIX["fusions"],
        cfg.EXPERIMENT_MATRIX["model_seeds"],
    ):
        dataset = str(dataset).upper()
        setting = str(setting).lower()
        fusion = str(fusion).lower()
        seed = int(seed)
        stem = f"{dataset.lower()}_{setting}_{fusion}_seed{seed}"
        rows.append(
            {
                "family": "primary",
                "dataset": dataset,
                "setting": setting,
                "model": fusion,
                "seed": seed,
                "stem": stem,
                "checkpoint": Path(cfg.MODEL_DIR) / f"{stem}.pt",
            }
        )
    return rows


def expected_baseline_rows():
    rows = []
    for dataset, setting, baseline, seed in itertools.product(
        cfg.BASELINE_EXPERIMENT_MATRIX["datasets"],
        cfg.BASELINE_EXPERIMENT_MATRIX["settings"],
        cfg.BASELINE_EXPERIMENT_MATRIX["baselines"],
        cfg.BASELINE_EXPERIMENT_MATRIX["model_seeds"],
    ):
        dataset = str(dataset).upper()
        setting = str(setting).lower()
        baseline = str(baseline).lower()
        seed = int(seed)
        stem = f"{baseline}__{dataset.lower()}_{setting}_seed{seed}"
        rows.append(
            {
                "family": "controlled_baseline",
                "dataset": dataset,
                "setting": setting,
                "model": baseline,
                "seed": seed,
                "stem": stem,
                "checkpoint": Path(cfg.MODEL_DIR) / "baselines" / f"{stem}.pt",
            }
        )
    return rows


def expected_sensitivity_rows():
    rows = []
    for dataset, setting, variant, seed in itertools.product(
        cfg.SENSITIVITY_EXPERIMENT_MATRIX["datasets"],
        cfg.SENSITIVITY_EXPERIMENT_MATRIX["settings"],
        cfg.SENSITIVITY_EXPERIMENT_MATRIX["variants"],
        cfg.SENSITIVITY_EXPERIMENT_MATRIX["model_seeds"],
    ):
        dataset = str(dataset).upper()
        setting = str(setting).lower()
        variant = str(variant)
        seed = int(seed)
        spec = cfg.SENSITIVITY_EXPERIMENTS[variant]
        fusion = str(spec["fusion"]).lower()
        stem = f"sensitivity__{variant}__{dataset.lower()}_{setting}_{fusion}_seed{seed}"
        rows.append(
            {
                "family": "sensitivity",
                "dataset": dataset,
                "setting": setting,
                "model": variant,
                "fusion": fusion,
                "seed": seed,
                "stem": stem,
                "overrides": spec["overrides"],
                "checkpoint": Path(cfg.MODEL_DIR) / "sensitivity" / f"{stem}.pt",
            }
        )
    return rows


def checkpoint_matches(row: dict) -> bool:
    path = Path(row["checkpoint"])
    if not path.exists():
        return False
    try:
        ck = trusted_load(path)
        if not isinstance(ck, dict):
            return False
        common = bool(
            str(ck.get("dataset", "")).upper() == row["dataset"]
            and str(ck.get("setting", "")).lower() == row["setting"]
            and int(ck.get("model_seed")) == int(row["seed"])
            and isinstance(ck.get("scaler"), dict)
            and ck["scaler"].get("fit_on") == "train_only"
            and ck.get("test_evaluated_during_training") is False
        )
        if not common:
            return False
        extra = ck.get("extra_metadata") or {}

        if row["family"] == "primary":
            return bool(
                ck.get("architecture_version") == cfg.MODEL_ARCHITECTURE_VERSION
                and str(ck.get("fusion_mode", "")).lower() == row["model"]
                and extra.get("experiment_family", "primary") == "primary"
            )

        if row["family"] == "controlled_baseline":
            baseline = row["model"]
            return bool(
                ck.get("architecture_version")
                    == cfg.BASELINES[baseline]["architecture_version"]
                and str(
                    ck.get("baseline_name") or extra.get("baseline_name") or ""
                ).lower() == baseline
                and extra.get("experiment_family") == "controlled_baseline"
            )

        if row["family"] == "sensitivity":
            config = ck.get("config") or {}
            return bool(
                ck.get("architecture_version") == cfg.MODEL_ARCHITECTURE_VERSION
                and str(ck.get("fusion_mode", "")).lower() == row["fusion"]
                and extra.get("experiment_family") == "sensitivity"
                and extra.get("sensitivity_name") == row["model"]
                and int(config["PROTEIN_ENCODER"]["max_len"])
                    == int(row["overrides"]["protein_max_len"])
                and str(config["DRUG_ENCODER"]["pooling"])
                    == str(row["overrides"]["drug_pooling"])
            )
        return False
    except Exception:
        return False


def full_training_status():
    groups = {
        "primary": expected_primary_rows(),
        "controlled_baseline": expected_baseline_rows(),
        "sensitivity": expected_sensitivity_rows(),
    }
    status = {}
    missing_all = []
    for family, rows in groups.items():
        missing = [r["stem"] for r in rows if not checkpoint_matches(r)]
        status[family] = {
            "expected": len(rows),
            "complete": len(rows) - len(missing),
            "missing": missing,
        }
        missing_all.extend(f"{family}:{x}" for x in missing)
    status["overall"] = {
        "expected": sum(x["expected"] for x in status.values()),
        "complete": sum(x["complete"] for x in status.values()),
        "all_complete": len(missing_all) == 0,
        "missing": missing_all,
    }
    return status


def require_full_training_complete():
    if ROBUSTNESS_SCOPE == "v2_robustness":
        rows = expected_robustness_v2_rows()
        missing = [r["stem"] for r in rows if not checkpoint_matches(r)]
        if missing:
            raise RuntimeError(
                f"R2#1 v2 seal: {len(rows) - len(missing)}/{len(rows)} declared runs complete. "
                "Missing/invalid:\n  " + "\n  ".join(missing[:30])
            )
        return {"scope": "v2_robustness", "expected": len(rows),
                "complete": len(rows), "missing": []}
    status = full_training_status()
    if not status["overall"]["all_complete"]:
        missing = status["overall"]["missing"]
        expected = int(status["overall"]["expected"])
        raise RuntimeError(
            f"Held-out test remains sealed because the full prespecified {expected}-run "
            "training program is incomplete. Missing/invalid checkpoints:\n  "
            + "\n  ".join(missing[:30])
            + ("\n  ..." if len(missing) > 30 else "")
        )
    return status
