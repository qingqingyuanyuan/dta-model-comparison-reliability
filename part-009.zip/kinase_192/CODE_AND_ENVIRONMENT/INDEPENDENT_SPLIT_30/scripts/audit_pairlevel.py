"""Pair-level containment + degree-distribution audit for v2 splits.

Check 1 (pair-level single-cold guarantee):
  cold_target : every drug appearing in val/test must also appear in train.
                Any (drug,protein) test pair whose drug was NEVER in train is a
                "new drug + new target" double-cold pair -> report count.
  cold_drug   : every protein appearing in val/test must also appear in train.

Check 2: degree distribution of the v2 held-out proteins vs all proteins,
         Mann-Whitney U test (so the +37% test size is a quantified feature,
         not an unexplained anomaly). Sampling was UNIFORM over proteins
         (not pair-weighted) -- recorded for the methods text.
"""
import json
from pathlib import Path
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data_final_v2" / "KIBA"
report = {}

# ---- Check 1: pair-level containment ----
tr = pd.read_csv(DATA / "cold_target" / "train.csv")
va = pd.read_csv(DATA / "cold_target" / "val.csv")
te = pd.read_csv(DATA / "cold_target" / "test.csv")
train_drugs = set(tr["Canonical SMILES"])
dt_extra_val = set(va["Canonical SMILES"]) - train_drugs
dt_extra_test = set(te["Canonical SMILES"]) - train_drugs
dt_double_pairs_val = int(va["Canonical SMILES"].isin(dt_extra_val).sum())
dt_double_pairs_test = int(te["Canonical SMILES"].isin(dt_extra_test).sum())
report["cold_target_pair_level"] = {
    "method": "every val/test drug must appear in train; leftover = double-cold pairs",
    "drugs_only_in_val_not_train": len(dt_extra_val),
    "drugs_only_in_test_not_train": len(dt_extra_test),
    "double_cold_pairs_in_val": dt_double_pairs_val,
    "double_cold_pairs_in_test": dt_double_pairs_test,
}

tr2 = pd.read_csv(DATA / "cold_drug" / "train.csv")
va2 = pd.read_csv(DATA / "cold_drug" / "val.csv")
te2 = pd.read_csv(DATA / "cold_drug" / "test.csv")
train_prots = set(tr2["Target Sequence"])
dd_extra_val = set(va2["Target Sequence"]) - train_prots
dd_extra_test = set(te2["Target Sequence"]) - train_prots
dd_double_pairs_val = int(va2["Target Sequence"].isin(dd_extra_val).sum())
dd_double_pairs_test = int(te2["Target Sequence"].isin(dd_extra_test).sum())
report["cold_drug_pair_level"] = {
    "method": "every val/test protein must appear in train; leftover = double-cold pairs",
    "proteins_only_in_val_not_train": len(dd_extra_val),
    "proteins_only_in_test_not_train": len(dd_extra_test),
    "double_cold_pairs_in_val": dd_double_pairs_val,
    "double_cold_pairs_in_test": dd_double_pairs_test,
}

# ---- Check 2: protein degree distribution, v2 test vs all ----
full = pd.read_csv(ROOT / "v1_reference" / ".." / "cleaned_full.csv")
deg_all = full.groupby("Target Sequence").size()
deg_test = te.groupby("Target Sequence").size()
u, p = stats.mannwhitneyu(deg_test.values, deg_all.values, alternative="two-sided")
report["cold_target_degree"] = {
    "sampling": "uniform over proteins (RandomState(2026)); NOT pair-weighted",
    "test_protein_degree_median": float(deg_test.median()),
    "test_protein_degree_mean": float(deg_test.mean()),
    "all_protein_degree_median": float(deg_all.median()),
    "all_protein_degree_mean": float(deg_all.mean()),
    "mannwhitney_U": float(u),
    "mannwhitney_p_two_sided": float(p),
}

out = ROOT / "SPLIT_V2_PAIRLEVEL_AUDIT.json"
out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(report, indent=2, ensure_ascii=False))
