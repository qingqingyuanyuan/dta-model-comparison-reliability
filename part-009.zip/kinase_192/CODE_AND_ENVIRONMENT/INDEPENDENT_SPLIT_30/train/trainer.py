"""Training engine for the sealed-test ZhiYao-Graph experiment protocol."""

from __future__ import annotations

import copy
import os
import random
from typing import Any, Dict, Optional

import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm


class Trainer:
    """Train on fixed train/validation splits and select by validation MSE only.

    The held-out test split is intentionally outside this class. Final test
    evaluation is performed later by ``scripts/evaluate_model.py`` after the
    experiment matrix has been fixed/trained.
    """

    def __init__(self, model, config, device=None):
        self.model = model
        self.config = copy.deepcopy(config)
        tc = self.config["TRAINING"]

        if str(self.config["PREDICTOR"].get("task", "regression")).lower() != "regression":
            raise RuntimeError("Final Trainer supports continuous DTA regression only")

        self.model_seed = int(tc.get("seed", 42))
        self._seed_runtime(self.model_seed, bool(tc.get("deterministic", True)))

        requested_device = str(tc.get("device", "auto"))
        if device is not None:
            self.device = torch.device(device)
        elif requested_device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(requested_device)

        self.model = self.model.to(self.device)
        self.criterion = nn.MSELoss(reduction="mean")

        optimizer_name = str(tc.get("optimizer", "adam")).lower()
        if optimizer_name == "adam":
            optimizer_cls = torch.optim.Adam
        elif optimizer_name == "adamw":
            optimizer_cls = torch.optim.AdamW
        else:
            raise ValueError(f"Unsupported optimizer for final protocol: {optimizer_name}")
        self.optimizer = optimizer_cls(
            self.model.parameters(),
            lr=float(tc["learning_rate"]),
            weight_decay=float(tc["weight_decay"]),
        )

        scheduler_name = str(tc.get("scheduler", "reduce_on_plateau")).lower()
        if scheduler_name != "reduce_on_plateau":
            raise ValueError(f"Unsupported scheduler for final protocol: {scheduler_name}")
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer,
            mode="min",
            factor=float(tc.get("scheduler_factor", 0.5)),
            patience=int(tc.get("scheduler_patience", 10)),
            min_lr=float(tc.get("scheduler_min_lr", 1e-6)),
        )

        self.num_epochs = int(tc["num_epochs"])
        self.patience = int(tc.get("early_stopping_patience", tc.get("patience", 30)))
        self.min_delta = float(tc.get("early_stopping_min_delta", 0.0))
        self.gradient_clip_norm = float(tc.get("gradient_clip_norm", 5.0))
        if self.num_epochs <= 0 or self.patience <= 0:
            raise ValueError("num_epochs and early_stopping_patience must be positive")
        if self.gradient_clip_norm <= 0:
            raise ValueError("gradient_clip_norm must be positive")

        self.best_val_loss = float("inf")
        self.best_epoch: Optional[int] = None
        self.stop_epoch: Optional[int] = None
        self.stop_reason = "not_started"
        self.patience_counter = 0

        self.best_model_state = None
        self.best_optimizer_state = None
        self.best_scheduler_state = None

        self.history: Dict[str, Any] = {
            "epoch": [],
            "train_loss": [],
            "val_loss": [],
            "lr": [],
        }

        print(f"Device: {self.device}")
        print(f"Model seed: {self.model_seed}")
        print(
            "Early stopping: "
            f"patience={self.patience}, min_delta={self.min_delta:g}; "
            f"max_epochs={self.num_epochs}"
        )

    @staticmethod
    def _seed_runtime(seed: int, deterministic: bool) -> None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.deterministic = bool(deterministic)
            torch.backends.cudnn.benchmark = False if deterministic else False
        # PyG scatter reductions on GPU can remain nondeterministic on some
        # hardware/PyTorch combinations, so we do not force
        # torch.use_deterministic_algorithms(True), which can make valid GNN
        # kernels fail. Seeds + deterministic cuDNN settings are recorded.

    @staticmethod
    def _batch_size(affinities: torch.Tensor) -> int:
        return int(affinities.numel())

    def train_epoch(self, train_loader) -> float:
        self.model.train()
        total_squared_error_mean = 0.0
        total_samples = 0

        if len(train_loader) == 0:
            raise ValueError("train_loader is empty")

        for drug_graphs, protein_seqs, affinities in tqdm(train_loader, desc="train"):
            drug_graphs = drug_graphs.to(self.device, non_blocking=True)
            protein_seqs = protein_seqs.to(self.device, non_blocking=True)
            affinities = affinities.to(self.device, non_blocking=True)

            self.optimizer.zero_grad(set_to_none=True)
            pred = self.model(drug_graphs, protein_seqs)
            loss = self.criterion(pred, affinities)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Non-finite training loss: {loss.item()}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(),
                max_norm=self.gradient_clip_norm,
            )
            self.optimizer.step()

            bs = self._batch_size(affinities)
            total_squared_error_mean += float(loss.item()) * bs
            total_samples += bs

        if total_samples == 0:
            raise RuntimeError("No training samples were processed")
        return total_squared_error_mean / total_samples

    @torch.no_grad()
    def evaluate(self, loader):
        """Return sample-weighted MSE, predictions and labels for train/val use."""
        self.model.eval()
        if len(loader) == 0:
            raise ValueError("evaluation loader is empty")

        weighted_loss = 0.0
        total_samples = 0
        all_preds = []
        all_labels = []

        for drug_graphs, protein_seqs, affinities in loader:
            drug_graphs = drug_graphs.to(self.device, non_blocking=True)
            protein_seqs = protein_seqs.to(self.device, non_blocking=True)
            affinities = affinities.to(self.device, non_blocking=True)

            pred = self.model(drug_graphs, protein_seqs)
            loss = self.criterion(pred, affinities)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Non-finite evaluation loss: {loss.item()}")

            bs = self._batch_size(affinities)
            weighted_loss += float(loss.item()) * bs
            total_samples += bs
            all_preds.append(pred.detach().cpu().numpy().reshape(-1))
            all_labels.append(affinities.detach().cpu().numpy().reshape(-1))

        if total_samples == 0:
            raise RuntimeError("No evaluation samples were processed")
        return (
            weighted_loss / total_samples,
            np.concatenate(all_preds, axis=0),
            np.concatenate(all_labels, axis=0),
        )

    def _is_improvement(self, val_loss: float) -> bool:
        return val_loss < (self.best_val_loss - self.min_delta)

    def _capture_best_state(self, epoch: int, val_loss: float) -> None:
        self.best_val_loss = float(val_loss)
        self.best_epoch = int(epoch)
        self.best_model_state = {
            k: v.detach().cpu().clone()
            for k, v in self.model.state_dict().items()
        }
        # Keep optimizer/scheduler states matched to the selected model state.
        self.best_optimizer_state = copy.deepcopy(self.optimizer.state_dict())
        self.best_scheduler_state = copy.deepcopy(self.scheduler.state_dict())

    def fit(self, train_loader, val_loader):
        self.stop_reason = "max_epochs_reached"

        for epoch in range(1, self.num_epochs + 1):
            lr_used = float(self.optimizer.param_groups[0]["lr"])
            train_loss = self.train_epoch(train_loader)
            val_loss, _, _ = self.evaluate(val_loader)

            self.history["epoch"].append(int(epoch))
            self.history["train_loss"].append(float(train_loss))
            self.history["val_loss"].append(float(val_loss))
            self.history["lr"].append(lr_used)

            print(
                f"Epoch {epoch:3d}/{self.num_epochs} | "
                f"train MSE={train_loss:.6f} | val MSE={val_loss:.6f} | "
                f"lr={lr_used:.2e}"
            )

            improved = self._is_improvement(val_loss)
            if improved:
                self.patience_counter = 0
            else:
                self.patience_counter += 1

            self.scheduler.step(val_loss)

            if improved:
                self._capture_best_state(epoch, val_loss)

            if self.patience_counter >= self.patience:
                self.stop_epoch = int(epoch)
                self.stop_reason = "early_stopping_patience"
                print(
                    f"Early stopping at epoch {epoch}; "
                    f"best epoch={self.best_epoch}, "
                    f"best val MSE={self.best_val_loss:.6f}"
                )
                break

        if not self.history["epoch"]:
            raise RuntimeError("Training produced no epochs")
        if self.stop_epoch is None:
            self.stop_epoch = int(self.history["epoch"][-1])
        if self.best_model_state is None:
            raise RuntimeError("No best validation state was captured")

        self.history["best_epoch"] = self.best_epoch
        self.history["best_val_loss"] = self.best_val_loss
        self.history["stop_epoch"] = self.stop_epoch
        self.history["stop_reason"] = self.stop_reason

        self.model.load_state_dict(self.best_model_state, strict=True)
        if self.best_optimizer_state is not None:
            self.optimizer.load_state_dict(self.best_optimizer_state)
        if self.best_scheduler_state is not None:
            self.scheduler.load_state_dict(self.best_scheduler_state)
        return self.history

    def save(
        self,
        path="checkpoints/best_model.pt",
        *,
        scaler=None,
        history=None,
        fusion_mode=None,
        edge_dim=None,
        dataset=None,
        setting=None,
        model_seed=None,
        split_metadata=None,
        data_provenance=None,
        validation_metrics=None,
        extra_metadata=None,
    ):
        """Atomically save the best-validation checkpoint.

        Final test metrics are intentionally absent. They live in separate
        evaluation artifacts created only during the explicit test phase.
        """
        path = os.fspath(path)
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        if history is None:
            history = self.history

        save_dict: Dict[str, Any] = {
            "checkpoint_format_version": 4,
            "architecture_version": getattr(self.model, "architecture_version", None),
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict(),
            "training_state_epoch": self.best_epoch,
            "best_val_loss": float(self.best_val_loss),
            "best_epoch": self.best_epoch,
            "stop_epoch": self.stop_epoch,
            "stop_reason": self.stop_reason,
            "history": history,
            "config": copy.deepcopy(self.config),
            "model_seed": int(model_seed if model_seed is not None else self.model_seed),
            "parameter_summary": (
                self.model.parameter_summary()
                if hasattr(self.model, "parameter_summary")
                else {
                    "total": sum(
                        p.numel() for p in self.model.parameters() if p.requires_grad
                    )
                }
            ),
            "test_evaluated_during_training": False,
        }

        optional = {
            "scaler": scaler,
            "fusion_mode": fusion_mode,
            "edge_dim": edge_dim,
            "dataset": dataset,
            "setting": setting,
            "split_metadata": split_metadata,
            "data_provenance": data_provenance,
            "validation_metrics": validation_metrics,
            "extra_metadata": extra_metadata,
        }
        for key, value in optional.items():
            if value is not None:
                save_dict[key] = value

        tmp_path = path + ".tmp"
        torch.save(save_dict, tmp_path)
        os.replace(tmp_path, path)

        print(f"Saved best-validation checkpoint: {path}")
        print(f"  architecture={save_dict.get('architecture_version')}")
        print(
            f"  best_epoch={self.best_epoch}, stop_epoch={self.stop_epoch}, "
            f"stop_reason={self.stop_reason}"
        )
        print("  test evaluated during training: NO")
        return path
