#include <vector>
#include <cmath>
// y is ascending; ranks are 1-based ranks of predictions, in the same row order.
// weights are nonnegative multiplicities of rows. Equal observed labels are excluded.
extern "C" double weighted_ci(int n, const double* y, const int* ranks, const double* w) {
  std::vector<double> bit(n+2,0.0);
  auto sum=[&](int k) { double s=0; for(;k>0;k-=k&-k)s+=bit[k]; return s; };
  auto add=[&](int k,double v) { for(;k<=n+1;k+=k&-k)bit[k]+=v; };
  double prev=0, concord=0, denom=0;
  for(int a=0;a<n;) {
    int b=a+1;while(b<n && y[b]==y[a])b++;
    for(int j=a;j<b;j++) if(w[j]>0) {
      double lo=sum(ranks[j]-1),eq=sum(ranks[j])-lo;
      concord+=w[j]*(lo+0.5*eq);denom+=w[j]*prev;
    }
    for(int j=a;j<b;j++) if(w[j]>0){add(ranks[j],w[j]);prev+=w[j];}
    a=b;
  }
  return denom>0?concord/denom:NAN;
}
