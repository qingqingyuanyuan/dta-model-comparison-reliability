#!/usr/bin/env python3
"""Check original tables against recomputed frozen results; keep discrepant sources intact."""
from pathlib import Path
import argparse, re, json, zipfile, sys
import numpy as np
import pandas as pd
from docx import Document

MODELS={'ConcatFusion':'concat','ProductFusion':'product','AttentionFusion':'attention','DeepDTA-style':'deepdta_style','GraphDTA-GCN-style':'graphdta_gcn_style','DeepDTA-style baseline':'deepdta_style','GraphDTA-GCN-style baseline':'graphdta_gcn_style','Mean-pooling sensitivity':'drug_pool_mean','max_len = 1000 sensitivity':'protein_len_1000'}
MODELS.update({'ConcatFusion mean pooling':'drug_pool_mean','ConcatFusion max_len = 1000':'protein_len_1000'})
def nums(s):return [float(v) for v in re.findall(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?',s)]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source-dir',type=Path,required=True);ap.add_argument('--statistics-dir',type=Path,required=True);ap.add_argument('--final-package-dir',type=Path);a=ap.parse_args();o=a.statistics_dir
 prefix='Final' if a.final_package_dir else 'Original'
 d=Document(a.final_package_dir/'02_Supplementary/Revised_Supplementary.docx' if a.final_package_dir else next(a.source_dir.glob('revised-supplementary*.docx')));audit=[]
 def log(table,row,col,old,new,tol=0.000051):
  audit.append(dict(table=table,row=row,column=col,source_value=str(old),recomputed_value=str(new),agrees_at_display_precision=bool(abs(float(old)-float(new))<=tol),tolerance=tol))
 u=pd.read_csv(o/'Verified_UniqueInput_Metrics_All126.csv')
 for ti in [0,1]:
  for ri,row in enumerate(d.tables[ti].rows[1:],start=2):
   c=[c.text for c in row.cells];ds=c[0].lower();s=c[1].lower().replace('-','_');model=MODELS[c[2]];v=u[(u.dataset==ds)&(u.setting==s)&(u.model==model)]
   assert len(v)==3
   for j,k in enumerate(['mse_raw','rmse_raw','mae_raw','cindex'],3):
    n=nums(c[j]);log(f'S{ti+1}',ri,k+'_mean',n[0],v[k].mean());log(f'S{ti+1}',ri,k+'_sd',n[1],v[k].std(ddof=1))
 veg=pd.read_csv(o/'Verified_VEGFR2_68_Predictions.csv').set_index('Canonical SMILES')
 for ri,row in enumerate(d.tables[2].rows[1:],2):
  c=[x.text for x in row.cells];log('S3',ri,'Label_raw',float(c[1]),veg.loc[c[2],'Label_raw'],0.00000051)
 for ri,row in enumerate(d.tables[3].rows[1:],2):
  c=[x.text for x in row.cells];log('S4',ri,'Label_raw',float(c[2]),veg.loc[c[1],'Label_raw'],0.00000051)
  for j,m in enumerate(['concat','product','attention','deepdta_style','graphdta_gcn_style'],3):log('S4',ri,m,float(c[j]),veg.loc[c[1],m])
 comp=pd.read_csv(o/'Verified_Test_Composition.csv')
 for ri,row in enumerate(d.tables[4].rows[1:],2):
  c=[x.text for x in row.cells];v=comp[(comp.dataset==c[0].lower())&(comp.setting==c[1].replace('-','_'))].iloc[0]
  for j,k in enumerate(['unique_inputs','unique_drugs','unique_full_sequences'],2):log('S5',ri,k,int(c[j].replace(',','')),v[k],0)
 # S6 cannot be reproduced exactly: no original RNG seed, indices or bootstrap script supplied.
 loo=pd.read_csv(o/'UniqueInput_LOO_Summary.csv')
 for ri,row in enumerate(d.tables[6].rows[1:],2):
  c=[x.text for x in row.cells];v=loo[(loo.dataset==c[0].lower())&(loo.setting==c[1].replace('-','_'))&(loo.model==MODELS[c[2]])].iloc[0]
  log('S7',ri,'mean_rank',float(c[3]),v.mean_rank,.0051)
  limits=nums(c[4]);log('S7',ri,'min_rank',limits[0],v.rank_min,0);log('S7',ri,'max_rank',limits[1],v.rank_max,0);log('S7',ri,'mean_ci',float(c[5]),v.mean_cindex)
 vm=pd.read_csv(o/'Verified_VEGFR2_Metrics.csv');vm.seed=vm.seed.astype(str)
 for ri,row in enumerate(d.tables[8].rows[1:],2):
  c=[x.text for x in row.cells];v=vm[(vm.model==MODELS[c[0]])&(vm.seed==c[1])&(vm.subset=='all68')].iloc[0]
  for j,k in enumerate(['cindex','tau_b','rmse_raw'],2):log('S9',ri,k,float(c[j]),v[k])
 for ri,row in enumerate(d.tables[9].rows[1:],2):
  c=[x.text for x in row.cells];v=vm[(vm.model==MODELS[c[0]])&(vm.seed!='mean_prediction')&(vm.subset=='above5_33')];pooled=vm[(vm.model==MODELS[c[0]])&(vm.seed=='mean_prediction')&(vm.subset=='above5_33')].iloc[0]
  for j,nv in enumerate([v.cindex.mean(),v.cindex.std(),pooled.cindex,v.tau_b.mean(),pooled.tau_b,v.rmse_raw.mean()],1):log('S10',ri,["ci_mean","ci_sd","pooled_ci","tau_mean","pooled_tau","rmse_mean"][j-1],float(c[j]),nv)
 # Main tables and sensitivity deltas are based on unmodified formal metrics.
 main=Document(a.final_package_dir/'01_Manuscript/Revised_Manuscript.docx' if a.final_package_dir else next(a.source_dir.glob('revised-manuscript*.docx')));f=pd.read_csv(o/'Verified_Record_Cindex_All126.csv')
 for ti,ds in enumerate(['kiba','davis']):
  for ri,row in enumerate(main.tables[ti].rows[1:],2):
   c=[x.text for x in row.cells];model=MODELS[c[0]]
   for j,s in enumerate(['warm','cold_target','cold_drug'],1):
    v=f[(f.dataset==ds)&(f.setting==s)&(f.model_key==model)];n=nums(c[j]);vv=[v.rmse_raw.mean(),v.rmse_raw.std(),v.cindex.mean(),v.cindex.std()]
    for k,(old,new) in enumerate(zip(n,vv)):log('Main_1'+('A' if ti==0 else 'B'),ri,f'{s}_{k}',old,new)
 for ri,row in enumerate(main.tables[2].rows[1:],2):
  c=[x.text for x in row.cells];v=f[(f.dataset==c[0].lower())&(f.setting==c[1].replace('-','_'))].groupby('model_key').cindex.mean()
  nv=[v['concat'],v['drug_pool_mean'],v['drug_pool_mean']-v['concat'],v['protein_len_1000'],v['protein_len_1000']-v['concat']]
  for j,n in enumerate(nv,2):log('Main_2',ri,str(j),float(c[j]),n)
 pd.DataFrame(audit).to_csv(o/f'{prefix}_Table_Numeric_Audit.csv',index=False)
 # The S8 scores are supplied descriptor results, not a reexecution of RDKit fingerprints.
 sim=pd.DataFrame([[c.text for c in row.cells] for row in d.tables[7].rows[1:]],columns=['dataset','Canonical SMILES','max_ecfp4_tanimoto','scaffold_shared']);sim.dataset=sim.dataset.str.lower();sim.max_ecfp4_tanimoto=sim.max_ecfp4_tanimoto.astype(float)
 assert not sim.duplicated(['dataset','Canonical SMILES']).any()
 sim.to_csv(o/'Provided_Structural_Scores_S8.csv',index=False)
 summary=sim.groupby('dataset').max_ecfp4_tanimoto.agg(['count','mean','median','min','max']);summary.to_csv(o/'Verified_S8_Score_Summary.csv')
 # Recalculate similarity-stratified metrics using the supplied S8 descriptor scores.
 sys.path.insert(0,str(Path(__file__).parent));from recompute_statistics import CIndex
 cache=o/'_runtime_cache';cache.mkdir(parents=True,exist_ok=True)
 ci=CIndex(cache);z=zipfile.ZipFile(next(a.source_dir.glob('03-*.zip')));strat=[];ensemble=[]
 bins=[0,.2,.4,.6,.8,1.000000001]
 for ds in ['kiba','davis']:
  ss=sim[sim.dataset==ds]
  for model in ['concat','product','attention','deepdta_style','graphdta_gcn_style']:
   seed_frames=[]
   for seed in [42,123,2026]:
    suffix=f'{ds}_cold_drug_'+(f'{model}_seed{seed}' if model in ['concat','product','attention'] else f'seed{seed}')+f'__{ds}__cold_drug__unique_input_predictions.csv'
    ns=[n for n in z.namelist() if n.endswith(suffix) and ('/主模型-' in n if model in ['concat','product','attention'] else model in n and '/基线-' in n)];assert len(ns)==1
    pp=pd.read_csv(z.open(ns[0])).sort_values(['Canonical SMILES','Target Sequence']).reset_index(drop=True);assert set(pp['Canonical SMILES'])==set(ss['Canonical SMILES']);seed_frames.append(pp)
    pp=pp.merge(ss,on='Canonical SMILES',validate='many_to_one')
    for bi,(lo,hi) in enumerate(zip(bins[:-1],bins[1:])):
     q=pp[(pp.max_ecfp4_tanimoto>=lo)&(pp.max_ecfp4_tanimoto<hi)]
     strat.append(dict(dataset=ds,model=model,seed=seed,similarity_bin=['[0.0,0.2)','[0.2,0.4)','[0.4,0.6)','[0.6,0.8)','[0.8,1.0]'][bi],n_unique_inputs=len(q),n_drugs=q['Canonical SMILES'].nunique(),cindex=ci.direct(q.Label_raw.to_numpy(),q.Prediction_raw.to_numpy())[0] if len(q)>1 else np.nan,descriptor_provenance='supplied S8 scores; fingerprint generation not repeated'))
   pp=seed_frames[0].copy();pp.Prediction_raw=np.mean([x.Prediction_raw.to_numpy() for x in seed_frames],axis=0);pp=pp.merge(ss,on='Canonical SMILES',validate='many_to_one')
   for bi,(lo,hi) in enumerate(zip(bins[:-1],bins[1:])):
    q=pp[(pp.max_ecfp4_tanimoto>=lo)&(pp.max_ecfp4_tanimoto<hi)]
    ensemble.append(dict(dataset=ds,model=model,similarity_bin=['[0.0,0.2)','[0.2,0.4)','[0.4,0.6)','[0.6,0.8)','[0.8,1.0]'][bi],n_unique_inputs=len(q),n_drugs=q['Canonical SMILES'].nunique(),cindex=ci.direct(q.Label_raw.to_numpy(),q.Prediction_raw.to_numpy())[0] if len(q)>1 else np.nan,aggregation='C-index of three-seed averaged prediction; distinct from mean of per-seed C-index'))
 pd.DataFrame(strat).to_csv(o/'Verified_Similarity_Stratified_Cindex.csv',index=False,float_format='%.15g')
 pd.DataFrame(ensemble).to_csv(o/'Verified_Similarity_AveragedPrediction_Cindex.csv',index=False,float_format='%.15g')
 result={'numeric_cells_checked':len(audit),'display_mismatches':int((~pd.DataFrame(audit).agrees_at_display_precision).sum()),'S6_status':'preserved; exact original bootstrap RNG and replicate index files absent','S8_status':'SMILES/score table preserved; scalar score summaries recomputed; RDKit fingerprint and scaffold extraction not rerun','S7_status':'all displayed values verified using exact leave-one-cluster-out calculations on unique inputs, with ranks pooled over folds and three fixed seeds'}
 (o/f'{prefix}_Table_Verification_Status.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));print(pd.DataFrame(audit).query('agrees_at_display_precision==False').to_string(index=False));print(summary.to_string())
if __name__=='__main__':main()
