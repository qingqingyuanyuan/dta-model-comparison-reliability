#!/usr/bin/env python3
"""Cross-check retained S6/S8, added S11-S15, and frozen-test means in prose."""
from pathlib import Path
import argparse, json, re
import numpy as np
import pandas as pd
from docx import Document


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--package-dir', type=Path, required=True)
    a = ap.parse_args()
    s = a.package_dir / '04_Verified_Statistics'
    doc = Document(a.package_dir / '02_Supplementary/Revised_Supplementary.docx')
    audit = []
    labels = {'ConcatFusion': 'concat', 'ProductFusion': 'product',
              'AttentionFusion': 'attention', 'DeepDTA-style': 'deepdta_style',
              'GraphDTA-GCN-style': 'graphdta_gcn_style'}

    def numeric(table, row, column, actual, expected, tolerance):
        vals = [float(x) for x in re.findall(r'[-+]?\d+(?:\.\d+)?', actual)]
        expected = list(np.atleast_1d(expected))
        ok = len(vals) == len(expected) and bool(np.allclose(vals, expected, atol=tolerance, rtol=0))
        audit.append(dict(table=table, row=row, column=column, displayed=actual,
                          expected=json.dumps([float(x) for x in expected]),
                          agrees=ok, tolerance=tolerance))

    for ti, number in [(5, 6), (7, 8)]:
        original = pd.read_csv(s / f'Original_Table_S{number:02d}_Preserved.csv', dtype=str).fillna('')
        actual = [[c.text for c in r.cells] for r in doc.tables[ti].rows[1:]]
        assert len(actual) == len(original)
        for i, (current, old) in enumerate(zip(actual, original.values.tolist()), 2):
            for j, (x, y) in enumerate(zip(current, old)):
                audit.append(dict(table=f'S{number}_preserved', row=i, column=j,
                                  displayed=x, expected=y, agrees=x == y, tolerance='exact text'))

    tau = pd.read_csv(s / 'Verified_Kendall_Tau_All.csv', dtype={'seed': str})
    for ti in [10, 11]:
        for i, row in enumerate(doc.tables[ti].rows[1:], 2):
            c = [x.text for x in row.cells]
            g = tau[(tau.dataset == c[0].lower()) & (tau.pair == c[1].replace('-', '_'))]
            keys = (['original_five', 'replace_concat_with_drug_pool_mean',
                     'replace_concat_with_protein_len_1000'] if ti == 10 else ['42', '123', '2026'])
            for j, k in enumerate(keys, 2):
                z = g[(g.seed == 'mean') & (g.analysis == k)] if ti == 10 else g[(g.seed == k) & (g.analysis == 'original_five')]
                assert len(z) == 1
                numeric('S11A' if ti == 10 else 'S11B', i, j, c[j], z.tau.iloc[0], .00501)

    boot = pd.read_csv(s / 'Cluster_Bootstrap_Rank_Summary.csv')
    for i, row in enumerate(doc.tables[12].rows[1:], 2):
        c = [x.text for x in row.cells]
        dataset, scheme = c[0].split('\n')
        setting, axis = scheme.split(' / ')
        z = boot[(boot.dataset == dataset.lower()) & (boot.setting == setting.replace('-', '_')) &
                 (boot.cluster_axis == axis) & (boot.model == labels[c[2]])]
        assert len(z) == 1
        z = z.iloc[0]
        for j, expected, tol in [(1, z.n_clusters, 0), (3, z.cindex_point, .0000501),
                                  (4, [z.cindex_lower, z.cindex_upper], .0000501),
                                  (5, z.mean_rank, .00501), (6, [z.rank_lower, z.rank_upper], .000001),
                                  (7, z.p_rank1, .000501)]:
            numeric('S12', i, j, c[j], expected, tol)

    paired = pd.read_csv(s / 'Cluster_Bootstrap_Paired_Differences.csv', dtype={'seed': str})
    unique = pd.read_csv(s / 'Verified_UniqueInput_Metrics_All126.csv')
    for i, row in enumerate(doc.tables[13].rows[1:], 2):
        c = [x.text for x in row.cells]
        z = paired[(paired.dataset == c[0].lower()) & (paired.setting == 'cold_drug') &
                   (paired.metric == 'cindex') & (paired.seed == 'mean_of_three') &
                   (paired.model_a == labels[c[1]]) & (paired.model_b == labels[c[2]])]
        assert len(z) == 1
        z = z.iloc[0]
        g = unique[(unique.dataset == z.dataset) & (unique.setting == 'cold_drug')].groupby('model').cindex.mean()
        numeric('S13', i, 3, c[3], g[z.model_a] - g[z.model_b], .0000501)
        numeric('S13', i, 4, c[4], [z.delta_lower, z.delta_upper], .0000501)
        numeric('S13', i, 5, c[5], z.p_delta_gt_zero, .000501)

    distribution = pd.read_csv(s / 'Verified_Test_Label_Statistics.csv')
    for i, row in enumerate(doc.tables[14].rows[1:], 2):
        c = [x.text for x in row.cells]
        z = distribution[(distribution.dataset == c[0].lower()) &
                         (distribution.setting == c[1].replace('-', '_'))].iloc[0]
        for j, k in enumerate(['n', 'mean', 'sd', 'median', 'minimum', 'maximum'], 2):
            numeric('S14', i, j, c[j], z[k], 0 if j == 2 else .0000501)

    strat = pd.read_csv(s / 'Verified_Similarity_Stratified_Cindex.csv')
    averaged = pd.read_csv(s / 'Verified_Similarity_AveragedPrediction_Cindex.csv')
    for i, row in enumerate(doc.tables[15].rows[1:], 2):
        c = [x.text for x in row.cells]
        g = strat[(strat.dataset == c[0].lower()) & (strat.similarity_bin == c[1])]
        e = averaged[(averaged.dataset == c[0].lower()) & (averaged.similarity_bin == c[1])]
        m = g.groupby('model').cindex.mean()
        numeric('S15', i, 2, c[2], g.n_drugs.iloc[0], 0)
        numeric('S15', i, 3, c[3], g.n_unique_inputs.iloc[0], 0)
        numeric('S15', i, 4, c[4], [m.min(), m.max()], .0000501)
        numeric('S15', i, 5, c[5], [e.cindex.min(), e.cindex.max()], .0000501)

    prose_checks = []
    for relative in ['01_Manuscript/Revised_Manuscript.docx', '03_Response/Response_to_Reviewers_Revised.docx']:
        text = ' '.join(p.text for p in Document(a.package_dir / relative).paragraphs)
        for ds in ['kiba', 'davis']:
            g = distribution[distribution.dataset == ds].set_index('setting')
            expected = '/'.join(f'{g.loc[k, "mean"]:.2f}' for k in ['warm', 'cold_target', 'cold_drug'])
            prose_checks.append(dict(file=relative, statistic=f'{ds}_test_label_means',
                                     expected=expected, agrees=expected in text))
        prose_checks.append(dict(file=relative, statistic='obsolete_Davis_means_absent',
                                 expected='5.39/5.43/5.37 absent', agrees='5.39/5.43/5.37' not in text))
    pd.DataFrame(audit).to_csv(s / 'Added_And_Preserved_Table_Audit.csv', index=False)
    pd.DataFrame(prose_checks).to_csv(s / 'Narrative_Statistics_Crosscheck.csv', index=False)
    result = dict(table_checks=len(audit), mismatches=sum(not x['agrees'] for x in audit),
                  narrative_checks=len(prose_checks), narrative_mismatches=sum(not x['agrees'] for x in prose_checks),
                  scope='S6/S8 preservation; S11-S15 against analysis CSVs; both documents test-label mean prose')
    (s / 'Added_Table_Verification_Status.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    assert result['mismatches'] == result['narrative_mismatches'] == 0


if __name__ == '__main__':
    main()
