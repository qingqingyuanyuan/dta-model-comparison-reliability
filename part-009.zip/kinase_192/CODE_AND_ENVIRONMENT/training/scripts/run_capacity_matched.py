#!/usr/bin/env python3
"""Plan/train the capacity-matched controlled baseline matrix (R1#6).

Matrix: 2 datasets x 3 settings x 2 widened baseline families x 3 paired seeds = 36.
The architecture topology is identical to the original controlled baselines; only
layer widths change so each model has ~590k trainable parameters. Training uses
train+validation only; held-out test is sealed until the explicit unlock flag.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import os
import platform
import random
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import config as cfg


def _sha256(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _set_seed(seed: int):
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic = bool(cfg.TRAINING.get("deterministic", True))
        torch.backends.cudnn.benchmark = False


def _trusted_load(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def build_matrix():
    matrix = cfg.CAPACITY_MATCHED_EXPERIMENT_MATRIX
    rows = []
    for dataset, setting, baseline, seed in itertools.product(
        matrix["datasets"],
        matrix["settings"],
        matrix["baselines"],
        matrix["model_seeds"],
    ):
        dataset = str(dataset).upper()
        setting = str(setting).lower()
        baseline = str(baseline).lower()
        seed = int(seed)
        stem = f"{baseline}__{dataset.lower()}_{setting}_seed{seed}"
        rows.append(
            {
                "dataset": dataset,
                "setting": setting,
                "baseline": baseline,
                "seed": seed,
                "stem": stem,
                "checkpoint": str(
                    (cfg.worker_checkpoint_dir(baseline) / f"{stem}.pt").resolve()
                ),
            }
        )
    return rows


def _checkpoint_matches(row):
    path = Path(row["checkpoint"])
    if not path.exists():
        return False
    try:
        ck = _trusted_load(path)
        expected_arch = cfg.BASELINES[row["baseline"]]["architecture_version"]
        extra = ck.get("extra_metadata") or {}
        return bool(
            ck.get("architecture_version") == expected_arch
            and str(ck.get("dataset", "")).upper() == row["dataset"]
            and str(ck.get("setting", "")).lower() == row["setting"]
            and int(ck.get("model_seed")) == row["seed"]
            and str(extra.get("baseline_name", "")).lower() == row["baseline"]
            and ck.get("test_evaluated_during_training") is False
        )
    except Exception:
        return False


def _write_plan(rows, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "plan_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "config_sha256": _sha256(ROOT / "config.py"),
        "purpose": (
            "Capacity-matched controlled baselines (R1#6). Same topology as the "
            "original controlled baselines with widened layers to match fusion-model "
            "parameter count. Names ending in -style are not exact external-repository "
            "reproductions."
        ),
        "matrix": rows,
        "n_runs": len(rows),
        "baseline_configs": {
            k: cfg.BASELINES[k]
            for k in cfg.CAPACITY_MATCHED_EXPERIMENT_MATRIX["baselines"]
        },
        "training_protocol": cfg.TRAINING,
        "test_policy": "Held-out test sealed during training; explicit unlock required.",
    }
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def _prepare_loaders(row, bc, args):
    from baselines.dataset import create_fixed_sequence_train_val_loaders
    from data.dataset import create_fixed_train_val_loaders

    if bc["input_modality"] == "smiles_sequence+protein_sequence":
        return create_fixed_sequence_train_val_loaders(
            row["dataset"],
            row["setting"],
            data_root=Path(args.data_root),
            batch_size=int(cfg.TRAINING["batch_size"]),
            model_seed=row["seed"],
            max_smiles_len=int(bc["max_smiles_len"]),
            max_protein_len=int(bc["max_protein_len"]),
            protein_truncation="right",
            num_workers=args.num_workers,
        )
    if bc["input_modality"] == "molecular_graph+protein_sequence":
        return create_fixed_train_val_loaders(
            row["dataset"],
            row["setting"],
            data_root=Path(args.data_root),
            batch_size=int(cfg.TRAINING["batch_size"]),
            model_seed=row["seed"],
            max_len=int(bc["max_protein_len"]),
            truncation="right",
            num_workers=args.num_workers,
            show_progress=not args.no_progress,
            trim_protein_padding=True,
        )
    raise ValueError(f"Unsupported modality {bc['input_modality']}")


def _train_one(row, args):
    from baselines.dataset import sequence_truncation_report
    from baselines.registry import build_baseline_model, get_baseline_config
    from data.utils import denormalize_affinity, load_fixed_train_val
    from train.evaluate import Evaluator, METRIC_SCHEMA_VERSION
    from train.trainer import Trainer

    ckpt_path = Path(row["checkpoint"])
    out_dir = cfg.worker_training_dir(row["baseline"])
    out_dir.mkdir(parents=True, exist_ok=True)
    history_path = out_dir / f"{row['stem']}__history.csv"
    val_pred_path = out_dir / f"{row['stem']}__val_predictions.csv"
    meta_path = out_dir / f"{row['stem']}__training.json"
    existing = [p for p in (ckpt_path, history_path, val_pred_path, meta_path) if p.exists()]
    if existing and not args.overwrite:
        raise FileExistsError(
            "Capacity-matched output exists:\n  " + "\n  ".join(str(x) for x in existing)
        )

    train_df, val_df, scaler = load_fixed_train_val(
        row["dataset"], row["setting"], data_root=Path(args.data_root)
    )
    config = get_baseline_config(row["baseline"])
    config["TRAINING"]["seed"] = row["seed"]
    config["TRAINING"]["device"] = args.device
    bc = config["BASELINE"]

    _set_seed(row["seed"])
    train_loader, val_loader, scaler2 = _prepare_loaders(row, bc, args)
    if scaler2 != scaler:
        raise RuntimeError("baseline scaler mismatch")

    model = build_baseline_model(row["baseline"], config)
    params = model.parameter_summary()
    trainer = Trainer(model, config, device=None if args.device == "auto" else args.device)

    print("=" * 76)
    print("CAPACITY-MATCHED BASELINE TRAINING — TEST SEALED")
    print(f"Baseline : {row['baseline']}")
    print(f"Dataset  : {row['dataset']}")
    print(f"Setting  : {row['setting']}")
    print(f"Seed     : {row['seed']}")
    print(f"Rows     : train={len(train_df):,}, val={len(val_df):,}")
    print(f"Params   : {params['total']:,}")
    print("=" * 76)

    start = time.time()
    history = trainer.fit(train_loader, val_loader)
    val_loss, pred, true = trainer.evaluate(val_loader)
    metrics = Evaluator(scaler=scaler).evaluate(true, pred)
    if not np.isclose(val_loss, metrics["mse_norm"], atol=1e-9, rtol=1e-6):
        raise RuntimeError("Trainer val MSE mismatch")

    val_out = val_df.copy()
    if len(val_out) != len(pred) or not np.allclose(
        val_out["Label_norm"].to_numpy(float), true
    ):
        raise RuntimeError("validation loader order mismatch")
    val_out["Prediction_norm"] = pred
    val_out["Prediction_raw"] = denormalize_affinity(pred, scaler)
    val_out.to_csv(val_pred_path, index=False)
    history_columns = [
        "epoch", "train_loss", "val_loss", "lr", "val_prediction_std",
        "total_grad_norm", "protein_grad_norm", "drug_grad_norm",
        "protein_param_norm", "drug_param_norm", "protein_embedding_norm",
        "protein_token_proj_norm", "drug_input_proj_norm",
    ]
    pd.DataFrame(
        {k: history[k] for k in history_columns if k in history}
    ).to_csv(history_path, index=False)

    truncation = sequence_truncation_report(
        pd.concat([train_df, val_df], ignore_index=True),
        max_smiles_len=int(bc.get("max_smiles_len", 10**9)),
        max_protein_len=int(bc["max_protein_len"]),
    )

    split_dir = Path(args.data_root) / row["dataset"] / row["setting"]
    provenance = {
        "train": {"path": str((split_dir / "train.csv").resolve()), "sha256": _sha256(split_dir / "train.csv")},
        "val": {"path": str((split_dir / "val.csv").resolve()), "sha256": _sha256(split_dir / "val.csv")},
        "scaler": {"path": str((split_dir / "scaler.json").resolve()), "sha256": _sha256(split_dir / "scaler.json")},
        "test_policy": {"path": str((split_dir / "test.csv").resolve()), "status": "sealed_not_read_or_hashed_during_training"},
    }
    split_metadata = json.loads(
        (split_dir / "split_metadata.json").read_text(encoding="utf-8")
    )

    trainer.save(
        ckpt_path,
        scaler=scaler,
        history=history,
        dataset=row["dataset"],
        setting=row["setting"],
        model_seed=row["seed"],
        split_metadata=split_metadata,
        data_provenance=provenance,
        validation_metrics=metrics,
        extra_metadata={
            "run_kind": "revision_capacity_matched_adamw",
            "experiment_family": "revision_capacity_matched_adamw",
            "optimizer_implementation": "torch.optim.AdamW",
            "baseline_name": row["baseline"],
            "baseline_description": bc.get("description"),
            "input_modality": bc["input_modality"],
            "reporting_label": "style reimplementation; capacity-matched; AdamW; not exact published-repository reproduction",
            "truncation_audit_train_plus_val": truncation,
            "history_file": str(history_path.resolve()),
            "validation_prediction_file": str(val_pred_path.resolve()),
            "metric_schema_version": METRIC_SCHEMA_VERSION,
            "test_policy": "sealed_not_evaluated_during_training",
        },
    )

    ck = _trusted_load(ckpt_path)
    ck["baseline_name"] = row["baseline"]
    tmp_ckpt = ckpt_path.with_suffix(ckpt_path.suffix + ".tmp")
    torch.save(ck, tmp_ckpt)
    os.replace(tmp_ckpt, ckpt_path)

    run_meta = {
        "experiment_family": "revision_capacity_matched_adamw",
        "optimizer_implementation": "torch.optim.AdamW",
        "baseline_name": row["baseline"],
        "architecture_version": bc["architecture_version"],
        "dataset": row["dataset"],
        "setting": row["setting"],
        "model_seed": row["seed"],
        "validation_metrics": metrics,
        "parameter_summary": params,
        "truncation_audit_train_plus_val": truncation,
        "elapsed_seconds": float(time.time() - start),
        "checkpoint": str(ckpt_path.resolve()),
        "checkpoint_sha256": _sha256(ckpt_path),
        "test_evaluated": False,
        "python": platform.python_version(),
        "torch": torch.__version__,
    }
    tmp = meta_path.with_suffix(meta_path.suffix + ".tmp")
    tmp.write_text(json.dumps(run_meta, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, meta_path)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--phase", choices=["plan", "train"], default="plan")
    p.add_argument("--data-root", type=Path, default=cfg.FROZEN_DATA_ROOT)
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--device", default="auto")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--continue-on-error", action="store_true")
    p.add_argument("--no-progress", action="store_true")
    p.add_argument(
        "--plan-file",
        type=Path,
        default=cfg.REVISION_ROOT / "capacity_matched_adamw_plan.json",
    )
    args = p.parse_args()
    rows = build_matrix()

    if args.phase == "plan":
        _write_plan(rows, args.plan_file)
        print(f"Capacity-matched plan: {args.plan_file}")
        print(f"Runs: {len(rows)}")
        return

    if not args.plan_file.exists():
        raise FileNotFoundError(
            f"Run --phase plan first; frozen plan missing: {args.plan_file}"
        )
    plan = json.loads(args.plan_file.read_text(encoding="utf-8"))
    if plan.get("config_sha256") != _sha256(ROOT / "config.py"):
        raise RuntimeError("config.py changed after plan was frozen; regenerate the plan.")

    for i, row in enumerate(rows, 1):
        print(f"\n[{i}/{len(rows)}] {row['stem']}")
        if _checkpoint_matches(row) and not args.overwrite:
            print("SKIP: valid checkpoint exists")
            continue
        try:
            _train_one(row, args)
        except Exception:
            if not args.continue_on_error:
                raise
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    main()
