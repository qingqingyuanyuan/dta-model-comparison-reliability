#!/usr/bin/env python3
"""Three-seed aggregation of the 36 capacity-matched held-out evaluations.

Self-contained: reads only the widened evaluation JSONs. Produces per-run wide
table and grouped (baseline x dataset x setting) per-seed / mean / sample-SD /
range summaries at both record and unique-input levels. No retraining.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import config as cfg  # noqa: E402
OUT_DIR = cfg.REVISION_ROOT / "aggregation_combined"
SEEDS = [42, 123, 2026]
METRICS = ["ci", "mse_norm", "rmse_norm", "mae_norm",
           "mse_raw", "rmse_raw", "mae_raw"]
LEVELS = [("record_level_metrics", "record"),
          ("unique_input_level_metrics", "unique_input")]


def load_runs():
    runs = []
    for worker in ("worker_A", "worker_B"):
        eval_dir = cfg.REVISION_ROOT / worker / "evaluation_outputs"
        for jf in sorted(eval_dir.glob("*__evaluation.json")):
            d = json.loads(jf.read_text(encoding="utf-8"))
            runs.append(d)
    return runs


def main():
    runs = load_runs()
    assert len(runs) == 36, f"expected 36 eval json, got {len(runs)}"
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # ---- per-run wide table ----
    wide = []
    for d in runs:
        row = {
            "baseline": d["baseline_name"],
            "dataset": d["dataset"].lower(),
            "setting": d["setting"],
            "seed": d["model_seed"],
            "test_samples": d["test_samples"],
            "unique_inputs": d["unique_model_inputs"],
            "params_total": (d["parameter_summary"] or {}).get("total"),
            "checkpoint_sha256": d["checkpoint_sha256"],
        }
        for src, lab in LEVELS:
            for k in METRICS:
                row[f"{lab}_{k}"] = d[src][k]
        wide.append(row)
    wide_df = pd.DataFrame(wide).sort_values(
        ["baseline", "dataset", "setting", "seed"]).reset_index(drop=True)
    wide_df.to_csv(OUT_DIR / "cm-per-run-wide.csv", index=False, encoding="utf-8")

    # ---- grouped summary (long) ----
    keys = wide_df[["baseline", "dataset", "setting"]].drop_duplicates()
    summary_rows = []
    nested = {}
    for _, k in keys.sort_values(["baseline", "dataset", "setting"]).iterrows():
        b, ds, st = k["baseline"], k["dataset"], k["setting"]
        sub = wide_df[(wide_df.baseline == b) & (wide_df.dataset == ds)
                      & (wide_df.setting == st)]
        assert len(sub) == 3, f"{b}/{ds}/{st} has {len(sub)} seeds"
        nested[f"{b}|{ds}|{st}"] = {}
        for _, lab in LEVELS:
            nested[f"{b}|{ds}|{st}"][lab] = {}
            for metric in METRICS:
                col = f"{lab}_{metric}"
                vals = sub.set_index("seed")[col].reindex(SEEDS).to_numpy(float)
                mean = float(np.mean(vals))
                sd = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
                r = {"baseline": b, "dataset": ds, "setting": st,
                     "level": lab, "metric": metric,
                     "seed42": vals[0], "seed123": vals[1], "seed2026": vals[2],
                     "mean": mean, "sd": sd,
                     "min": float(np.min(vals)), "max": float(np.max(vals)),
                     "n_seeds": len(vals)}
                summary_rows.append(r)
                nested[f"{b}|{ds}|{st}"][lab][metric] = {
                    "per_seed": {str(s): float(v) for s, v in zip(SEEDS, vals)},
                    "mean": mean, "sd": sd, "range": [r["min"], r["max"]],
                }
    sum_df = pd.DataFrame(summary_rows)
    sum_df.to_csv(OUT_DIR / "cm-grouped-summary.csv", index=False, encoding="utf-8")
    (OUT_DIR / "cm-grouped-summary.json").write_text(
        json.dumps(nested, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---- console preview: record-level CI mean +/- SD ----
    print("record-level CI (mean +/- SD, range), n=3 seeds")
    ci = sum_df[(sum_df.level == "record") & (sum_df.metric == "ci")]
    for _, r in ci.iterrows():
        print(f"{r['baseline']:32s} {r['dataset']:5s} {r['setting']:11s} "
              f"{r['mean']:.4f} +/- {r['sd']:.4f}  "
              f"[{r['min']:.4f}, {r['max']:.4f}]")
    print("\nWROTE:", *(p.name for p in OUT_DIR.iterdir()))


if __name__ == "__main__":
    main()
