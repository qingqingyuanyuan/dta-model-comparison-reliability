#!/usr/bin/env python3
"""Lane launcher for the AdamW capacity-matched matrix: trains one baseline family.

Reuses run_capacity_matched internals without modifying config.py at runtime.
Each run still uses batch_size 64, paired seeds and the frozen splits; this only
schedules a disjoint subset of runs (worker A: DeepDTA-CM, worker B: GraphDTA).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import config as cfg  # noqa: E402
import run_capacity_matched as m  # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--baseline", required=True)
    p.add_argument("--data-root", type=Path, default=cfg.FROZEN_DATA_ROOT)
    p.add_argument("--plan-file", type=Path,
                   default=cfg.REVISION_ROOT / "capacity_matched_adamw_plan.json")
    p.add_argument("--num-workers", type=int, default=4)
    p.add_argument("--device", default="auto")
    p.add_argument("--no-progress", action="store_true")
    a = p.parse_args()

    if not a.plan_file.exists():
        raise FileNotFoundError(f"frozen plan missing: {a.plan_file}")

    rows = [r for r in m.build_matrix() if r["baseline"] == a.baseline]
    if not rows:
        raise ValueError(f"no runs for baseline {a.baseline}")

    args = SimpleNamespace(
        data_root=a.data_root,
        num_workers=a.num_workers,
        device=a.device,
        overwrite=False,
        continue_on_error=True,
        no_progress=a.no_progress,
        plan_file=a.plan_file,
    )

    print(f"LANE {a.baseline}: {len(rows)} runs", flush=True)
    for i, row in enumerate(rows, 1):
        print(f"\n[{i}/{len(rows)}] {row['stem']}", flush=True)
        if m._checkpoint_matches(row) and not args.overwrite:
            print("SKIP: valid checkpoint exists", flush=True)
            continue
        try:
            m._train_one(row, args)
        except Exception:
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    main()
