#!/usr/bin/env python3
"""Train a single AdamW capacity-matched run by exact stem (used for the smoke test).

Reuses run_capacity_matched._train_one unchanged; only selects one row. The
held-out test stays sealed and validation-only checkpoint selection is preserved.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

import config as cfg  # noqa: E402
import run_capacity_matched as m  # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--stem", required=True)
    p.add_argument("--data-root", type=Path, default=cfg.FROZEN_DATA_ROOT)
    p.add_argument("--num-workers", type=int, default=0)
    p.add_argument("--device", default="auto")
    a = p.parse_args()

    matches = [r for r in m.build_matrix() if r["stem"] == a.stem]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one row for stem {a.stem}, got {len(matches)}")
    row = matches[0]
    print("SMOKE/SINGLE RUN:", row["stem"], "->", cfg.worker_for(row["baseline"]), flush=True)

    args = SimpleNamespace(
        data_root=a.data_root,
        num_workers=a.num_workers,
        device=a.device,
        overwrite=False,
        continue_on_error=False,
        no_progress=False,
    )
    m._train_one(row, args)


if __name__ == "__main__":
    main()
