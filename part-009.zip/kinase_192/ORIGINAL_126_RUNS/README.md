# Original126 frozen artifacts

Source metrics remain byte-identical at `PREDICTIONS_AND_METRICS/statistics/Frozen126/Source_Metrics_FINAL126_Frozen.csv`, SHA-2568de0061679c33c7b154db50cdcd595afe7d2770a34d9d4ccb52df209b7888880. Archived evaluation metadata matches those checkpoint identities. The126 unique-input prediction exports preserve original prediction tokens, and local labels can be restored from official data/frozen indices.

Only one original checkpoint and limited training evidence were supplied. Complete126 checkpoints/logs and original record-level prediction CSVs were not available. Record predictions were not fabricated by expanding unique-input means. Formal record metrics retain the frozen received values. Original126 unique-input sensitivity metrics can be independently replayed, but missing record predictions and historical test access cannot be reconstructed from these files.
