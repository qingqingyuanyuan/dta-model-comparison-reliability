# Third-party data provenance and local reproduction

**v1.0.2 candidate — not yet published**. New DOI: **[PENDING: Zenodo DOI for v1.0.2]**.

The archive includes author-generated research artifacts and frozen integer indices. It excludes raw KIBA/Davis datasets, complete PaddleHelix/BatchDTA input CSVs, cleaned/frozen feature-label copies and original prediction files embedding those inputs. No third-party dataset ZIP is included under a renamed filename.

## Official acquisition and full source identities

- Official data ZIP: https://baidu-nlp.bj.bcebos.com/PaddleHelix/datasets/dti_datasets/BatchDTA_processed_data.zip
- Official project: https://github.com/PaddlePaddle/PaddleHelix/tree/dev/apps/drug_target_interaction/batchdta
- BatchDTA reference: https://doi.org/10.1093/bib/bbac260

Recorded official ZIP size:45,081,433bytes. Recorded SHA-256:

`b10231276d9ab7135c1243f94bba95f096d43e6c13f7872986dd80bbf76d689d`

The ZIP identity and historical download/timeline statements come from the supplied source note, retained unchanged in `SPLITS_AND_MANIFESTS/RECEIVED_BATCHDTA_SOURCE_NOTE.md`. The official ZIP was not freshly downloaded here, so that ZIP hash and historical timeline are not independently re-established by this build. The four local CSV copies were independently rehashed and matched every full hash in the supplied note and frozen manifest:

| Source file | Bytes | SHA-256 |
| --- | ---: | --- |
| KIBA/train_KIBA_unseenP_seenD.csv | 81,472,017 | `8a91a9a5e2457d9f482d61b7ecf3e9748dfc4168a6afcc4b78c7a056a1ffcb28` |
| KIBA/test_KIBA_unseenP_seenD.csv | 13,885,642 | `258b843129167bf55afe265b913a53b523f7ab0b9b73069526863aeda03b3d6e` |
| DAVIS/train_DAVIS_unseenP_seenD.csv | 22,108,353 | `9df2254fabda4702e9410c6bbe85a9cecd2491472ce331ce7d7c7c7e8a71b74d` |
| DAVIS/test_DAVIS_unseenP_seenD.csv | 3,973,893 | `f9d6df455daeef702d858cb6667b162759f8000e2a89bf6813d00f3caed0946e` |

Acquire the official ZIP directly, verify its SHA-256 with `sha256sum`, then unpack these four files locally under `BatchDTA_processed_data/KIBA/` and `BatchDTA_processed_data/DAVIS/`. The local-label tool requires exact sizes/hashes and rejects mismatches. Nothing is downloaded automatically. If the source is unavailable or changed, document the difference and stop rather than substituting another dataset.

## Frozen indices and exact local labels

`SPLITS_AND_MANIFESTS/row_indices/{KIBA,DAVIS}/{warm,cold_target,cold_drug}/{train,val,test}.csv` records RowIndex, SourceSplit, SourceRow, GroupId, DrugClusterId and TargetClusterId. SourceRow is zero-based in the corresponding raw CSV before cleaning; SourceSplit is source_train/source_test. The row order is the received frozen order. Opaque group/cluster IDs are partition-local. GroupId is the original lexicographic canonical-SMILES/full-sequence pair order; drug/target IDs preserve the original lexicographic cluster order. No source feature strings or true-label vectors are public in these files.

The public `labels` command gathers raw labels from the exact source rows and applies unchanged train-only min–max scalers. It writes local labels outside the archive. No RDKit or full feature regeneration is needed for saved-prediction numerical replay. These restored labels are third-party local data and should not be added to a public release without a redistribution review.

The original data-generation manifest records Python3.13.5, pandas2.2.3, NumPy2.3.5 and RDKit2025.09.4. The training environment differs and is retained in the execution records. Optional `restore_frozen_inputs.py` uses archived cleaning code, fixed row membership and scalers and requires exact original CSV hashes. Full RDKit feature reconstruction was not executed here; it must pass that hash gate before being described as byte-identical.

Here “raw” means the study’s native label column before min–max normalization (Davis pKd or KIBA score), not an assertion that original measured Kd values are redistributed. Raw-scale error metrics use that native scale.

## Author-generated prediction exports

AdamW36 record/validation exports preserve RowIndex and original Prediction_norm/Prediction_raw decimal strings. Unique-input exports preserve GroupId, both predictions and RecordCount. Original126 has unique-input exports; missing historical record predictions were not fabricated by repeating group means. Public projections have their own hashes. Original hashes remain in run indices, mappings and unchanged source receipts, and are not misrepresented as hashes of projected CSVs.

S3/S4/S8 exports omit source labels/SMILES while retaining author-generated numerical cells and representative raw source-row references for local identity recovery. Approved Figure1–5 files are unchanged. Withheld originals and any ambiguous redistribution questions are listed in `EXCLUDED_FILES_REPORT.csv` and `AUDIT_AND_VERIFICATION/MANUAL_REVIEW_REQUIRED.csv`.

The live PaddleHelix root LICENSE viewed during preparation states CC BY-NC-SA4.0; this is an upstream repository notice, not a confirmed redistribution license for every underlying KIBA/Davis dataset or derivative. Complete third-party inputs remain excluded. Dependency distributions are referenced rather than vendored. Project/component licensing and adapted-code attribution still require author confirmation; see `LICENSE_STATUS.md` and `THIRD_PARTY_NOTICES.md`.
