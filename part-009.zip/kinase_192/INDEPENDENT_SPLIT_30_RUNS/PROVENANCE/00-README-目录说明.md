# R2#1 v3 AdamW 独立划分归档

日期：2026-11-13
状态：`ALL_30_TRAIN_AND_EVAL_VERIFIED`（30/30 训练、封条、checkpoint 优化器、评估全部通过）

## 1. 本目录是什么

本目录完整归档 Molecular Diversity（SNAPP）R2#1「单一固定划分」争议的方案 A 结果：在 KIBA 第二套独立划分（cold-drug v2 / cold-target v2）上，用与 v1 主实验相同的 **AdamW** 协议重跑 5 个模型 × 2 设定 × 3 seeds = **30 组**，用于把「划分 + 优化器」联合扰动收敛回「只改划分」。

服务器工程：`/root/dta_kiba_split_robustness_adamw`（host `jupyter-jm9typxxxan04e0b`，本次运行在 `hb01-ssh.gpuhome.cc:30165`）。
运行窗口：2026-11-12 12:00:56 至 22:33:49（服务器本地时间），约 10 h 33 min。

## 2. 目录结构

- `01-正式产物/`
  - `checkpoints/`：30 个 `.pt`（18 个融合 + 12 个基线，全部 `config.TRAINING.optimizer == "adamw"`）
  - `evaluation_outputs/`：30 份 `*__evaluation.json`（18 根目录 + 12 `baselines/`）与 30 份 record-level 预测 CSV
  - `training_outputs/`：30 份 `*__training.json`（18 融合 + 12 基线）
- `02-运行日志/`
  - `rest_adamw.log`：主日志，含 `ALL_30_TRAIN_AND_EVAL_VERIFIED`
  - `per-run/`：每组训练日志（18 融合 + 12 基线）与 bootstrap 日志
  - `eval_logs/`：30 份评估日志
- `03-统计与报告/`
  - `S22-v3-聚合/`：`table_s22_v3.json`、`rank_comparison_v1_v3.json`、`macro_summary_v3.json`、`v3_all_records_cindex.json`
  - `bootstrap-v3/test_entity_bootstrap.json`：1,000 次实体 cluster bootstrap 与 leave-one-entity-out
  - `v1-reference/v1_kiba_rankings.json`：冻结 v1 五模型均值/排序参考
  - `v3-结果汇总.json` / `v3-结果汇总.md`：本目录的关键数字汇总
- `04-代码与配置/`
  - `scripts/`、`train/`、`models/`、`data/`、`baselines/`：服务器实际运行代码
  - `config.py`、`run_adamw.sh`、`config.py.bak_pre_adamw_20261112_115934`
  - `environment-server.txt`、`requirements-v3.txt`：主机、Python、torch/PyG/rdkit 版本与完整 pip freeze
- `05-数据划分/`
  - `KIBA/cold_drug/`、`KIBA/cold_target/`：train/val/test.csv、scaler.json、split_metadata.json
- `06-压缩包/`
  - `v3_reports.tar.gz`、`v3_checkpoints.tar.gz`、`v3_support.tar.gz`：原始回传包

## 3. 关键计数

| 项目 | 数量 |
|---|---:|
| checkpoints | 30 |
| evaluation JSON | 30 |
| record-level prediction CSV | 30 |
| training JSON | 30 |
| per-run 训练日志 | 31 |
| 评估日志 | 30 |
| 数据划分文件 | 10 |
| 本目录总大小 | 2158.9 MB |

## 4. 关键结果（v3，30 组 AdamW）

- 跨设定 τ（5 模型、seed 平均）= **−0.60**，exact two-sided p = **0.2333**；per-seed τ = **−0.60 / −0.40 / −0.60**。
- cold-drug 排序：**product > concat > attention > DeepDTA > GCN**。
- cold-target 排序：**GCN > DeepDTA > concat > product > attention**。
- v1↔v3 同设定 τ：cold-drug **0.80**（p=0.0833），cold-target **0.40**（p=0.4833）。
- 第二套划分内部 bootstrap（1,000 次）：保持原排序 cold-drug **221/1000**、cold-target **517/1000**；jackknife **202/206**、**41/47**。
- 跨设定 bootstrap：P(τ=−1) pooled = **0.010**，mean τ = **−0.391**。
- macro vs micro：cold-drug τ=0.40，cold-target τ=1.00。

## 5. 重要说明

1. 主指标一律取评估 JSON 的 `record_level_metrics.ci`；用导出 CSV 重算仅作一致性检查，30 组最大偏差约 1.6e-5，因此 `aggregate_s22_v3.py` 把该检查容差设为 5e-5，主指标仍用 JSON。
2. 30 组评估 JSON 的 `seal_scope` 为 `v2_robustness`；主 campaign 的 126-run 封条未改动。
3. v3 代码是 **parameter-matched reimplementation**，架构与训练协议和 v1 一致，但不是与 v1 逐字节相同的代码；论文中不得写 "identical code"。
4. 早期 v2 Adam 30 组是中间运行，保留在 `17-R2_1-KIBA独立划分稳健性`，**不用于最终论文**；本目录只包含与 v1 优化器对齐的 v3 AdamW 结果。
5. 原始评估 JSON 内的 `checkpoint` / `record_prediction_file` 仍保留服务器绝对路径，作为原始回执的一部分；本地对应文件已在 `01-正式产物` 中按同名归档。
